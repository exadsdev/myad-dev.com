<?php
// /img-proxy.php
// เสิร์ฟไฟล์รูปจากโฟลเดอร์ตามโหมดใน /config/image_switch.php

$config = require __DIR__ . '/config/image_switch.php';

// รับชื่อไฟล์จาก query
$file = $_GET['f'] ?? '';
$file = trim($file);

// กัน path traversal
if ($file === '' || strpos($file, '..') !== false || strpos($file, '/') !== false || strpos($file, '\\') !== false) {
  http_response_code(400);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Bad Request";
  exit;
}

$baseDir = $config['baseDir'];
$fullPath = rtrim($baseDir, '/\\') . DIRECTORY_SEPARATOR . $file;

// Debug mode
if (isset($_GET['debug']) && $_GET['debug'] === '1') {
  header('Content-Type: text/plain; charset=utf-8');
  echo "httpdocs:     {$config['httpdocs']}\n";
  echo "imgRoot:      {$config['imgRoot']}\n";
  echo "mode:         {$config['mode']}\n";
  echo "phoneDir:     {$config['phoneDir']}\n";
  echo "phoneV9Dir:   {$config['phoneV9Dir']}\n";
  echo "baseDir:      {$config['baseDir']}\n";
  echo "file:         {$file}\n";
  echo "fullPath:     {$fullPath}\n";
  echo "exists:       " . (file_exists($fullPath) ? "YES" : "NO") . "\n";
  exit;
}

if (!file_exists($fullPath) || !is_file($fullPath)) {
  http_response_code(404);
  header('Content-Type: text/plain; charset=utf-8');
  echo "Not Found";
  exit;
}

// ตั้ง content-type ตามนามสกุล
$ext = strtolower(pathinfo($fullPath, PATHINFO_EXTENSION));
$mime = 'application/octet-stream';
if ($ext === 'gif')
  $mime = 'image/gif';
if ($ext === 'jpg' || $ext === 'jpeg')
  $mime = 'image/jpeg';
if ($ext === 'png')
  $mime = 'image/png';
if ($ext === 'webp')
  $mime = 'image/webp';

header("Content-Type: {$mime}");
header("Cache-Control: public, max-age=86400");
header("X-Mode: {$config['mode']}");

readfile($fullPath);
exit;
