<?php require_once __DIR__ . '/config/site.php'; ?>
<!doctype html>
<html lang="th">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>นโยบายความเป็นส่วนตัว —
    <?php echo SHOP_NAME; ?>
  </title>
  <meta name="description" content="นโยบายความเป็นส่วนตัวของ <?php echo SHOP_NAME; ?> - การเก็บและใช้งานข้อมูลลูกค้า">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="app.css">
</head>

<body>
  <div class="container py-5">
    <h1 class="mb-3">นโยบายความเป็นส่วนตัว</h1>
    <p>เราเก็บข้อมูลส่วนบุคคลของลูกค้าเพื่อนำไปใช้สำหรับการสั่งซื้อ การจัดส่ง และการให้บริการหลังการขายเท่านั้น
      ข้อมูลจะไม่ถูกเปิดเผยให้บุคคลที่สาม ยกเว้นผู้ให้บริการจัดส่ง
      หรือผู้ให้บริการชำระเงินที่จำเป็นต้องใช้ข้อมูลในการดำเนินการตามคำสั่งซื้อ</p>

    <h2 class="mt-4">ข้อมูลที่เรารวบรวม</h2>
    <ul>
      <li>ชื่อ-นามสกุล</li>
      <li>ที่อยู่สำหรับจัดส่ง</li>
      <li>อีเมลและหมายเลขโทรศัพท์</li>
      <li>ข้อมูลการชำระเงิน (จัดเก็บกับผู้ให้บริการชำระเงินภายนอก)</li>
    </ul>

    <h2 class="mt-4">การใช้คุกกี้</h2>
    <p>เว็บไซต์อาจใช้คุกกี้เพื่อปรับปรุงประสบการณ์ใช้งานและเก็บสถานะการสั่งซื้อ หากต้องการปิดการใช้คุกกี้
      คุณสามารถตั้งค่าเบราว์เซอร์ของคุณได้</p>

    <h2 class="mt-4">การแชร์ข้อมูลกับบุคคลที่สาม</h2>
    <p>เราจะไม่ขายข้อมูลของลูกค้า
      แต่เราอาจแชร์ข้อมูลพื้นฐานกับผู้ให้บริการขนส่งและผู้ให้บริการชำระเงินเท่าที่จำเป็นเพื่อดำเนินการคำสั่งซื้อ</p>

    <h2 class="mt-4">ติดต่อเรา</h2>
    <p>อีเมล:
      <?php echo SITE_EMAIL; ?><br>โทร:
      <?php echo SITE_PHONE; ?>
    </p>

    <a href="index.php" class="btn btn-secondary mt-3">ย้อนกลับ</a>
  </div>
</body>

</html>