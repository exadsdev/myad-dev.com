<?php require_once __DIR__ . '/config/site.php'; ?>
<!doctype html>
<html lang="th">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>เกี่ยวกับเรา —
    <?php echo SHOP_NAME; ?>
  </title>
  <meta name="description" content="ข้อมูลบริษัท <?php echo SHOP_NAME; ?> - ประวัติ, ที่ตั้งและข้อมูลติดต่อ">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="app.css">
</head>

<body>
  <div class="container py-5">
    <h1 class="mb-3">เกี่ยวกับเรา</h1>
    <p>
      <?php echo COMPANY_NAME; ?> ดำเนินการจำหน่ายโทรศัพท์มือถือ บริการผ่อนชำระ และบริการหลังการขาย
      เรามีหน้าร้านและบริการออนไลน์มุ่งเน้นความพึงพอใจของลูกค้า
    </p>

    <h2 class="mt-4">ข้อมูลติดต่อ</h2>
    <p>
      ที่อยู่:
      <?php echo COMPANY_FULL_ADDRESS; ?><br>
      โทร:
      <?php echo SITE_PHONE; ?><br>
      อีเมล:
      <?php echo SITE_EMAIL; ?><br>
      เลขทะเบียน:
      <?php echo COMPANY_REGISTRATION; ?>
    </p>

    <h2 class="mt-4">เวลาทำการ</h2>
    <p>จันทร์-เสาร์: 09:00 - 19:00</p>

    <a href="index.php" class="btn btn-secondary mt-3">ย้อนกลับ</a>
  </div>
</body>

</html>