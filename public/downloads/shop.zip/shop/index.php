<?php
require_once __DIR__ . '/config/site.php';
$jsonData = file_get_contents('products.json');
$products = json_decode($jsonData, true);
?>
<!DOCTYPE html>
<html lang="th">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="<?php echo SEO_DEFAULT_DESCRIPTION; ?>">
  <meta name="keywords" content="<?php echo SEO_KEYWORDS; ?>">
  <meta property="og:title" content="PG Phone Shop ผ่อนมือถือ เดอะมอลล์โคราช ชั้น 3">
  <meta property="og:description"
    content="ร้านขายมือถือที่มีสินค้าคุณภาพสูง ทุกรุ่นทุกยี่ห้อ ผ่อนมือถือได้ที่ เดอะมอลล์โคราช ชั้น 3">
  <meta property="og:image" content="<?php echo SITE_LOGO_URL; ?>">
  <meta property="og:url" content="<?php echo SITE_URL; ?>">
  <meta name="robots" content="index, follow">
  <meta property="og:type" content="website">

  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">

  <title>PG Phone Shop ผ่อนมือถือ เดอะมอลล์โคราช ชั้น 3 รับซื้อ ซ่อม เทิร์น มือถือ</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

  <link rel="stylesheet" href="app.css">

  <style>
    /* ============================
   GLOBAL / BASE
   ============================ */
    :root {
      --pg-primary: #0d6efd;
      --pg-primary-soft: #e7f0ff;
      --pg-dark: #151824;
      --pg-muted: #6c757d;
      --pg-bg: #f4f6fb;
    }

    *,
    *::before,
    *::after {
      box-sizing: border-box;
    }

    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background-color: var(--pg-bg);
      color: #222;
    }

    /* ปิดระยะขอบ container บนมือถือให้ดูโล่ง */
    .container,
    .container-lg,
    .container-fluid {
      max-width: 1200px;
    }

    /* ============================
   NAVBAR
   ============================ */

    .navbar {
      background: #ffffff !important;
    }

    .navbar-brand img {
      margin-right: 0.5rem;
    }

    .navbar-brand {
      display: flex;
      align-items: center;
      font-weight: 700;
      color: var(--pg-dark) !important;
    }

    .nav-link {
      font-weight: 500;
      color: #555 !important;
    }

    .nav-link.active,
    .nav-link:hover {
      color: var(--pg-primary) !important;
    }

    /* ============================
   HERO / HEADER TITLE
   ============================ */

    .topimg {
      max-width: 320px;
      margin: 1.5rem auto 0;
      border-radius: 18px;
      overflow: hidden;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
    }

    .topimg img {
      display: block;
      width: 100%;
      height: auto;
    }

    .hero-title-main {
      text-align: center;
      margin: 2rem 0 2.5rem;
      font-weight: 800;
      letter-spacing: 0.03em;
      text-transform: uppercase;
      font-size: 1.9rem;
      color: var(--pg-dark);
    }

    .hero-title-main span {
      display: block;
      font-size: 0.9rem;
      font-weight: 500;
      color: var(--pg-muted);
      letter-spacing: 0.15em;
    }

    /* ============================
   PRODUCTS GRID
   ============================ */

    #products {
      margin-top: 1rem;
      margin-bottom: 2rem;
    }

    .product-card {
      border-radius: 16px;
      overflow: hidden;
      border: 0;
      background: #ffffff;
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
      transition: transform 0.18s ease, box-shadow 0.18s ease;
    }

    .product-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 18px 40px rgba(0, 0, 0, 0.12);
    }

    .product-card img.card-img-top {
      height: 230px;
      object-fit: cover;
    }

    .product-card .card-body {
      padding: 1.25rem 1.3rem 1.4rem;
    }

    .product-card .card-title {
      font-weight: 700;
      margin-bottom: 0.4rem;
    }

    .product-card .card-text {
      font-size: 0.95rem;
      color: var(--pg-muted);
    }

    .product-card strong {
      color: #000;
      font-size: 1rem;
    }

    .product-card .btn {
      font-weight: 600;
      border-radius: 999px;
      padding: 0.55rem 0.9rem;
    }

    /* ============================
   INFO / POLICY SECTION
   ============================ */

    .info-section {
      margin-top: 2rem;
      margin-bottom: 3rem;
    }

    .info-section h3 {
      font-size: 1.3rem;
      font-weight: 700;
      margin-bottom: 0.75rem;
    }

    .info-section .info-card {
      background: #ffffff;
      border-radius: 16px;
      border: 0;
      box-shadow: 0 10px 26px rgba(0, 0, 0, 0.06);
    }

    .info-section .info-card p {
      margin-bottom: 0;
      color: var(--pg-muted);
    }


    /* ============================
   CONTACT SECTION
   ============================ */

    #contact {
      background: #f8f9fa;
    }

    #contact h2 {
      font-weight: 800;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    }

    #contact p {
      color: #555;
    }

    /* Card ฟอร์ม & แผนที่ */
    #contact .card {
      border-radius: 16px;
      overflow: hidden;
      border: 0;
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
    }

    #contact .card-body {
      padding: 2.25rem 2.3rem;
    }

    #contact h4 {
      font-weight: 700;
    }

    /* ฟอร์มติดต่อ */
    #contact .form-label {
      font-weight: 500;
      color: #333;
    }

    #contact .form-control {
      border-radius: 10px;
      border-color: #dee2e6;
      box-shadow: none;
      transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.1s ease;
    }

    #contact .form-control:focus {
      border-color: var(--pg-primary);
      box-shadow: 0 0 0 0.15rem rgba(13, 110, 253, 0.15);
      transform: translateY(-1px);
    }

    /* ปุ่มส่งข้อความ */
    #contact button[type="submit"] {
      font-weight: 700;
      padding: 0.7rem 1rem;
      border-radius: 999px;
      text-transform: none;
    }

    /* สถานะฟอร์ม */
    #formStatus {
      font-size: 0.95rem;
    }

    /* กล่องแผนที่ & ข้อมูลบริษัท */
    #contact h5 {
      margin-bottom: 0.3rem;
    }

    #contact iframe {
      border-radius: 14px;
    }

    /* ============================
   REVIEWS SECTION
   ============================ */

    .reviews {
      padding: 4rem 0 4.5rem;
    }

    .reviews h3 {
      font-weight: 800;
      text-align: center;
      margin-bottom: 2rem;
    }

    .reviews .card {
      border-radius: 16px;
      overflow: hidden;
      border: 0;
      background: #ffffff;
      box-shadow: 0 10px 26px rgba(0, 0, 0, 0.08);
      transition: transform 0.18s ease, box-shadow 0.18s ease;
    }

    .reviews .card:hover {
      transform: translateY(-4px);
      box-shadow: 0 16px 40px rgba(0, 0, 0, 0.13);
    }

    .reviews .card-img-top {
      height: 260px;
      object-fit: cover;
    }

    .reviews .card-title {
      font-weight: 700;
    }

    .reviews .card-text {
      margin-bottom: 0;
      color: var(--pg-muted);
    }

    .reviews .card-footer {
      background-color: #f8f9fa;
      border-top: 1px solid #eee;
    }

    /* ============================
   FOOTER / CONTACT INFO
   ============================ */

    footer {
      background: #ffffff;
      font-size: 0.95rem;
    }

    footer h3,
    footer h5 {
      font-weight: 700;
      margin-bottom: 0.75rem;
    }

    .footer-contact-text {
      color: #444;
      line-height: 1.6;
    }

    /* กล่อง footer-contact ด้านล่างที่แยกออกมา */
    #footer-contact h5 {
      font-weight: 700;
    }

    #footer-contact .btn {
      margin-right: 0.4rem;
      margin-bottom: 0.4rem;
      font-weight: 500;
      border-radius: 999px;
      padding: 0.35rem 0.9rem;
    }

    /* ปุ่ม Social ใน footer ทั่วไป */
    footer .btn {
      margin-right: 0.4rem;
      margin-bottom: 0.4rem;
      font-weight: 500;
      border-radius: 999px;
      padding: 0.35rem 0.9rem;
    }

    /* ลิงก์ใน footer */
    footer a {
      text-decoration: none;
    }

    footer a:hover {
      text-decoration: underline;
    }

    /* ลิงก์นโยบาย/เงื่อนไข */
    footer a[href="#privacy-policy"],
    footer a[href="#terms"] {
      font-size: 0.92rem;
      color: var(--pg-primary);
    }

    footer a[href="#privacy-policy"]:hover,
    footer a[href="#terms"]:hover {
      color: #0a58ca;
    }

    /* เส้นคั่นด้านบน footer */
    footer .border-top {
      border-top: 1px solid #e5e5e5 !important;
    }

    /* ============================
   RESPONSIVE
   ============================ */

    @media (max-width: 991.98px) {
      #contact .card-body {
        padding: 1.75rem 1.5rem;
      }

      .reviews .card-img-top {
        height: 230px;
      }

      .hero-title-main {
        font-size: 1.6rem;
      }
    }

    @media (max-width: 767.98px) {
      #contact h2 {
        font-size: 1.6rem;
      }

      #contact p.text-center.mb-5 {
        margin-bottom: 2rem !important;
        padding: 0 0.75rem;
      }

      .reviews {
        padding: 3rem 0 3.5rem;
      }

      footer .text-lg-end {
        text-align: left !important;
        margin-top: 0.5rem;
      }
    }
  </style>

  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "ElectronicsStore",
    "@id": "<?php echo SITE_URL; ?>/#store",
    "name": "<?php echo SHOP_NAME; ?>",
    "image": "<?php echo SITE_LOGO_URL; ?>",
    "url": "<?php echo SITE_URL; ?>/",
    "telephone": "<?php echo SITE_PHONE; ?>",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "<?php echo COMPANY_ADDRESS; ?>",
      "addressLocality": "<?php echo COMPANY_PROVINCE; ?>",
      "postalCode": "<?php echo COMPANY_POSTAL_CODE; ?>",
      "addressCountry": "TH"
    },
    "priceRange": "฿฿",
    "sameAs": [
      "<?php echo SOCIAL_FACEBOOK; ?>"
    ]
  }
  </script>

</head>

<body>

  <!-- NAVBAR -->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
      <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="/">
          <img src="img/logo.png" width="60" alt="PG Phone Shop Logo">
          PG Mobile V9
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link active" href="/">หน้าแรก</a></li>
            <li class="nav-item"><a class="nav-link" href="#products">สินค้า</a></li>
            <li class="nav-item"><a class="nav-link" href="about.php">เกี่ยวกับเรา</a></li>
            <li class="nav-item"><a class="nav-link" href="#contact">ติดต่อเรา</a></li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

  <!-- HERO / BANNER -->
  <div class="container my-4">
    <div class="text-center">
      <div class="topimg">
        <img src="img/review.jpg" width="100%" alt="review PG MOBILE">
      </div>
    </div>

    <h1 class="hero-title-main">
      PG MOBILE LIMITED PARTNERSHIP
      <span>ร้านมือถือ & ผ่อนมือถือ เดอะมอลล์โคราช ชั้น 3</span>
    </h1>

    <!-- PRODUCTS -->
    <div class="row" id="products">
      <?php foreach ($products as $product): ?>
        <div class="col-md-4 mb-4">
          <div class="card product-card shadow-sm h-100">
            <img src="img/<?php echo $product['image']; ?>" class="card-img-top"
              alt="<?php echo htmlspecialchars($product['name']); ?>" />
            <div class="card-body d-flex flex-column">
              <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
              <p class="card-text flex-grow-1"><?php echo htmlspecialchars($product['description']); ?></p>
              <p class="card-text">
                <strong><?php echo number_format($product['price'], 2); ?> บาท</strong>
              </p>
              <a href="cart.php?id=<?php echo $product['id']; ?>" class="btn btn-primary w-100 mt-2">
                สั่งซื้อ
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>


  <!-- EXTRA INFORMATION (การรับประกัน / จัดส่ง / ชำระเงิน / นโยบาย / เงื่อนไข) -->
  <section class="container info-section">
    <div class="row g-4">

      <div class="col-md-6">
        <div class="p-4 bg-light info-card">
          <h3>สินค้าทุกชิ้นเป็นของแท้</h3>
          <p>สินค้าทุกชิ้นเป็นของแท้ ประกันศูนย์ไทยอย่างน้อย 1 ปี สามารถติดต่อศูนย์บริการ หรือให้เราช่วยประสานงานได้</p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="p-4 bg-light info-card">
          <h3>การจัดส่งและความปลอดภัย</h3>
          <p>จัดส่งสินค้าแบบมี Tracking ตรวจสอบได้ตลอด มีห่อกันกระแทก มีบริการเก็บเงินปลายทางในบางพื้นที่</p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="p-4 bg-light info-card">
          <h3>การชำระเงิน</h3>
          <p>รองรับบัตรเครดิต/เดบิต โอนผ่านธนาคาร และวอลเล็ต ข้อมูลถูกเก็บอย่างปลอดภัย</p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="p-4 bg-light info-card">
          <h3>นโยบายความเป็นส่วนตัว</h3>
          <p>ข้อมูลลูกค้าใช้เพื่อการจัดส่งสินค้าเท่านั้น และจะไม่ขายข้อมูลให้บุคคลที่สาม ยกเว้นขนส่ง & ระบบชำระเงิน</p>
          <p class="mt-2 mb-0">อ่านเพิ่มเติม: <a href="privacy.php">นโยบายความเป็นส่วนตัว</a> • <a
              href="refund.php">นโยบายการคืนสินค้า</a></p>
        </div>
      </div>

      <div class="col-12">
        <div class="p-4 bg-light info-card">
          <h3>เงื่อนไขการใช้งานเว็บไซต์</h3>
          <p>ลูกค้ายอมรับว่าจะใช้งานเว็บไซต์ในทางสุจริต ราคาอาจมีการเปลี่ยนแปลงได้ การสั่งซื้อเสร็จสมบูรณ์เมื่อชำระเงิน
            หรือมีการยืนยันจากเจ้าหน้าที่</p>
        </div>
      </div>

    </div>
  </section>



  <!-- ========================================= -->
  <!--   ⭐ CONTACT SECTION                      -->
  <!-- ========================================= -->

  <section id="contact" class="py-5 bg-light">
    <div class="container">
      <h2 class="text-center mb-4">ติดต่อเรา</h2>
      <p class="text-center mb-5">หากมีข้อสงสัยหรือต้องการติดต่อบริการหลังการขาย สามารถส่งข้อความถึงเราได้ทันที</p>

      <div class="row">

        <!-- Contact Form -->
        <div class="col-lg-6 col-md-12 mb-4">
          <div class="card shadow-sm border-0">
            <div class="card-body">
              <h4 class="mb-3">ส่งข้อความหาเรา</h4>

              <form id="contactForm">
                <div class="mb-3">
                  <label class="form-label">ชื่อ – นามสกุล</label>
                  <input type="text" class="form-control" name="name" required>
                </div>

                <div class="mb-3">
                  <label class="form-label">อีเมล</label>
                  <input type="email" class="form-control" name="email" required>
                </div>

                <div class="mb-3">
                  <label class="form-label">เบอร์โทร</label>
                  <input type="text" class="form-control" name="phone">
                </div>

                <div class="mb-3">
                  <label class="form-label">ข้อความ</label>
                  <textarea class="form-control" rows="4" name="message" required></textarea>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                  ส่งข้อความ
                </button>

                <div id="formStatus" class="mt-3 text-center"></div>
              </form>
            </div>
          </div>
        </div>

        <!-- Google Map -->
        <div class="col-lg-6 col-md-12">
          <div class="card shadow-sm border-0 h-100">
            <div class="card-body">

              <h4 class="text-center mb-3">แผนที่ตั้งร้าน / จุดให้บริการ</h4>

              <h5 class="fw-bold">PG MOBILE</h5>
              <p>
                183 หมู่ที่ 1 ตำบลคำตากล้า<br>
                อำเภอคำตากล้า จ.สกลนคร 47250
              </p>

              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d123900.8014764551!2d100.63811165558717!3d13.964554794559708!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x311d795ce88358e9%3A0x4176db0df5dba742!2z4Lie4Li1LuC4iOC4tS7guYLguKHguJrguLLguKI!5e0!3m2!1sth!2sth!4v1763807959950!5m2!1sth!2sth"
                width="100%" height="420" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade">
              </iframe>

            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- รีวิวลูกค้า -->
  <section class="reviews container">
    <h3>รีวิวลูกค้าใช้งานจริง บริการจริง</h3>

    <div class="row row-cols-1 row-cols-md-3 g-5">
      <div class="col">
        <div class="card h-100">
          <img src="/img/01.jpg" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9</h5>
            <p class="card-text">ลูกค้า : คุณ สมเกียรติ</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">10/10/2025</small>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100">
          <img src="/img/02.jpg" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9</h5>
            <p class="card-text">ลูกค้า : คุณ สุทิน</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">05/10/2025</small>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100">
          <img src="/img/03.jpg" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9</h5>
            <p class="card-text">ลูกค้า : คุณ สุเมธ</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">06/10/2025</small>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100">
          <img src="/img/04.png" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9 Pro</h5>
            <p class="card-text">ลูกค้า : คุณ สมัย</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">10/10/2025</small>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100">
          <img src="/img/05.png" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9 Pro</h5>
            <p class="card-text">ลูกค้า : คุณ น้องลำไย</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">12/10/2025</small>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100">
          <img src="/img/06.jpg" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9</h5>
            <p class="card-text">ลูกค้า : คุณ วราภรณ์</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">15/10/2025</small>
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- FOOTER -->
  <footer class="py-5 border-top mt-4">
    <div class="container-lg">

      <div class="row mb-4">
        <div class="col-md-4 mb-3" id="footer-contact">
          <h5>ติดต่อเรา</h5>
          <span class="footer-contact-text">
            โทร: <?php echo SITE_PHONE; ?><br>
            อีเมล: <?php echo SITE_EMAIL; ?>
          </span>
          <br><br>

          <a class="btn btn-danger" href="<?php echo SOCIAL_YOUTUBE; ?>">YouTube</a>
          <a class="btn btn-warning" href="<?php echo SOCIAL_LAZADA; ?>">Lazada</a>
          <a class="btn btn-info" href="<?php echo SOCIAL_FACEBOOK; ?>">Facebook</a>
          <a href="<?php echo SOCIAL_LINE; ?>">
            <img src="https://scdn.line-apps.com/n/line_add_friends/btn/th.png" alt="เพิ่มเพื่อน" height="36"
              border="0">
          </a>
        </div>

        <div class="col-md-4 mb-3">
          <h5>ที่ตั้งบริษัท</h5>
          <span class="footer-contact-text">
            <?php echo COMPANY_NAME; ?><br>
            <?php echo COMPANY_FULL_ADDRESS; ?>
            <br>เลขทะเบียน <?php echo COMPANY_REGISTRATION; ?>
          </span>
          <h5 class="mt-3">แผนที่</h5>
          <div class="footer-map">
            <iframe src="<?php echo MAP_EMBED_MAIN; ?>" width="600" height="450" style="border:0;" allowfullscreen=""
              loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </div>

        <div class="pgimg col-md-4 mb-3">

          <h5>ใบทะเบียนพาณิชย์</h5>
          <img src="img/pgmobile.jpg" class="footer-reg-img" width="100%"
            alt="ใบทะเบียนพาณิชย์ <?php echo SHOP_NAME; ?>">


        </div>
      </div>

      <div class="row border-top pt-3">
        <div class="col-md-6 mb-2">
          <p class="mb-0">
            © ลิขสิทธิ์ <?php echo COMPANY_NAME; ?>
          </p>
        </div>
        <div class="col-md-6 mb-2 text-lg-end">
          <a href="about.php" class="me-3">เกี่ยวกับเรา</a>
          <a href="refund.php" class="me-3">นโยบายการคืนสินค้า</a>
          <a href="privacy.php" class="me-3">นโยบายความเป็นส่วนตัว</a>
          <a href="terms.php" class="me-3">เงื่อนไขการใช้งาน</a>
          <a href="contact.php">ติดต่อเรา</a>
        </div>
      </div>
    </div>
  </footer>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>