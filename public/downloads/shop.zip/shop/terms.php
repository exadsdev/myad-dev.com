<?php require_once __DIR__ . '/config/site.php'; ?>
<!doctype html>
<html lang="th">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>เงื่อนไขการใช้งาน —
    <?php echo SHOP_NAME; ?>
  </title>
  <meta name="description" content="เงื่อนไขการใช้งาน การสั่งซื้อ และการคืนสินค้า ของ <?php echo SHOP_NAME; ?>">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="app.css">
</head>

<body>
  <div class="container py-5">
    <h1 class="mb-3">เงื่อนไขการใช้งาน</h1>
    <p>โดยการใช้เว็บไซต์นี้ คุณยอมรับเงื่อนไขการให้บริการและนโยบายของเรา โปรดอ่านรายละเอียดด้านล่างอย่างละเอียด</p>

    <h2 class="mt-4">การสั่งซื้อ</h2>
    <p>การสั่งซื้อถือว่าสำเร็จเมื่อมีการยืนยันการชำระเงิน หรือได้รับการยืนยันจากเจ้าหน้าที่ของร้าน</p>

    <h2 class="mt-4">การยกเลิกคำสั่งซื้อ</h2>
    <p>หากต้องการยกเลิก กรุณาติดต่อฝ่ายบริการลูกค้าทันที ขึ้นอยู่กับสถานะการจัดส่ง
      การยกเลิกอาจไม่สามารถทำได้หากสินค้าได้ถูกจัดส่งแล้ว</p>

    <h2 class="mt-4">การรับประกันและข้อยกเว้น</h2>
    <p>สินค้าแต่ละรายการอาจมีเงื่อนไขการรับประกันที่แตกต่างกัน
      โปรดตรวจสอบรายละเอียดสินค้าและเอกสารรับประกันที่แนบกับสินค้า</p>

    <a href="index.php" class="btn btn-secondary mt-3">ย้อนกลับ</a>
  </div>
</body>

</html>