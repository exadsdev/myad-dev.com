<?php
$orderData = [
    "product_id" => $_POST['product_id'],
    "quantity" => $_POST['quantity'],
    "customer_name" => $_POST['customer_name'],
    "customer_email" => $_POST['customer_email'],
    "customer_address" => $_POST['customer_address']
];

// อ่านข้อมูลคำสั่งซื้อเดิมจากไฟล์
$file = 'orders.json';
if (file_exists($file)) {
    $json = file_get_contents($file);
    $orders = json_decode($json, true);
} else {
    $orders = [];
}

// เพิ่มข้อมูลใหม่เข้าไป
$orders[] = $orderData;

// บันทึกข้อมูลกลับลงไฟล์ JSON
file_put_contents($file, json_encode($orders, JSON_PRETTY_PRINT));

echo "<script>alert('สั่งซื้อสำเร็จ!'); window.location='index.php';</script>";
?>
