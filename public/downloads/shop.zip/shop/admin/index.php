<?php
/**
 * Admin Dashboard
 * /admin/index.php (รองรับทั้งกรณีอยู่ Root)
 * หรือ /shop/admin/index.php (ถ้าคุณยังวางไว้ใน /shop)
 *
 * FIXED/IMPROVED:
 * - จัดรูปแบบไฟล์ให้ถูกต้อง (comment อยู่ใน PHP ไม่หลุดออกไปเป็น text)
 * - เพิ่ม CSRF token กันโดนยิงฟอร์ม
 * - Validate redirect_url ให้ปลอดภัย (ต้องเป็น http/https และไม่ยาวเกินกำหนด)
 * - โหมดรูป: phone | phonev9 (ตามที่คุณต้องการ)
 * - Preview รูป: ใช้ /img-proxy.php?f=1.gif
 * - require paths: รองรับทั้งโครงสร้าง Root และ /shop แบบอัตโนมัติ
 */

session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

/**
 * require_first: พยายาม require ไฟล์จากหลาย path
 */
function require_first(array $paths)
{
    foreach ($paths as $p) {
        if (is_file($p)) {
            require_once $p;
            return $p;
        }
    }
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Missing required file.\nTried:\n- " . implode("\n- ", $paths);
    exit;
}

/**
 * CSRF helpers
 */
function csrf_init()
{
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}
function csrf_token()
{
    return $_SESSION['csrf_token'] ?? '';
}
function csrf_verify_post()
{
    $posted = $_POST['csrf_token'] ?? '';
    $real = $_SESSION['csrf_token'] ?? '';
    if (!is_string($posted) || !is_string($real) || $posted === '' || !hash_equals($real, $posted)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo "Invalid CSRF token.";
        exit;
    }
}

csrf_init();

// หาไฟล์ config ให้ตรง ไม่ว่าจะอยู่ /config หรือ /shop/config
$loadedImageSwitch = require_first([
    __DIR__ . '/../config/image_switch.php',        // /admin -> /config
    __DIR__ . '/../shop/config/image_switch.php',   // /admin -> /shop/config
    __DIR__ . '/config/image_switch.php',           // เผื่อวางผิดที่
]);

$loadedCartLib = require_first([
    __DIR__ . '/../config/cart_redirect_lib.php',
    __DIR__ . '/../shop/config/cart_redirect_lib.php',
    __DIR__ . '/config/cart_redirect_lib.php',
]);

// คำนวณ base url ของโปรเจ็กต์ (กรณีอยู่ /shop/admin หรือ /admin)
$scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
$adminDir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
$baseUrl = preg_replace('#/admin$#', '', $adminDir);
if ($baseUrl === false || $baseUrl === null) {
    $baseUrl = '';
}
if ($baseUrl === '') {
    $baseUrl = '';
}

/**
 * Validate redirect URL
 */
function validate_redirect_url($url)
{
    if (!is_string($url))
        return '';
    $url = trim($url);
    if ($url === '')
        return '';

    // Max length
    if (strlen($url) > 2000)
        return '';

    // Must be http/https
    if (!preg_match('#^https?://#i', $url))
        return '';

    // filter_var basic
    if (!filter_var($url, FILTER_VALIDATE_URL))
        return '';

    return $url;
}

// ---------- POST handling ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify_post();

    // Switch mode
    if (isset($_POST['mode'])) {
        $newMode = ($_POST['mode'] === 'phonev9') ? 'phonev9' : 'phone';
        img_switch_set_mode($newMode);
    }

    // Save redirect URL
    if (array_key_exists('redirect_url', $_POST)) {
        $url = validate_redirect_url($_POST['redirect_url']);
        crl_set_redirect_url($url);
    }

    // Clear all cart logs
    if (isset($_POST['clear_logs'])) {
        crl_clear_cart_logs();
    }

    // Delete a single log entry
    if (isset($_POST['delete_index'])) {
        $idx = (int) $_POST['delete_index'];
        crl_delete_cart_log_index($idx);
    }

    // Redirect to avoid resubmission
    header('Location: ' . ($_SERVER['PHP_SELF'] ?? 'index.php'));
    exit;
}

$currentMode = img_switch_get_mode();
$currentRedirectUrl = crl_get_redirect_url();
$stats = crl_get_cart_stats();

$allLogs = crl_safe_json_read(crl_cart_log_path());
$recentLogs = array_slice($allLogs, -50);
$recentLogs = array_reverse($recentLogs);

// Preview URL (FIXED): ใช้ img-proxy.php ที่ Root/หรือ baseUrl
$previewUrl = $baseUrl . '/img-proxy.php?f=1.gif&v=' . time();

?><!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7fa;
            color: #333;
        }

        .container {
            max-width: 960px;
            margin: 20px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, .08);
        }

        .mode-btn.active {
            background: #3498db;
            color: #fff;
        }

        .mode-btn.inactive {
            background: #ecf0f1;
            color: #555;
        }

        .preview img {
            border: 2px solid #ddd;
            border-radius: 4px;
            width: 140px;
            height: auto;
        }

        .section-divider {
            border-top: 2px solid #dee2e6;
            margin: 30px 0;
            padding-top: 20px;
        }

        .stats-card {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
        }

        .stats-card h3 {
            font-size: 2rem;
            margin: 0;
        }

        .stats-card p {
            margin: 5px 0 0;
            color: #6c757d;
        }

        .table-logs {
            font-size: 0.85rem;
        }

        .table-logs td,
        .table-logs th {
            vertical-align: middle;
        }

        /* Hour-based row highlighting palette */
        .hour-bg-0 {
            background-color: #f8f9ff !important;
        }

        .hour-bg-1 {
            background-color: #f3fbff !important;
        }

        .hour-bg-2 {
            background-color: #f4fff7 !important;
        }

        .hour-bg-3 {
            background-color: #fffaf2 !important;
        }

        .hour-bg-4 {
            background-color: #fff5f7 !important;
        }

        .hour-bg-5 {
            background-color: #f7f5ff !important;
        }

        .hour-badge {
            font-size: 0.7rem;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            background: #6c757d;
            color: #fff;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <h1 class="mb-0">Admin Dashboard</h1>
            <div class="text-end">
                <div class="small text-muted">Base URL:
                    <code><?= htmlspecialchars($baseUrl ?: '/', ENT_QUOTES, 'UTF-8') ?></code>
                </div>
                <div class="small text-muted">Loaded:
                    <code><?= htmlspecialchars(basename($loadedImageSwitch), ENT_QUOTES, 'UTF-8') ?></code>
                </div>
            </div>
        </div>

        <!-- ============================================ -->
        <!-- Image Switch Feature (FIXED MODE NAMES)      -->
        <!-- ============================================ -->
        <h4>Image Switch</h4>
        <form method="post" class="mb-3">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

            <button type="submit" name="mode" value="phone"
                class="btn mode-btn <?= $currentMode === 'phone' ? 'active' : 'inactive' ?>">
                Phone
            </button>
            <button type="submit" name="mode" value="phonev9"
                class="btn mode-btn <?= $currentMode === 'phonev9' ? 'active' : 'inactive' ?>">
                Phone V9
            </button>
        </form>

        <div class="preview mb-4">
            <strong>Preview (1.gif) – Current mode:
                <?= htmlspecialchars($currentMode, ENT_QUOTES, 'UTF-8') ?>
            </strong>
            <br><br>
            <img src="<?= htmlspecialchars($previewUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Preview 1.gif">
            <div class="small text-muted mt-2">
                Preview URL: <code><?= htmlspecialchars($previewUrl, ENT_QUOTES, 'UTF-8') ?></code>
            </div>
        </div>

        <!-- ============================================ -->
        <!-- Redirect Target URL Settings                 -->
        <!-- ============================================ -->
        <div class="section-divider">
            <h4>Redirect Target URL</h4>
            <form method="post" class="mb-3">
                <input type="hidden" name="csrf_token"
                    value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

                <div class="mb-2">
                    <input type="text" name="redirect_url" class="form-control"
                        placeholder="https://your-domain.com/target-page"
                        value="<?= htmlspecialchars((string) $currentRedirectUrl, ENT_QUOTES, 'UTF-8') ?>">
                </div>
                <small class="text-muted d-block mb-2">
                    This URL is used to redirect visitors from cart.php when both <code>id</code> and
                    <code>mobile</code> are present.<br>
                    Must start with <code>http://</code> or <code>https://</code>. Max 2000 characters.
                </small>
                <button type="submit" class="btn btn-primary">Save URL</button>
            </form>

            <?php if (!empty($currentRedirectUrl)): ?>
                <div class="alert alert-success">
                    <strong>Current URL:</strong>
                    <?= htmlspecialchars((string) $currentRedirectUrl, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning">No redirect URL configured. Visitors will not be redirected.</div>
            <?php endif; ?>
        </div>

        <!-- ============================================ -->
        <!-- Cart Redirect Statistics                     -->
        <!-- ============================================ -->
        <div class="section-divider">
            <h4>Cart Redirect Statistics</h4>
            <p class="text-muted">Statistics are collected ONLY from cart.php requests. No image access is logged.</p>

            <div class="row g-3 mb-4">
                <div class="col-md">
                    <div class="stats-card">
                        <h3><?= (int) ($stats['total'] ?? 0) ?></h3>
                        <p>Total Events</p>
                    </div>
                </div>
                <div class="col-md">
                    <div class="stats-card">
                        <h3 class="text-danger"><?= (int) ($stats['redirect'] ?? 0) ?></h3>
                        <p>Redirects</p>
                    </div>
                </div>
                <div class="col-md">
                    <div class="stats-card">
                        <h3 class="text-info"><?= (int) ($stats['view'] ?? 0) ?></h3>
                        <p>Views</p>
                    </div>
                </div>
            </div>

            <form method="post" class="mb-4">
                <input type="hidden" name="csrf_token"
                    value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
                <button type="submit" name="clear_logs" class="btn btn-danger"
                    onclick="return confirm('Are you sure you want to clear all cart redirect logs?');">
                    Clear All Cart Logs
                </button>
            </form>
        </div>

        <!-- ============================================ -->
        <!-- Recent Cart Logs Table                       -->
        <!-- ============================================ -->
        <div class="section-divider">
            <h4>Recent Cart Logs (Last 50)</h4>

            <?php if (empty($recentLogs)): ?>
                <div class="alert alert-info">No log entries yet.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm table-logs">
                        <thead class="table-dark">
                            <tr>
                                <th>Hour</th>
                                <th>Time</th>
                                <th>IP</th>
                                <th>Action</th>
                                <th>ID</th>
                                <th>Ref</th>
                                <th>Redirect To</th>
                                <th>Del</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $prevHourKey = null;
                            $hourColorIndex = -1;

                            foreach ($recentLogs as $idx => $log):
                                $realIndex = count($allLogs) - 1 - $idx;

                                $shortRedirect = crl_short_text($log['redirect_to'] ?? '', 25);

                                $logTime = (string) ($log['time'] ?? '');
                                $hourKey = substr($logTime, 0, 13);

                                $isNewHour = ($hourKey !== $prevHourKey);
                                if ($isNewHour) {
                                    $hourColorIndex++;
                                    $prevHourKey = $hourKey;
                                }
                                $colorClass = 'hour-bg-' . ($hourColorIndex % 6);

                                $hourBadge = '';
                                if ($isNewHour && strlen($hourKey) >= 13) {
                                    $hourBadge = substr($hourKey, 11, 2) . ':00';
                                }
                                ?>
                                <tr class="<?= htmlspecialchars($colorClass, ENT_QUOTES, 'UTF-8') ?>">
                                    <td>
                                        <?php if ($isNewHour && $hourBadge): ?>
                                            <span class="hour-badge"><?= htmlspecialchars($hourBadge, ENT_QUOTES, 'UTF-8') ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">·</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($logTime, ENT_QUOTES, 'UTF-8') ?></td>
                                    <td><?= htmlspecialchars((string) ($log['ip'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                    <td>
                                        <?php
                                        $action = (string) ($log['action'] ?? '');
                                        if ($action === 'redirect'): ?>
                                            <span class="badge bg-danger">redirect</span>
                                        <?php elseif ($action === 'no_redirect'): ?>
                                            <span class="badge bg-secondary">no_redirect</span>
                                        <?php else: ?>
                                            <span class="badge bg-info"><?= htmlspecialchars($action, ENT_QUOTES, 'UTF-8') ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars((string) ($log['id'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                    <td><?= htmlspecialchars((string) ($log['ref'] ?? ($log['mobile'] ?? '')), ENT_QUOTES, 'UTF-8') ?>
                                    </td>
                                    <td title="<?= htmlspecialchars((string) ($log['redirect_to'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
                                        <?= htmlspecialchars((string) $shortRedirect, ENT_QUOTES, 'UTF-8') ?>
                                    </td>
                                    <td>
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="csrf_token"
                                                value="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="delete_index" value="<?= (int) $realIndex ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger"
                                                onclick="return confirm('Delete this entry?');">✕</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer></script>
</body>

</html>