<?php
// /admin/stats.php

session_start();

// ✅ กันคนเข้า Admin ถ้ายังไม่ login
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// ✅ ต้อง require เพื่อให้ img_switch_get_mode() ใช้งานได้
$config = require __DIR__ . '/../config/image_switch.php';
require_once __DIR__ . '/../config/cart_redirect_lib.php';

$logFile = __DIR__ . '/../config/visitor_log.json';
$logs = [];
if (file_exists($logFile)) {
    $content = file_get_contents($logFile);
    if ($content !== false) {
        $decoded = json_decode($content, true);
        if (is_array($decoded)) {
            $logs = $decoded;
        }
    }
}

$total = count($logs);

$currentMode = img_switch_get_mode();

// Latest 20 entries
$latest = array_reverse($logs);
$latest = array_slice($latest, 0, 20);

function h($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>สถิติผู้เข้าชม - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#0b1220; color:#e8eefc; }
        .card { background:#111a2e; border:1px solid rgba(255,255,255,.08); }
        .muted { color:rgba(232,238,252,.7); }
        .table { color:#e8eefc; }
        .table thead th { color:#cfe3ff; border-bottom-color: rgba(255,255,255,.12); }
        .table td, .table th { border-top-color: rgba(255,255,255,.08); }
        code { color:#cfe3ff; }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <div>
            <h3 class="mb-0">สถิติผู้เข้าชม</h3>
            <div class="muted">โหมดรูปปัจจุบัน: <code><?= h($currentMode) ?></code></div>
        </div>
        <div class="d-flex gap-2">
            <a class="btn btn-outline-light" href="index.php">กลับหน้า Admin</a>
            <a class="btn btn-outline-danger" href="logout.php">ออกจากระบบ</a>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-12">
            <div class="card p-3 text-center">
                <h4 class="muted mb-1">จำนวนผู้เข้าชมทั้งหมด</h4>
                <h2 class="mb-0 text-primary"><?= number_format($total) ?></h2>
            </div>
        </div>
    </div>

    <div class="card p-3">
        <h5 class="mb-3">ผู้เข้าชมล่าสุด 20 รายการ</h5>
        <div class="table-responsive">
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th>วันเวลา</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($latest)): ?>
                    <tr><td colspan="3" class="text-center text-muted">ไม่พบข้อมูลการเข้าชม</td></tr>
                    <?php else: ?>
                    <?php foreach ($latest as $row): ?>
                    <tr>
                        <td><?= h($row['time'] ?? '-') ?></td>
                        <td><?= h($row['ip'] ?? '-') ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>