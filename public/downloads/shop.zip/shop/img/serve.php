<?php
// /img/serve.php
declare(strict_types=1);

/**
 * Robust image server:
 * - Called as: /img/serve.php?file=1.gif
 * - Reads switch mode from: /shop/config/image_switch.php (if exists)
 * - Serves from:
 *    /shop/phone/<file>    when mode=phone
 *    /shop/phone-v9/<file> when mode=phone_v9
 *
 * Debug:
 *   /img/serve.php?file=1.gif&debug=1
 */

function respond_text(int $code, string $msg): void {
    http_response_code($code);
    header('Content-Type: text/plain; charset=utf-8');
    echo $msg;
    exit;
}

function safe_basename(string $name): string {
    $name = trim($name);
    $name = str_replace(["\0", "\r", "\n"], '', $name);
    return basename($name);
}

function is_allowed_ext(string $file): bool {
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    // ปรับได้ตามต้องการ: ถ้าคุณต้องการเฉพาะ gif ให้เหลือแค่ ['gif']
    $allowed = ['gif', 'jpg', 'jpeg', 'png', 'webp'];
    return in_array($ext, $allowed, true);
}

function content_type_for(string $file): string {
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    return match ($ext) {
        'gif'  => 'image/gif',
        'jpg', 'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'webp' => 'image/webp',
        default => 'application/octet-stream',
    };
}

// ------------------ Inputs ------------------
$file = safe_basename((string)($_GET['file'] ?? ''));
$debug = isset($_GET['debug']) && (string)$_GET['debug'] === '1';

if ($file === '') {
    respond_text(400, 'Missing file parameter.');
}
if (!is_allowed_ext($file)) {
    respond_text(400, 'Invalid file extension.');
}

// ------------------ Locate project paths ------------------
// Document root (e.g. /public_html)
$docRoot = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), '/\\');
if ($docRoot === '') {
    // fallback
    $docRoot = rtrim(dirname(__DIR__), '/\\');
}

// Project is under /shop
$shopRoot = $docRoot . '/shop';

// Config path
$configPath = $shopRoot . '/config/image_switch.php';

// Default folders (if config not found)
$phoneDir   = $shopRoot . '/phone';
$phoneV9Dir = $shopRoot . '/phone-v9';

// Load switch config if exists
$mode = 'phone';
if (is_file($configPath)) {
    require_once $configPath;
    if (function_exists('img_switch_get_mode')) {
        $mode = img_switch_get_mode();
    }

    // If config defines constants, prefer them
    if (defined('IMG_SWITCH_PHONE_DIR')) {
        $phoneDir = (string)IMG_SWITCH_PHONE_DIR;
    }
    if (defined('IMG_SWITCH_PHONE_V9_DIR')) {
        $phoneV9Dir = (string)IMG_SWITCH_PHONE_V9_DIR;
    }
}

// Normalize mode
if ($mode !== 'phone' && $mode !== 'phone_v9') {
    $mode = 'phone';
}

// Choose base dir
$baseDir = ($mode === 'phone_v9') ? $phoneV9Dir : $phoneDir;

// Final file path
$fullPath = rtrim($baseDir, '/\\') . '/' . $file;

// ------------------ Debug ------------------
if ($debug) {
    header('Content-Type: text/plain; charset=utf-8');
    echo "docRoot:      {$docRoot}\n";
    echo "shopRoot:     {$shopRoot}\n";
    echo "configPath:   {$configPath}\n";
    echo "mode:         {$mode}\n";
    echo "phoneDir:     {$phoneDir}\n";
    echo "phoneV9Dir:   {$phoneV9Dir}\n";
    echo "baseDir:      {$baseDir}\n";
    echo "file:         {$file}\n";
    echo "fullPath:     {$fullPath}\n";
    echo "exists:       " . (is_file($fullPath) ? 'YES' : 'NO') . "\n";
    exit;
}

// ------------------ Serve ------------------
if (!is_file($fullPath)) {
    respond_text(404, 'File not found.');
}

$mime = content_type_for($file);
header('Content-Type: ' . $mime);
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$size = filesize($fullPath);
if ($size !== false) {
    header('Content-Length: ' . $size);
}

readfile($fullPath);
exit;
