<?php
/**
 * Cart Redirect Helper Library
 * /shop/config/cart_redirect_lib.php
 * 
 * JSON files used:
 * - /shop/config/redirect_settings.json (stores redirect URL)
 * - /shop/config/cart_redirect_log.json (stores cart access logs)
 */

declare(strict_types=1);

function crl_redirect_settings_path(): string
{
    return __DIR__ . '/redirect_settings.json';
}

function crl_cart_log_path(): string
{
    return __DIR__ . '/cart_redirect_log.json';
}

function crl_safe_json_read(string $path): array
{
    if (!is_file($path)) {
        return [];
    }

    $raw = @file_get_contents($path);
    if ($raw === false) {
        return [];
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function crl_safe_json_write_atomic(string $path, string $json): bool
{
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }

    $tmp = $path . '.tmp';
    $fp = @fopen($tmp, 'wb');
    if ($fp === false) {
        return false;
    }

    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        @unlink($tmp);
        return false;
    }

    $written = fwrite($fp, $json);
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    if ($written === false) {
        @unlink($tmp);
        return false;
    }

    return @rename($tmp, $path);
}

function crl_json_encode_pretty($data): string
{
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    return ($json === false) ? '[]' : $json;
}

function crl_get_client_ip(): string
{
    $candidates = [
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_REAL_IP',
        'HTTP_X_FORWARDED_FOR',
        'REMOTE_ADDR',
    ];

    foreach ($candidates as $key) {
        if (!isset($_SERVER[$key]) || !is_string($_SERVER[$key])) {
            continue;
        }

        $value = trim((string) $_SERVER[$key]);
        if ($value === '') {
            continue;
        }

        if ($key === 'HTTP_X_FORWARDED_FOR') {
            $parts = explode(',', $value);
            $value = trim((string) ($parts[0] ?? ''));
        }

        return $value !== '' ? $value : 'unknown';
    }

    return 'unknown';
}

function crl_validate_redirect_url(string $url): string
{
    $url = trim($url);

    if ($url === '') {
        return '';
    }

    if (strlen($url) > 2000) {
        return '';
    }

    if (!preg_match('#^https?://#i', $url)) {
        return '';
    }

    return $url;
}

function crl_get_redirect_url(): string
{
    $settings = crl_safe_json_read(crl_redirect_settings_path());
    $raw = '';

    // Check both 'url' (new) and 'redirect_url' (legacy) for compatibility
    if (isset($settings['url']) && is_string($settings['url'])) {
        $raw = $settings['url'];
    } elseif (isset($settings['redirect_url']) && is_string($settings['redirect_url'])) {
        $raw = $settings['redirect_url'];
    }

    return crl_validate_redirect_url($raw);
}

function crl_set_redirect_url(string $url): bool
{
    $valid = crl_validate_redirect_url($url);

    $payload = [
        'url' => $valid,
        'updatedAt' => date('Y-m-d H:i:s'),
    ];

    $json = crl_json_encode_pretty($payload) . "\n";
    return crl_safe_json_write_atomic(crl_redirect_settings_path(), $json);
}

function crl_append_cart_log(array $entry): bool
{
    $path = crl_cart_log_path();
    $logs = crl_safe_json_read($path);
    if (!is_array($logs)) {
        $logs = [];
    }

    $logs[] = $entry;

    $maxEntries = 2000;
    if (count($logs) > $maxEntries) {
        $logs = array_slice($logs, -$maxEntries);
    }

    $json = crl_json_encode_pretty($logs) . "\n";
    return crl_safe_json_write_atomic($path, $json);
}

function crl_clear_cart_logs(): bool
{
    $json = "[]\n";
    return crl_safe_json_write_atomic(crl_cart_log_path(), $json);
}

function crl_delete_cart_log_index(int $index): bool
{
    $path = crl_cart_log_path();
    $logs = crl_safe_json_read($path);

    if (!is_array($logs)) {
        return false;
    }

    if ($index < 0 || $index >= count($logs)) {
        return false;
    }

    array_splice($logs, $index, 1);
    $json = crl_json_encode_pretty($logs) . "\n";

    return crl_safe_json_write_atomic($path, $json);
}

function crl_short_text(string $text, int $maxLen): string
{
    $text = trim($text);
    if ($text === '') {
        return '';
    }

    if (strlen($text) <= $maxLen) {
        return $text;
    }

    return substr($text, 0, max(0, $maxLen - 3)) . '...';
}

function crl_get_cart_stats(): array
{
    $logs = crl_safe_json_read(crl_cart_log_path());
    $stats = [
        'total' => 0,
        'redirect' => 0,
        'view' => 0,
    ];
    if (!is_array($logs)) {
        return $stats;
    }
    foreach ($logs as $entry) {
        $stats['total']++;
        if (isset($entry['action'])) {
            if ($entry['action'] === 'redirect') {
                $stats['redirect']++;
            } elseif ($entry['action'] === 'view') {
                $stats['view']++;
            }
        }
    }
    return $stats;
}
