<?php
/**
 * Site Configuration
 * /shop/config/site.php
 * 
 * ═══════════════════════════════════════════════════════════════════════════════
 * 📌 ไฟล์นี้เป็นไฟล์เดียวสำหรับแก้ไขข้อมูลโดเมนและข้อมูลติดต่อของเว็บไซต์
 * ═══════════════════════════════════════════════════════════════════════════════
 * 
 * วิธีใช้งาน: require_once __DIR__ . '/config/site.php';
 * จากนั้นเรียกใช้ SITE_DOMAIN, SITE_URL, SITE_EMAIL, SITE_PHONE, etc.
 */

// ═══════════════════════════════════════════════════════════════════════════════
// 🌐 DOMAIN & URL SETTINGS
// ═══════════════════════════════════════════════════════════════════════════════

// โดเมนหลัก (ไม่มี https:// และ /)
define('SITE_DOMAIN', 'orderedshop.pgmobile.shop');

// URL เต็ม (พร้อม https://)
define('SITE_URL', 'https://' . SITE_DOMAIN);

// URL สำหรับ Logo
define('SITE_LOGO_URL', SITE_URL . '/img/logo.png');


// ═══════════════════════════════════════════════════════════════════════════════
// 📧 CONTACT INFORMATION
// ═══════════════════════════════════════════════════════════════════════════════

// อีเมลติดต่อ
define('SITE_EMAIL', 'support@pgmobile.shop');

// เบอร์โทร
define('SITE_PHONE', '093-564-9111');


// ═══════════════════════════════════════════════════════════════════════════════
// 🏢 COMPANY INFORMATION
// ═══════════════════════════════════════════════════════════════════════════════

// ชื่อบริษัท
define('COMPANY_NAME', 'PG MOBILE LIMITED PARTNERSHIP');

// ชื่อร้าน
define('SHOP_NAME', 'PG Mobile V9');

// เลขทะเบียนพาณิชย์
define('COMPANY_REGISTRATION', '0473560000846');

// ที่อยู่
define('COMPANY_ADDRESS', '183 หมู่ที่ 1 ตำบลคำตากล้า อำเภอคำตากล้า');
define('COMPANY_PROVINCE', 'สกลนคร');
define('COMPANY_POSTAL_CODE', '47250');
define('COMPANY_FULL_ADDRESS', COMPANY_ADDRESS . ' จ.' . COMPANY_PROVINCE . ' ' . COMPANY_POSTAL_CODE);


// ═══════════════════════════════════════════════════════════════════════════════
// 🔗 SOCIAL MEDIA LINKS
// ═══════════════════════════════════════════════════════════════════════════════

define('SOCIAL_FACEBOOK', 'https://www.facebook.com/meedee88shopping/');
define('SOCIAL_YOUTUBE', 'https://www.youtube.com/watch?v=ILFvnPZpvD4&t=7s');
define('SOCIAL_LINE', 'https://lin.ee/pzucFIX');
define('SOCIAL_LAZADA', 'https://www.lazada.co.th/shop-mobiles/pg/?spm=a2o4m.pdp_revamp.0.0.781a4c22qZGHvt');


// ═══════════════════════════════════════════════════════════════════════════════
// 🗺️ GOOGLE MAPS EMBED URLS
// ═══════════════════════════════════════════════════════════════════════════════

// แผนที่ร้าน (Sakon Nakhon)
define('MAP_EMBED_MAIN', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3797.7216506345394!2d103.7636709!3d17.8516788!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x313b470030665087%3A0x8119614a066b6a61!2spg%20mobile!5e0!3m2!1sth!2sth!4v1768082237857!5m2!1sth!2sth');

// แผนที่สาขาโคราช (ถ้ามี)
define('MAP_EMBED_KORAT', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d123900.8014764551!2d100.63811165558717!3d13.964554794559708!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x311d795ce88358e9%3A0x4176db0df5dba742!2z4Lie4Li1LuC4iOC4tS7guYLguKHguJrguLLguKI!5e0!3m2!1sth!2sth!4v1763807959950!5m2!1sth!2sth');


// ═══════════════════════════════════════════════════════════════════════════════
// 🎨 SEO & METADATA
// ═══════════════════════════════════════════════════════════════════════════════

define('SEO_TITLE_SUFFIX', ' | ' . SHOP_NAME);
define('SEO_DEFAULT_DESCRIPTION', 'PG Phone Shop ผ่อนมือถือ เดอะมอลล์โคราช ชั้น 3 รับซื้อ ซ่อม เทิร์น มือถือ');
define('SEO_KEYWORDS', 'pg mobile, pg v9, ผ่อนมือถือ, สมาร์ทโฟน, ร้านขายมือถือ, ราคามือถือ, สั่งซื้อมือถือออนไลน์, ผ่อนมือถือ เดอะมอลล์โคราช');


// ═══════════════════════════════════════════════════════════════════════════════
// 📌 HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * สร้าง URL เต็มจาก path
 * @param string $path เช่น '/img/logo.png' หรือ 'cart.php?id=1'
 * @return string URL เต็ม
 */
function site_url(string $path = ''): string
{
    $path = ltrim($path, '/');
    return SITE_URL . ($path !== '' ? '/' . $path : '');
}

/**
 * สร้าง mailto link
 * @return string mailto:email
 */
function site_mailto(): string
{
    return 'mailto:' . SITE_EMAIL;
}

/**
 * สร้าง tel link
 * @return string tel:phone (กรองเฉพาะตัวเลขและ +)
 */
function site_tel(): string
{
    return 'tel:' . preg_replace('/[^0-9+]/', '', SITE_PHONE);
}
