<?php
// /config/image_switch.php

define('IMG_SWITCH_STATE_FILE', __DIR__ . '/image_switch_state.json');
define('IMG_SWITCH_DEFAULT_MODE', 'phone'); // phone | phonev9

function img_switch_get_mode(): string
{
    $mode = IMG_SWITCH_DEFAULT_MODE;

    if (is_file(IMG_SWITCH_STATE_FILE)) {
        $raw = @file_get_contents(IMG_SWITCH_STATE_FILE);
        if ($raw !== false) {
            $json = json_decode($raw, true);
            if (is_array($json) && isset($json['mode']) && is_string($json['mode'])) {
                $mode = $json['mode'];
            }
        }
    }

    if ($mode !== 'phone' && $mode !== 'phonev9') {
        $mode = IMG_SWITCH_DEFAULT_MODE;
    }

    return $mode;
}

function img_switch_set_mode(string $mode): bool
{
    if ($mode !== 'phone' && $mode !== 'phonev9')
        return false;

    $payload = [
        'mode' => $mode,
        'updatedAt' => date('c'),
    ];

    $tmp = IMG_SWITCH_STATE_FILE . '.tmp';
    $ok = @file_put_contents($tmp, json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    if ($ok === false)
        return false;

    return @rename($tmp, IMG_SWITCH_STATE_FILE);
}

// resolve paths
$httpdocs = rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/\\');
if ($httpdocs === '') {
    $httpdocs = rtrim(realpath(__DIR__ . '/..'), '/\\');
}

$imgRoot = is_dir($httpdocs . '/img') ? ($httpdocs . '/img') : $httpdocs;

$phoneDir = $imgRoot . '/phone';
$phoneV9Dir = $imgRoot . '/phonev9';

$mode = img_switch_get_mode();
$baseDir = ($mode === 'phonev9') ? $phoneV9Dir : $phoneDir;

return [
    'httpdocs' => $httpdocs,
    'imgRoot' => $imgRoot,
    'mode' => $mode,
    'phoneDir' => $phoneDir,
    'phoneV9Dir' => $phoneV9Dir,
    'baseDir' => $baseDir,
];
