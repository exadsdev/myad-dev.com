<?php require_once __DIR__ . '/config/site.php'; ?>
<!doctype html>
<html lang="th">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>นโยบายการคืนสินค้าและคืนเงิน —
    <?php echo SHOP_NAME; ?>
  </title>
  <meta name="description"
    content="นโยบายการคืนสินค้าและคืนเงินของ <?php echo SHOP_NAME; ?> — ขั้นตอนการขอคืนสินค้า, เงื่อนไขการคืน, ระยะเวลา และการติดต่อฝ่ายบริการลูกค้า">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="app.css">
  <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "MerchantReturnPolicy",
      "name": "<?php echo SHOP_NAME; ?> - Return Policy",
      "merchantReturnLink": "<?php echo SITE_URL; ?>/refund.php",
      "returnPolicyCategory": "https://schema.org/MerchantReturnFiniteReturnWindow",
      "returnWindow": {
        "@type": "QuantitativeValue",
        "value": 14,
        "unitCode": "DAY"
      },
      "returnFees": "https://schema.org/FreeReturn"
    }
    </script>
</head>

<body class="bg-light">
  <div class="container py-5">
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <div class="card shadow-sm">
          <div class="card-body">
            <h1 class="h3 mb-3">นโยบายการคืนสินค้าและคืนเงิน</h1>

            <p>ที่
              <?php echo SHOP_NAME; ?> เราต้องการให้คุณพึงพอใจกับการสั่งซื้อของคุณ หากสินค้ามีปัญหา หรือคุณต้องการยกเลิก
              คำสั่งซื้อ เรามีกระบวนการคืนสินค้าและคืนเงินที่ชัดเจนและยุติธรรมดังนี้
            </p>

            <h3 class="mt-4">1. ระยะเวลาในการขอคืน / เปลี่ยน</h3>
            <p>คุณสามารถขอคืนหรือเปลี่ยนสินค้าได้ภายใน <strong>14 วัน</strong> นับจากวันที่ได้รับสินค้า
              (ยืนยันโดยหมายเลขติดตามการจัดส่ง)</p>

            <h3 class="mt-4">2. เงื่อนไขการคืนสินค้า</h3>
            <ul>
              <li>สินค้าที่ต้องการคืนต้องอยู่ในสภาพเดิม ไม่ถูกใช้งานหรือชำรุดจากการใช้งานที่ผิดปกติ</li>
              <li>ต้องส่งคืนพร้อมกล่องบรรจุ ภายในชุดอุปกรณ์ และเอกสารใบเสร็จหรือหลักฐานการซื้อ</li>
              <li>สินค้าที่มีการเสียหายจากการขนส่ง ทางร้านยินดีรับผิดชอบและจะดำเนินการคืนเงินหรือเปลี่ยนสินค้าให้</li>
              <li>สินค้าที่เกิดความเสียหายจากการใช้งาน/ตกหล่น หรือถูกดัดแปลง จะไม่สามารถคืนได้ภายใต้เงื่อนไขปกติ</li>
            </ul>

            <h3 class="mt-4">3. ขั้นตอนการขอคืนหรือเปลี่ยนสินค้า</h3>
            <ol>
              <li>ติดต่อฝ่ายลูกค้าสัมพันธ์ที่ <strong>
                  <?php echo SITE_EMAIL; ?>
                </strong> หรือโทร <strong>
                  <?php echo SITE_PHONE; ?>
                </strong></li>
              <li>แจ้งหมายเลขคำสั่งซื้อ และแนบรูปภาพหรือวีดีโอประกอบ (ถ้ามี)</li>
              <li>ลูกค้าจะได้รับคำแนะนำการจัดส่งคืนสินค้าและวิธีการรับเงินคืนหรือเปลี่ยนสินค้า</li>
            </ol>

            <h3 class="mt-4">4. การคืนเงิน</h3>
            <p>เมื่อเราตรวจสอบและยืนยันการรับคืนสินค้าแล้ว เราจะดำเนินการคืนเงินภายใน 7-14
              วันทำการผ่านช่องทางการชำระเงินเดิม (หากเป็นไปได้) ยกเว้นกรณีที่มีข้อตกลงอื่น ๆ ระบุไว้</p>

            <h3 class="mt-4">5. ค่าจัดส่งคืน</h3>
            <p>ถ้าการคืนเกิดจากความผิดพลาดของร้านค้า (ส่งสินค้าผิดหรือสินค้ามีตำหนิ) ร้านค้าจะรับผิดชอบค่าจัดส่งคืน
              ในกรณีขอคืนสินค้าเพราะเหตุผลของลูกค้า อาจมีค่าใช้จ่ายในการจัดส่งคืน</p>

            <h3 class="mt-4">6. สินค้าที่ยกเว้นการรับคืน</h3>
            <p>สินค้าที่ไม่สามารถคืนได้ เช่น บริการดาวน์โหลดซอฟต์แวร์ สินค้าที่ใช้แล้วเสียหายจากการใช้งาน
              หรือสินค้าที่ระบุไว้เป็นข้อยกเว้นในรายละเอียดหน้าสินค้า</p>

            <h3 class="mt-4">7. คำถามเพิ่มเติม</h3>
            <p>หากมีคำถามเพิ่มเติม หรืออยากส่งเอกสารประกอบการคืนสินค้า กรุณาติดต่อ
              <?php echo SITE_EMAIL; ?> หรือโทร
              <?php echo SITE_PHONE; ?>
            </p>

            <a href="index.php" class="btn btn-secondary mt-3">ย้อนกลับไปยังหน้าหลัก</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html>