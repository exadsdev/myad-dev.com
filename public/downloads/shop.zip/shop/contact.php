<?php require_once __DIR__ . '/config/site.php'; ?>
<!doctype html>
<html lang="th">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ติดต่อเรา —
    <?php echo SHOP_NAME; ?>
  </title>
  <meta name="description" content="ติดต่อ <?php echo SHOP_NAME; ?> — เบอร์โทร อีเมล และแผนที่ร้าน">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="app.css">
</head>

<body>
  <div class="container py-5">
    <h1 class="mb-3">ติดต่อเรา</h1>
    <p class="text-muted mb-4">หากต้องการสอบถามข้อมูลสินค้า การสั่งซื้อ หรือบริการหลังการขาย
      ติดต่อเราได้ตามช่องทางด้านล่าง</p>

    <div class="row g-4">
      <div class="col-12 col-lg-5">
        <div class="card border-0 shadow-sm">
          <div class="card-body">
            <h2 class="h5 mb-3">ข้อมูลติดต่อ</h2>
            <p class="mb-2"><strong>โทร:</strong> <a href="<?php echo site_tel(); ?>" class="text-decoration-none">
                <?php echo SITE_PHONE; ?>
              </a></p>
            <p class="mb-2"><strong>อีเมล:</strong> <a href="<?php echo site_mailto(); ?>" class="text-decoration-none">
                <?php echo SITE_EMAIL; ?>
              </a></p>

            <div class="d-flex flex-wrap gap-2 mb-3">
              <a class="btn btn-outline-primary btn-sm" href="<?php echo SOCIAL_FACEBOOK; ?>" target="_blank"
                rel="noopener">Facebook</a>
              <a class="btn btn-outline-success btn-sm" href="<?php echo SOCIAL_LINE; ?>" target="_blank"
                rel="noopener">LINE</a>
              <a class="btn btn-outline-secondary btn-sm" href="<?php echo site_mailto(); ?>">Email</a>
            </div>

            <p class="mb-0"><strong>ที่อยู่:</strong>
              <?php echo COMPANY_NAME; ?><br>
              <?php echo COMPANY_FULL_ADDRESS; ?><br>
              <span class="text-muted">เลขทะเบียน
                <?php echo COMPANY_REGISTRATION; ?>
              </span>
            </p>

            <hr class="my-4">

            <h3 class="h6 mb-2">ใบทะเบียนพาณิชย์</h3>
            <img src="img/pgmobile.jpg" class="footer-reg-img" alt="ใบทะเบียนพาณิชย์ <?php echo SHOP_NAME; ?>">
          </div>
        </div>
      </div>

      <div class="col-12 col-lg-7">
        <div class="card border-0 shadow-sm">
          <div class="card-body">
            <h2 class="h5 mb-3">แผนที่</h2>
            <div class="footer-map contact-map" style="max-width:none;">
              <iframe src="<?php echo MAP_EMBED_MAIN; ?>" width="600" height="450" style="border:0;" allowfullscreen=""
                loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="d-flex flex-wrap gap-2 mt-4">
      <a href="index.php" class="btn btn-primary">กลับหน้าแรก</a>
      <a href="index.php" class="btn btn-outline-secondary">ย้อนกลับ</a>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>