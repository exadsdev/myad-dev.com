<?php
/**
 * หน้ารายการวิดีโอทั้งหมด
 * URL: /videos.php
 * 
 * Performance Critical:
 * - LCP: ใช้ thumbnail ขนาด hqdefault เพื่อโหลดเร็ว
 * - CLS: กำหนด aspect-ratio ไว้ล่วงหน้า
 * - INP: ไม่มี JS หนักในหน้านี้
 */
require_once 'config.php';
require_once 'data/videos.php';

$pageTitle = 'วิดีโอรีวิวมือถือมือสอง PG Mobile | ' . SITE_NAME;
$pageDescription = 'รวมวิดีโอรีวิวมือถือมือสอง PG Mobile V9 คุณภาพดี ราคาถูก รับประกัน 30 วัน ดูรีวิวจริงก่อนตัดสินใจซื้อ';
$pageKeywords = 'วิดีโอ PG Mobile, รีวิวมือถือมือสอง, PG V9 รีวิว, มือถือราคาถูก, รีวิววิดีโอมือถือ';
$canonicalPath = '/videos.php';

// Get sorted videos
$allVideos = getSortedVideos();

include 'includes/header.php';
?>

<!-- JSON-LD: BreadcrumbList -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
        {
            "@type": "ListItem",
            "position": 1,
            "name": "หน้าแรก",
            "item": "<?= BASE_URL ?>/"
        },
        {
            "@type": "ListItem",
            "position": 2,
            "name": "วิดีโอ",
            "item": "<?= BASE_URL ?>/videos.php"
        }
    ]
}
</script>

<!-- JSON-LD: ItemList for Video Collection -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "ItemList",
    "name": "วิดีโอรีวิวมือถือมือสอง PG Mobile",
    "description": "รวมวิดีโอรีวิวมือถือมือสองคุณภาพดี ราคาถูก จาก PG Mobile",
    "numberOfItems": <?= count($allVideos) ?>,
    "itemListElement": [
        <?php foreach ($allVideos as $index => $video):
            $videoUrls = getVideoUrls($video, BASE_URL);
            ?>
            {
                "@type": "ListItem",
                "position": <?= $index + 1 ?>,
                "url": "<?= htmlspecialchars($videoUrls['pageUrl']) ?>",
                "name": "<?= htmlspecialchars($video['title']) ?>"
            }<?= $index < count($allVideos) - 1 ? ',' : '' ?>
        <?php endforeach; ?>
    ]
}
</script>

<style>
    /* Critical CSS for Video List - Prevents CLS */
    .video-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
        gap: 1.5rem;
    }

    .video-card {
        background: #fff;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        text-decoration: none;
        color: inherit;
        display: block;
    }

    .video-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
    }

    /* CLS Prevention: Fixed aspect ratio for thumbnails */
    .video-thumb-wrapper {
        position: relative;
        aspect-ratio: 16 / 9;
        background: #1a1a2e;
        overflow: hidden;
    }

    .video-thumb {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    /* Play button overlay */
    .play-overlay {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 64px;
        height: 64px;
        background: rgba(255, 0, 0, 0.9);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s ease, background 0.2s ease;
    }

    .video-card:hover .play-overlay {
        transform: translate(-50%, -50%) scale(1.1);
        background: rgba(255, 0, 0, 1);
    }

    .play-overlay svg {
        width: 28px;
        height: 28px;
        fill: #fff;
        margin-left: 4px;
    }

    .video-duration {
        position: absolute;
        bottom: 8px;
        right: 8px;
        background: rgba(0, 0, 0, 0.8);
        color: #fff;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 0.75rem;
        font-weight: 500;
    }

    .video-info {
        padding: 1rem;
    }

    .video-title {
        font-size: 1rem;
        font-weight: 600;
        color: #1a1a2e;
        margin: 0 0 0.5rem;
        line-height: 1.4;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .video-excerpt {
        font-size: 0.875rem;
        color: #666;
        margin: 0;
        line-height: 1.5;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .video-meta {
        display: flex;
        gap: 1rem;
        margin-top: 0.75rem;
        font-size: 0.75rem;
        color: #999;
    }

    .video-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin-top: 0.75rem;
    }

    .video-tag {
        background: #f0f4f8;
        color: #1a1a2e;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.7rem;
    }

    /* Hero Section */
    .videos-hero {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        padding: 3rem 0;
        color: #fff;
        text-align: center;
    }

    .videos-hero h1 {
        font-size: 2rem;
        font-weight: 700;
        margin: 0 0 0.5rem;
    }

    .videos-hero p {
        font-size: 1rem;
        opacity: 0.9;
        margin: 0;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
    }

    /* SEO Content Sections */
    .seo-section {
        background: #f8fafc;
        padding: 3rem 0;
        margin-top: 2rem;
    }

    .seo-section h2 {
        font-size: 1.5rem;
        color: #1a1a2e;
        margin-bottom: 1rem;
    }

    .seo-section p {
        color: #4a5568;
        line-height: 1.8;
        margin-bottom: 1rem;
    }

    .keyword-list {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        margin-top: 1rem;
    }

    .keyword-item {
        background: #e2e8f0;
        color: #2d3748;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.875rem;
    }

    .related-links {
        list-style: none;
        padding: 0;
        margin: 1rem 0 0;
    }

    .related-links li {
        margin-bottom: 0.5rem;
    }

    .related-links a {
        color: #2563eb;
        text-decoration: none;
    }

    .related-links a:hover {
        text-decoration: underline;
    }

    @media (max-width: 768px) {
        .video-grid {
            grid-template-columns: 1fr;
            gap: 1rem;
        }

        .videos-hero {
            padding: 2rem 0;
        }

        .videos-hero h1 {
            font-size: 1.5rem;
        }

        .seo-section {
            padding: 2rem 0;
        }
    }
</style>

<!-- Hero Section -->
<section class="videos-hero">
    <div class="container">
        <h1>วิดีโอรีวิวมือถือมือสอง PG Mobile</h1>
        <p>รวมวิดีโอรีวิวจริงจากร้าน PG Mobile ดูก่อนตัดสินใจซื้อ มือถือคุณภาพดี ราคาถูก รับประกัน 30 วัน</p>
    </div>
</section>

<!-- Breadcrumb -->
<nav class="container py-3" aria-label="breadcrumb">
    <ol class="breadcrumb mb-0" style="font-size: 0.875rem;">
        <li class="breadcrumb-item"><a href="index.php">หน้าแรก</a></li>
        <li class="breadcrumb-item active" aria-current="page">วิดีโอ</li>
    </ol>
</nav>

<!-- Video List -->
<section class="container pb-4">
    <?php if (empty($allVideos)): ?>
        <div class="text-center py-5">
            <p class="text-muted">ยังไม่มีวิดีโอในขณะนี้</p>
        </div>
    <?php else: ?>
        <div class="video-grid">
            <?php foreach ($allVideos as $video):
                $videoUrls = getVideoUrls($video, BASE_URL);
                ?>
                <a href="video.php?slug=<?= urlencode($video['slug']) ?>" class="video-card"
                    title="<?= htmlspecialchars($video['title']) ?>">
                    <div class="video-thumb-wrapper">
                        <!-- 
                            LCP Optimization: 
                            - ใช้ hqdefault แทน maxresdefault เพื่อโหลดเร็วกว่า
                            - loading="eager" สำหรับวิดีโอแรก
                        -->
                        <img src="<?= htmlspecialchars($videoUrls['thumbnailUrl']) ?>"
                            alt="<?= htmlspecialchars($video['title']) ?>" class="video-thumb" width="480" height="360"
                            loading="<?= $video['order'] === 1 ? 'eager' : 'lazy' ?>" decoding="async">
                        <div class="play-overlay" aria-hidden="true">
                            <svg viewBox="0 0 24 24">
                                <path d="M8 5v14l11-7z" />
                            </svg>
                        </div>
                        <span class="video-duration"><?= htmlspecialchars($video['durationDisplay']) ?></span>
                    </div>
                    <div class="video-info">
                        <h2 class="video-title"><?= htmlspecialchars($video['shortTitle'] ?? $video['title']) ?></h2>
                        <p class="video-excerpt"><?= htmlspecialchars($video['excerpt'] ?? $video['description']) ?></p>
                        <div class="video-meta">
                            <span>📅 <?= htmlspecialchars($video['publishedDateDisplay']) ?></span>
                        </div>
                        <?php if (!empty($video['tags'])): ?>
                            <div class="video-tags">
                                <?php foreach (array_slice($video['tags'], 0, 3) as $tag): ?>
                                    <span class="video-tag"><?= htmlspecialchars($tag) ?></span>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<!-- SEO Content Section -->
<section class="seo-section">
    <div class="container">
        <h2>เกี่ยวกับวิดีโอรีวิว PG Mobile</h2>
        <p>
            ยินดีต้อนรับสู่หน้ารวมวิดีโอรีวิวมือถือมือสองจากร้าน PG Mobile จังหวัดสกลนคร
            เราได้รวบรวมวิดีโอรีวิวสินค้าทั้งหมดไว้ที่นี่
            เพื่อให้คุณได้ดูรีวิวจริงก่อนตัดสินใจซื้อ ทุกวิดีโอแสดงให้เห็นถึงคุณภาพของสินค้า กระบวนการตรวจสอบ
            และการรับประกันที่เราให้กับลูกค้าทุกท่าน
        </p>
        <p>
            มือถือมือสองจาก PG Mobile ทุกเครื่องผ่านการตรวจสอบคุณภาพ QC 100% ก่อนจัดส่ง รับประกัน 30 วันเต็ม
            จัดส่งฟรีทั่วประเทศ รองรับเก็บเงินปลายทาง (COD) ไม่ต้องโอนเงินก่อน
        </p>

        <h3 style="margin-top: 2rem; font-size: 1.25rem;">คำค้นที่เกี่ยวข้อง</h3>
        <div class="keyword-list">
            <span class="keyword-item">รีวิวมือถือมือสอง</span>
            <span class="keyword-item">PG Mobile V9</span>
            <span class="keyword-item">มือถือราคาถูก</span>
            <span class="keyword-item">รับประกัน 30 วัน</span>
            <span class="keyword-item">มือถือสกลนคร</span>
            <span class="keyword-item">ซื้อมือถือออนไลน์</span>
            <span class="keyword-item">เก็บเงินปลายทาง</span>
            <span class="keyword-item">มือถือคุณภาพดี</span>
        </div>

        <h3 style="margin-top: 2rem; font-size: 1.25rem;">หน้าที่เกี่ยวข้อง</h3>
        <ul class="related-links">
            <li><a href="index.php">หน้าแรก PG Mobile - ดูสินค้าทั้งหมด</a></li>
            <li><a href="about.php">เกี่ยวกับเรา - ประวัติร้าน PG Mobile</a></li>
            <li><a href="warranty.php">นโยบายรับประกัน - การรับประกัน 30 วัน</a></li>
            <li><a href="faq.php">คำถามที่พบบ่อย - FAQ</a></li>
            <li><a href="contact.php">ติดต่อเรา - ช่องทางการติดต่อ</a></li>
            <li><a href="blog.php">บทความ - ความรู้เกี่ยวกับมือถือ</a></li>
        </ul>
    </div>
</section>

<?php include 'includes/footer.php'; ?>