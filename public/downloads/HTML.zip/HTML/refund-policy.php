<?php
require_once 'config.php';

$pageTitle = 'นโยบายคืนสินค้า/เปลี่ยนสินค้า/รับประกัน - ' . SITE_NAME;
$pageDescription = 'นโยบายการคืนสินค้า เปลี่ยนสินค้า และการรับประกันสินค้า PG Mobile เงื่อนไขครบถ้วน โปร่งใส มั่นใจทุกการสั่งซื้อ';
$pageKeywords = 'นโยบายคืนสินค้า, เปลี่ยนสินค้า, รับประกัน, refund policy, PG Mobile';
$canonicalPath = '/refund-policy.php';

require_once 'includes/header.php';
?>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <h1>นโยบายคืนสินค้า/เปลี่ยนสินค้า/รับประกัน</h1>
        <p>เงื่อนไขและขั้นตอนการคืน-เปลี่ยนสินค้า และการรับประกัน</p>
    </div>
</section>

<!-- Policy Content -->
<section class="section">
    <div class="container">
        <div class="legal-content" style="max-width:900px; margin:0 auto;">

            <p class="text-muted mb-4">
                <strong>วันที่มีผลบังคับใช้:</strong> 1 มกราคม 2026<br>
                <strong>ปรับปรุงล่าสุด:</strong>
                <?= date('j F Y') ?>
            </p>

            <!-- 1. เงื่อนไขการรับประกัน -->
            <div class="policy-section mb-5">
                <h2 class="h4 mb-3">🛡️ 1. เงื่อนไขการรับประกัน</h2>

                <h5 class="mt-4">1.1 ระยะเวลารับประกัน</h5>
                <ul>
                    <li>สินค้าทุกชิ้นได้รับการรับประกัน <strong>30 วัน</strong> นับจากวันที่ได้รับสินค้า
                        (อ้างอิงจากวันที่พัสดุถึงผู้รับตามระบบขนส่ง)</li>
                    <li>การรับประกันครอบคลุมเฉพาะสินค้าที่ซื้อผ่านช่องทางของร้าน
                        <?= SITE_NAME ?> เท่านั้น
                    </li>
                </ul>

                <h5 class="mt-4">1.2 สิ่งที่รับประกันครอบคลุม</h5>
                <ul>
                    <li>ปัญหาฮาร์ดแวร์จากการใช้งานปกติ เช่น หน้าจอค้าง, ลำโพงไม่ดัง, ไมค์ไม่ทำงาน</li>
                    <li>ปัญหาการชาร์จไฟ เช่น ชาร์จไม่เข้า, แบตเตอรี่เสื่อมเร็วผิดปกติ</li>
                    <li>ปุ่มกดไม่ทำงาน หรือทำงานผิดปกติ</li>
                    <li>กล้องไม่ทำงาน หรือภาพเบลอผิดปกติ</li>
                    <li>สัญญาณ Wi-Fi / Bluetooth / เครือข่ายมีปัญหา</li>
                </ul>

                <h5 class="mt-4">1.3 สิ่งที่ไม่อยู่ในการรับประกัน</h5>
                <ul>
                    <li>ความเสียหายจากการตกกระแทก หรือแรงกดทับ</li>
                    <li>ความเสียหายจากน้ำ ของเหลว หรือความชื้น</li>
                    <li>หน้าจอแตก หน้าจอร้าว หรือรอยขีดข่วนบนตัวเครื่อง</li>
                    <li>เครื่องถูกถอดประกอบ ดัดแปลง หรือซ่อมโดยบุคคลอื่นที่ไม่ใช่ทางร้าน</li>
                    <li>ความเสียหายจากไวรัส มัลแวร์ หรือการติดตั้งซอฟต์แวร์ผิดกฎหมาย</li>
                    <li>อุปกรณ์เสริมที่แถมไปกับเครื่อง เช่น สายชาร์จ, หูฟัง, เคส</li>
                    <li>ความเสียหายจากภัยธรรมชาติ หรือเหตุสุดวิสัย</li>
                </ul>
            </div>

            <!-- 2. เงื่อนไขการเปลี่ยน/คืนสินค้า -->
            <div class="policy-section mb-5">
                <h2 class="h4 mb-3">🔄 2. เงื่อนไขการเปลี่ยน/คืนสินค้า</h2>

                <h5 class="mt-4">2.1 การเปลี่ยนสินค้า</h5>
                <ul>
                    <li>สามารถแจ้งขอเปลี่ยนสินค้าได้ภายใน <strong>7 วัน</strong> นับจากวันที่ได้รับสินค้า</li>
                    <li>สินค้าต้องอยู่ในสภาพเดิม ไม่มีรอยตำหนิเพิ่มเติมจากการใช้งาน</li>
                    <li>ต้องมีกล่อง อุปกรณ์ และของแถมครบถ้วนตามที่ได้รับ</li>
                    <li>กรณีสินค้าไม่ตรงตามที่สั่ง หรือมีตำหนิจากการผลิต ทางร้านรับผิดชอบค่าส่งทั้งหมด</li>
                </ul>

                <h5 class="mt-4">2.2 การคืนสินค้า</h5>
                <ul>
                    <li>สามารถแจ้งขอคืนสินค้าได้ภายใน <strong>7 วัน</strong> นับจากวันที่ได้รับสินค้า</li>
                    <li>สินค้าต้องอยู่ในสภาพเดิม ไม่ถูกเปิดใช้งาน หรือมีร่องรอยการใช้งาน</li>
                    <li>หากสินค้าถูกเปิดใช้งานแล้ว จะไม่สามารถคืนสินค้าได้ ยกเว้นกรณีสินค้าชำรุด</li>
                    <li>การคืนเงินจะดำเนินการภายใน <strong>7-14 วันทำการ</strong>
                        หลังจากได้รับสินค้าคืนและตรวจสอบเรียบร้อยแล้ว</li>
                </ul>

                <h5 class="mt-4">2.3 เอกสารที่ต้องใช้</h5>
                <ul>
                    <li>หลักฐานการสั่งซื้อ (ใบเสร็จ, หลักฐานการโอนเงิน, แชทการสั่งซื้อ)</li>
                    <li>รูปถ่ายหรือวิดีโอแสดงปัญหาของสินค้า (กรณีสินค้าชำรุด)</li>
                    <li>หมายเลขพัสดุและวันที่ได้รับสินค้า</li>
                </ul>
            </div>

            <!-- 3. ขั้นตอนการเคลม -->
            <div class="policy-section mb-5">
                <h2 class="h4 mb-3">📋 3. ขั้นตอนการเคลมสินค้า</h2>

                <div class="step-list">
                    <div class="step-item d-flex mb-3">
                        <div class="step-number bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width:36px;height:36px;flex-shrink:0;">1</div>
                        <div class="ms-3">
                            <strong>แจ้งปัญหา</strong><br>
                            ติดต่อแจ้งปัญหาพร้อมแนบหลักฐานผ่านช่องทาง LINE, Facebook หรือโทรศัพท์
                        </div>
                    </div>
                    <div class="step-item d-flex mb-3">
                        <div class="step-number bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width:36px;height:36px;flex-shrink:0;">2</div>
                        <div class="ms-3">
                            <strong>รอการยืนยัน</strong><br>
                            ทีมงานจะตรวจสอบและยืนยันสิทธิ์การเคลมภายใน 1-2 วันทำการ
                        </div>
                    </div>
                    <div class="step-item d-flex mb-3">
                        <div class="step-number bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width:36px;height:36px;flex-shrink:0;">3</div>
                        <div class="ms-3">
                            <strong>ส่งสินค้า</strong><br>
                            แพ็คสินค้าอย่างมิดชิดแล้วส่งมาที่ที่อยู่ร้าน (ทางร้านจะแจ้งที่อยู่ให้)
                        </div>
                    </div>
                    <div class="step-item d-flex mb-3">
                        <div class="step-number bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width:36px;height:36px;flex-shrink:0;">4</div>
                        <div class="ms-3">
                            <strong>ตรวจสอบ</strong><br>
                            ช่างผู้ชำนาญจะตรวจสอบสินค้าภายใน 3-5 วันทำการ
                        </div>
                    </div>
                    <div class="step-item d-flex mb-3">
                        <div class="step-number bg-primary text-white rounded-circle d-flex align-items-center justify-content-center"
                            style="width:36px;height:36px;flex-shrink:0;">5</div>
                        <div class="ms-3">
                            <strong>ดำเนินการ</strong><br>
                            ซ่อม/เปลี่ยน/คืนเงิน ตามผลการตรวจสอบ แล้วส่งกลับให้ลูกค้า
                        </div>
                    </div>
                </div>
            </div>

            <!-- 4. ค่าจัดส่งกรณีเคลม -->
            <div class="policy-section mb-5">
                <h2 class="h4 mb-3">📦 4. ค่าจัดส่งกรณีเคลม</h2>

                <table class="table table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th>กรณี</th>
                            <th>ค่าส่งขาไป</th>
                            <th>ค่าส่งขากลับ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>สินค้าชำรุดจากการผลิต/ไม่ตรงปก</td>
                            <td class="text-success">ร้านรับผิดชอบ</td>
                            <td class="text-success">ร้านรับผิดชอบ</td>
                        </tr>
                        <tr>
                            <td>ลูกค้าเปลี่ยนใจ/สั่งผิดรุ่น</td>
                            <td class="text-warning">ลูกค้ารับผิดชอบ</td>
                            <td class="text-success">ร้านรับผิดชอบ</td>
                        </tr>
                        <tr>
                            <td>เคลมในประกันปกติ</td>
                            <td class="text-success">ร้านรับผิดชอบ</td>
                            <td class="text-success">ร้านรับผิดชอบ</td>
                        </tr>
                        <tr>
                            <td>ซ่อมนอกประกัน (ลูกค้าร้องขอ)</td>
                            <td class="text-warning">ลูกค้ารับผิดชอบ</td>
                            <td class="text-warning">ลูกค้ารับผิดชอบ</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- 5. ข้อยกเว้น -->
            <div class="policy-section mb-5">
                <h2 class="h4 mb-3">⚠️ 5. ข้อยกเว้นสำคัญ</h2>

                <div class="alert alert-warning">
                    <strong>กรณีต่อไปนี้ไม่สามารถเคลมประกันได้:</strong>
                </div>

                <ul>
                    <li><strong>ตกน้ำ/ของเหลวเข้า:</strong> รวมถึงความชื้น หยดน้ำ เหงื่อ หรือของเหลวทุกชนิด</li>
                    <li><strong>หน้าจอแตก/ร้าว:</strong> ความเสียหายจากแรงกระแทกทุกกรณี</li>
                    <li><strong>ดัดแปลงเครื่อง:</strong> ถอดประกอบ, Root/Jailbreak, เปลี่ยนอะไหล่เอง</li>
                    <li><strong>อะไหล่และอุปกรณ์เสริม:</strong> สายชาร์จ, หูฟัง, เคส, ฟิล์มกระจก</li>
                    <li><strong>ซอฟต์แวร์:</strong> ไวรัส, แอปค้าง, ลืมรหัสผ่าน, บัญชี iCloud/Google</li>
                    <li><strong>ความเสื่อมตามอายุการใช้งาน:</strong> แบตเตอรี่เสื่อมตามปกติ (หลังระยะประกัน)</li>
                </ul>
            </div>

            <!-- 6. เวลาทำการ -->
            <div class="policy-section mb-5">
                <h2 class="h4 mb-3">🕐 6. เวลาทำการและระยะเวลาดำเนินการ</h2>

                <h5 class="mt-4">เวลาทำการ</h5>
                <ul>
                    <li><strong>วันจันทร์ - อาทิตย์:</strong> 09:00 - 21:00 น.</li>
                    <li><strong>วันหยุดนักขัตฤกษ์:</strong> เปิดให้บริการตามปกติ (ยกเว้นวันหยุดพิเศษที่จะแจ้งล่วงหน้า)
                    </li>
                </ul>

                <h5 class="mt-4">ระยะเวลาดำเนินการ</h5>
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <td>ตอบกลับการแจ้งเคลม</td>
                            <td>ภายใน 1-2 วันทำการ</td>
                        </tr>
                        <tr>
                            <td>ตรวจสอบสินค้า</td>
                            <td>3-5 วันทำการ หลังได้รับสินค้า</td>
                        </tr>
                        <tr>
                            <td>ซ่อม/เปลี่ยนสินค้า</td>
                            <td>5-7 วันทำการ (ขึ้นอยู่กับอาการ)</td>
                        </tr>
                        <tr>
                            <td>คืนเงิน</td>
                            <td>7-14 วันทำการ หลังอนุมัติ</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- ช่องทางติดต่อ -->
            <div class="policy-section mb-5">
                <h2 class="h4 mb-3">📞 ช่องทางติดต่อเคลมสินค้า</h2>

                <div class="contact-info p-4 bg-light rounded">
                    <p class="mb-2"><strong>โทรศัพท์:</strong> <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>">
                            <?= COMPANY_PHONE ?>
                        </a></p>
                    <p class="mb-2"><strong>อีเมล:</strong> <a href="mailto:<?= COMPANY_EMAIL ?>">
                            <?= COMPANY_EMAIL ?>
                        </a></p>
                    <p class="mb-2"><strong>LINE:</strong> <a href="https://lin.ee/EAtjlIe" target="_blank"
                            rel="noopener">@pgmobile</a></p>
                    <p class="mb-2"><strong>Facebook:</strong> <a href="https://www.facebook.com/pgmobiles"
                            target="_blank" rel="noopener">facebook.com/pgmobiles</a></p>
                    <p class="mb-0"><strong>ที่อยู่:</strong>
                        <?= COMPANY_ADDRESS ?>
                    </p>
                </div>
            </div>

            <!-- สรุปท้ายหน้า -->
            <div class="policy-section">
                <h2 class="h4 mb-3">📌 สรุปเงื่อนไขสำคัญ</h2>

                <div class="alert alert-info">
                    <ul class="mb-0">
                        <li>✅ รับประกัน <strong>30 วัน</strong> สำหรับปัญหาฮาร์ดแวร์จากการใช้งานปกติ</li>
                        <li>✅ เปลี่ยน/คืนสินค้าได้ภายใน <strong>7 วัน</strong> นับจากวันที่ได้รับ</li>
                        <li>✅ ค่าส่งเคลมใน กรณีสินค้าชำรุด <strong>ร้านรับผิดชอบทั้งหมด</strong></li>
                        <li>✅ คืนเงินภายใน <strong>7-14 วันทำการ</strong> หลังอนุมัติ</li>
                        <li>❌ ไม่รับประกัน: ตกน้ำ, หน้าจอแตก, ดัดแปลงเครื่อง, อะไหล่</li>
                        <li>📞 ติดต่อเคลมได้ทุกวัน <strong>09:00 - 21:00 น.</strong></li>
                    </ul>
                </div>
            </div>

            <hr class="my-5">

            <p class="text-muted small">
                <strong>หมายเหตุ:</strong> ทางร้านขอสงวนสิทธิ์ในการเปลี่ยนแปลงเงื่อนไขโดยไม่ต้องแจ้งล่วงหน้า
                การพิจารณารับประกันขึ้นอยู่กับการตรวจสอบของช่างผู้ชำนาญ และเป็นไปตามดุลยพินิจของทางร้าน
            </p>

        </div>
    </div>
</section>

<!-- CTA -->
<section class="cta-section">
    <div class="container">
        <h2>มีคำถามเกี่ยวกับการคืนสินค้า/รับประกัน?</h2>
        <p>ติดต่อเราได้ตลอดเวลา เรายินดีให้บริการ!</p>
        <div class="cta-buttons">
            <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>" class="btn btn-primary">โทรหาเรา
                <?= COMPANY_PHONE ?>
            </a>
            <a href="contact.php" class="btn btn-outline">ติดต่อเรา</a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>