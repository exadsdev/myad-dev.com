<?php
declare(strict_types=1);

/**
 * =====================================================
 * Gallery (IMG-PROXY ONLY / NO BOT / DOMAIN FROM settings.json)
 * =====================================================
 */

// -----------------------------------------------------
// 1) ป้องกัน Cache หน้า HTML
// -----------------------------------------------------
require_once __DIR__ . '/includes/no-cache.php';

// -----------------------------------------------------
// 2) Helper: Escape HTML
// -----------------------------------------------------
function h($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

// -----------------------------------------------------
// 3) URL Sanitize
// -----------------------------------------------------
function sanitize_http_url(string $url): string
{
    $url = trim($url);
    if ($url === '') return '';

    $url = str_replace(["\r", "\n"], '', $url);
    $p = parse_url($url);

    if (!$p || empty($p['scheme']) || empty($p['host'])) return '';

    $scheme = strtolower((string)$p['scheme']);
    if (!in_array($scheme, ['http', 'https'], true)) return '';

    return $url;
}

// -----------------------------------------------------
// 4) อ่าน target URL จาก settings.json (shop_url)
// -----------------------------------------------------
$settingsFile = __DIR__ . '/data/settings.json';

// ❗ ตั้งค่า fallback เผื่อ settings.json ไม่มี/พัง
$defaultUrl  = 'https://workshop.pgphone-thai.shop';

function get_target_url(string $settingsFile, string $defaultUrl): string
{
    $defaultUrl = sanitize_http_url($defaultUrl);

    if (!is_file($settingsFile)) return $defaultUrl;

    $raw = @file_get_contents($settingsFile);
    if ($raw === false || trim($raw) === '') return $defaultUrl;

    $json = json_decode($raw, true);
    if (!is_array($json)) return $defaultUrl;

    // ใช้โดเมน/ลิงก์ที่คุณบันทึกไว้
    $url = sanitize_http_url((string)($json['shop_url'] ?? ''));

    return $url !== '' ? $url : $defaultUrl;
}

$target_url = get_target_url($settingsFile, $defaultUrl);

// -----------------------------------------------------
// 5) ดึง origin จาก target_url เพื่อเอา "โดเมน" ไปประกอบรูป
//    เช่น https://workshop.pgphone-thai.shop
// -----------------------------------------------------
function get_origin(string $url): string
{
    if ($url === '') return '';
    $p = parse_url($url);
    if (!$p || empty($p['scheme']) || empty($p['host'])) return '';

    $origin = strtolower((string)$p['scheme']) . '://' . $p['host'];
    if (!empty($p['port'])) {
        $origin .= ':' . $p['port'];
    }
    return $origin;
}

$origin = get_origin($target_url);

// -----------------------------------------------------
// 6) IMG PROXY BASE (ต้องเป็นโดเมนจาก settings.json เสมอ)
// -----------------------------------------------------
$img_proxy_base = ($origin !== '')
    ? $origin . '/img-proxy.php?f='
    : '/img-proxy.php?f='; // fallback สุดท้ายจริงๆ

// กันแคชรูป
$assetVersion = substr(sha1((string)time()), 0, 10);

$alt_text   = 'PG Phone V9';
$url_suffix = '&ref=mobile';
?>

<link rel="stylesheet" href="home.css">

<div class="gallery-wrap">
<?php for ($i = 1; $i <= 6; $i++): ?>
<?php
    // ✅ รูปแบบที่คุณต้องการ:
    // https://workshop.pgphone-thai.shop/img-proxy.php?f=1.gif&v=xxxx
    $img_src = $img_proxy_base . $i . '.gif&v=' . $assetVersion;

    // ลิงก์ปลายทาง (คงเดิม)
    if ($target_url !== '') {
        $sep = (strpos($target_url, '?') !== false) ? '&' : '?';
        $final_link = $target_url . $sep . 'id=' . $i . $url_suffix;
    } else {
        $final_link = '#';
    }
?>
    <a href="<?= h($final_link) ?>" class="img-box" <?= $target_url !== '' ? 'target="_blank" rel="noopener"' : '' ?>>
        <img src="<?= h($img_src) ?>" alt="<?= h($alt_text . ' ' . $i) ?>" loading="lazy">
    </a>
<?php endfor; ?>
</div>

<!-- ✅ แสดงทุกคน ไม่มีแยก bot/human -->
<div class="sticky-footer">
<?php
    $sep = ($target_url !== '' && strpos($target_url, '?') !== false) ? '&' : '?';
    $btn_link = ($target_url !== '') ? $target_url . $sep . 'id=register' . $url_suffix : '#';
?>
    <a href="<?= h($btn_link) ?>" target="_blank" rel="noopener" class="btn-register">
        สมัคร / สั่งซื้อทันที
    </a>
</div>
