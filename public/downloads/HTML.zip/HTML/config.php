<?php
/**
 * PG Mobile - Configuration File
 */

// Base URL - เปลี่ยนเป็น URL จริงของคุณเมื่อ deploy
define('BASE_URL', 'https://pgphone-thai.shop');

// Site Info
define('SITE_NAME', 'PG Mobile');
define('SITE_TAGLINE', 'ร้านขายมือถือมือสอง คุณภาพดี ราคาถูก');
define('SITE_DESCRIPTION', 'PG Mobile ร้านขายมือถือมือสอง คุณภาพดี ราคาถูก รับประกันสินค้าทุกเครื่อง ส่งฟรีทั่วประเทศ');

// Company Info
define('COMPANY_NAME', 'PG MOBILE LIMITED PARTNERSHIP');
define('COMPANY_NAME_TH', 'ห้างหุ้นส่วนจำกัด พีจี โมบาย');
define('COMPANY_ADDRESS', '183 หมู่ที่ 1 ตำบลคำตากล้า อำเภอคำตากล้า จ.สกลนคร 47250');
define('COMPANY_REGISTRATION', '0473560000846');
define('COMPANY_PHONE', '093-564-9111');
define('COMPANY_EMAIL', 'admin@pgmobilev9.com');

// Social Media
define('FACEBOOK_URL', 'https://www.facebook.com/pgmobilev9');
define('LINE_ID', '@pgmobile');

// Image Paths
define('IMG_PATH', 'images/');
define('FAVICON', IMG_PATH . 'favicon.ico');
define('LOGO', IMG_PATH . 'logo.png');
define('OG_IMAGE', IMG_PATH . 'og-main.png');

// Google Maps Embed
define('GOOGLE_MAPS_EMBED', '<iframe title="แผนที่ร้าน PG Mobile" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3797.7215419938907!2d103.761095975818!3d17.851683889262585!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x313b470030665087%3A0x8119614a066b6a61!2spg%20mobile!5e0!3m2!1sth!2sth!4v1767750733748!5m2!1sth!2sth" width="100%" height="300" style="border:0;border-radius:12px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>');

/**
 * Auto-detect images in a directory
 * @param string $dir Directory path
 * @param array $extensions Allowed extensions
 * @return array Array of image paths
 */
function getImages($dir = 'images/', $extensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'])
{
    $images = [];
    $basePath = __DIR__ . '/' . $dir;

    if (!is_dir($basePath)) {
        return $images;
    }

    $files = scandir($basePath);
    foreach ($files as $file) {
        if ($file === '.' || $file === '..')
            continue;

        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (in_array($ext, $extensions)) {
            // Skip favicon, logo, og-image
            if (!in_array($file, ['favicon.ico', 'logo.png', 'og-main.png', 'Commercial-registration.jpg'])) {
                $images[] = $dir . $file;
            }
        }
    }

    // Sort by filename
    sort($images);
    return $images;
}

/**
 * Get hero image (first product image)
 */
function getHeroImage()
{
    $images = getImages();
    return !empty($images) ? $images[0] : LOGO;
}

/**
 * Get gallery images (all except first)
 */
function getGalleryImages()
{
    $images = getImages();
    if (count($images) > 1) {
        return array_slice($images, 1);
    }
    return $images;
}

/**
 * Get review images
 */
function getReviewImages()
{
    return getImages('images/review/');
}

/**
 * Get new arrival images
 */
function getNewArrivalImages()
{
    $images = [];
    $dir = 'images/';
    $basePath = __DIR__ . '/' . $dir;

    if (!is_dir($basePath)) {
        return $images;
    }

    for ($i = 1; $i <= 9; $i++) {
        $images[] = $dir . 'pg-v9-' . $i . '.jpg';
    }

    return $images;
}

/**
 * Current page URL
 */
function getCurrentURL()
{
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    return $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}

/**
 * Active page class
 */
function isActivePage($page)
{
    $currentPage = basename($_SERVER['PHP_SELF'], '.php');
    return ($currentPage === $page) ? 'active' : '';
}
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', '1122');

