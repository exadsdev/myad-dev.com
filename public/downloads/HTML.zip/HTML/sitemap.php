<?php
/**
 * Dynamic Sitemap Generator with Video Support
 * Generates XML sitemap including video sitemap extension
 * URL: /sitemap.xml (via .htaccess rewrite)
 * 
 * Features:
 * - Standard sitemap entries for all pages
 * - Video sitemap extension with full video metadata
 * - Uses BASE_URL from config.php for domain
 */
require_once 'config.php';
require_once 'data/videos.php';

header('Content-Type: application/xml; charset=utf-8');

// Standard pages
$pages = [
    ['loc' => '/', 'priority' => '1.0', 'changefreq' => 'daily'],
    ['loc' => '/about.php', 'priority' => '0.8', 'changefreq' => 'monthly'],
    ['loc' => '/contact.php', 'priority' => '0.8', 'changefreq' => 'monthly'],
    ['loc' => '/warranty.php', 'priority' => '0.7', 'changefreq' => 'monthly'],
    ['loc' => '/terms.php', 'priority' => '0.5', 'changefreq' => 'yearly'],
    ['loc' => '/privacy.php', 'priority' => '0.5', 'changefreq' => 'yearly'],
    ['loc' => '/blog.php', 'priority' => '0.8', 'changefreq' => 'weekly'],
    ['loc' => '/faq.php', 'priority' => '0.7', 'changefreq' => 'monthly'],
    ['loc' => '/refund-policy.php', 'priority' => '0.6', 'changefreq' => 'monthly'],
    ['loc' => '/videos.php', 'priority' => '0.9', 'changefreq' => 'weekly'],
];

// Get all videos
$allVideos = getSortedVideos();

$lastmod = date('Y-m-d');

// Output XML
echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
    xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">
    <?php foreach ($pages as $page): ?>
        <url>
            <loc><?= htmlspecialchars(BASE_URL . $page['loc']) ?></loc>
            <lastmod><?= $lastmod ?></lastmod>
            <changefreq><?= $page['changefreq'] ?></changefreq>
            <priority><?= $page['priority'] ?></priority>
        </url>
    <?php endforeach; ?>
    <?php foreach ($allVideos as $video):
        $videoUrls = getVideoUrls($video, BASE_URL);
        ?>
        <url>
            <loc><?= htmlspecialchars($videoUrls['pageUrl']) ?></loc>
            <lastmod><?= date('Y-m-d', strtotime($video['uploadDate'])) ?></lastmod>
            <changefreq>monthly</changefreq>
            <priority>0.9</priority>
            <video:video>
                <video:thumbnail_loc><?= htmlspecialchars($videoUrls['thumbnailUrl']) ?></video:thumbnail_loc>
                <video:title><?= htmlspecialchars($video['title']) ?></video:title>
                <video:description><?= htmlspecialchars($video['description']) ?></video:description>
                <video:player_loc allow_embed="yes"><?= htmlspecialchars($videoUrls['embedUrl']) ?></video:player_loc>
                <video:content_loc><?= htmlspecialchars($videoUrls['contentUrl']) ?></video:content_loc>
                <video:duration><?= $video['durationSeconds'] ?></video:duration>
                <video:publication_date><?= $video['uploadDate'] ?></video:publication_date>
                <video:family_friendly>yes</video:family_friendly>
                <video:live>no</video:live>
                <?php if (!empty($video['tags'])): ?>
                    <video:tag><?= htmlspecialchars(implode(', ', $video['tags'])) ?></video:tag>
                <?php endif; ?>
            </video:video>
        </url>
    <?php endforeach; ?>
</urlset>