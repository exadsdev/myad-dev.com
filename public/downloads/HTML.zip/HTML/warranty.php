<?php
require_once 'config.php';

$pageTitle = 'การรับประกันสินค้า - ' . SITE_NAME;
$pageDescription = 'เงื่อนไขการรับประกันสินค้ามือถือมือสอง PG Mobile รับประกัน 30 วัน ครอบคลุมปัญหาจากการใช้งานปกติ';
$pageKeywords = 'รับประกันมือถือ, warranty, เงื่อนไขการรับประกัน, PG Mobile';
$canonicalPath = '/warranty.php';

require_once 'includes/header.php';
?>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <h1>การรับประกันสินค้า</h1>
        <p>เงื่อนไขและขอบเขตการรับประกันสินค้า</p>
    </div>
</section>

<!-- Warranty Content -->
<section class="section">
    <div class="container">
        <div class="warranty-grid">
            <div class="warranty-card">
                <h3>🛡️ ระยะเวลารับประกัน</h3>
                <p>รับประกันสินค้าทุกเครื่อง 30 วัน นับจากวันที่ได้รับสินค้า (ตามเลขพัสดุขนส่ง)</p>
            </div>

            <div class="warranty-card">
                <h3>✅ สิ่งที่รับประกัน</h3>
                <p>ปัญหาจากการใช้งานปกติ เช่น หน้าจอค้าง, ลำโพงไม่ดัง, ชาร์จไม่เข้า, ปุ่มไม่ทำงาน,
                    และปัญหาฮาร์ดแวร์อื่นๆ ที่ไม่ได้เกิดจากการใช้งานผิดวิธี</p>
            </div>

            <div class="warranty-card">
                <h3>❌ สิ่งที่ไม่รับประกัน</h3>
                <p>ความเสียหายจากการตก, น้ำเข้า, ถอดประกอบเอง, ติดไวรัส, หรือความเสียหายจากการใช้งานผิดวิธีทุกกรณี</p>
            </div>

            <div class="warranty-card">
                <h3>📋 ขั้นตอนการเคลม</h3>
                <p>1. ติดต่อแจ้งปัญหาทางโทรศัพท์หรือแชท<br>2. ส่งสินค้ากลับมาตรวจสอบ<br>3. รอผลการตรวจสอบ 3-5
                    วันทำการ<br>4. รับสินค้าซ่อมคืน หรือเปลี่ยนเครื่องใหม่</p>
            </div>

            <div class="warranty-card">
                <h3>📦 การส่งสินค้าเคลม</h3>
                <p>กรุณาแพ็คสินค้าอย่างมิดชิด และส่งมาที่ที่อยู่ร้าน ค่าส่งขาไป-กลับทางร้านเป็นผู้รับผิดชอบ</p>
            </div>

            <div class="warranty-card">
                <h3>📞 ติดต่อเคลม</h3>
                <p>โทร:
                    <?= COMPANY_PHONE ?><br>อีเมล:
                    <?= COMPANY_EMAIL ?><br>เวลาทำการ: ทุกวัน 09:00-21:00
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Important Notes -->
<section class="section section-alt">
    <div class="container">
        <div class="legal-content">
            <h2>หมายเหตุสำคัญ</h2>
            <ul style="list-style:disc;padding-left:1.5rem;">
                <li>กรุณาเก็บหลักฐานการสั่งซื้อไว้เพื่อใช้ในการเคลมประกัน</li>
                <li>สินค้าต้องอยู่ในสภาพเดิมตามที่ได้รับ ไม่มีการแกะหรือดัดแปลง</li>
                <li>การพิจารณารับประกันขึ้นอยู่กับการตรวจสอบของช่างผู้ชำนาญ</li>
                <li>ทางร้านขอสงวนสิทธิ์ในการเปลี่ยนแปลงเงื่อนไขโดยไม่ต้องแจ้งล่วงหน้า</li>
            </ul>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="cta-section">
    <div class="container">
        <h2>มีคำถามเกี่ยวกับการรับประกัน?</h2>
        <p>ติดต่อเราได้ตลอดเวลา เรายินดีให้บริการ!</p>
        <div class="cta-buttons">
            <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>" class="btn btn-primary">โทรหาเรา
                <?= COMPANY_PHONE ?>
            </a>
            <a href="contact.php" class="btn btn-outline">ติดต่อเรา</a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>