<?php
// tracker.php
// PHP 7.4+
// include ไฟล์นี้แล้วเรียก track_visit(); ในทุกหน้าที่ต้องการเก็บผู้เข้าชม

require_once __DIR__ . '/config.php';

// ==== Fallback constants (ถ้า config.php ของคุณไม่มี) ====
if (!defined('DATA_DIR')) {
    define('DATA_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'data');
}
if (!defined('VISITS_JSON')) {
    define('VISITS_JSON', DATA_DIR . DIRECTORY_SEPARATOR . 'visits.json');
}
if (!defined('CLICKS_JSON')) {
    define('CLICKS_JSON', DATA_DIR . DIRECTORY_SEPARATOR . 'clicks.json');
}
if (!defined('MAX_ROWS_SHOW')) {
    define('MAX_ROWS_SHOW', 200);
}
if (!defined('MAX_STORE_ROWS')) {
    define('MAX_STORE_ROWS', 20000);
}

function ensure_data_storage() {
    if (!is_dir(DATA_DIR)) {
        @mkdir(DATA_DIR, 0755, true);
    }
    if (!file_exists(VISITS_JSON)) {
        @file_put_contents(VISITS_JSON, "[]");
    }
    if (!file_exists(CLICKS_JSON)) {
        @file_put_contents(CLICKS_JSON, "[]");
    }
}

function get_client_ip() {
    $keys = ['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','REMOTE_ADDR'];
    foreach ($keys as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = $_SERVER[$k];
            if ($k === 'HTTP_X_FORWARDED_FOR') {
                $parts = explode(',', $ip);
                $ip = trim($parts[0]);
            }
            return $ip;
        }
    }
    return '0.0.0.0';
}

function get_current_url() {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $uri  = $_SERVER['REQUEST_URI'] ?? '/';
    return $scheme . '://' . $host . $uri;
}

function is_bot_request() {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua === '') return true;

    $bot_keywords = [
        'bot','crawl','spider','slurp','bingpreview','facebookexternalhit',
        'googlebot','bingbot','yandex','duckduckbot','baiduspider','ahrefs',
        'semrush','mj12bot','dotbot','crawler','uptimerobot','headless',
        'python-requests','curl','wget','scrapy','httpclient','postmanruntime',
        'lighthouse','pagespeed','gtmetrix','telegrambot','discordbot','line'
    ];

    foreach ($bot_keywords as $kw) {
        if (strpos($ua, $kw) !== false) return true;
    }

    // ถ้าไม่มี Accept-Language มักเป็นสคริปต์/บอท
    if (empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) return true;

    return false;
}

function safe_json_read($file) {
    ensure_data_storage();

    $fp = @fopen($file, 'c+');
    if (!$fp) return [];

    flock($fp, LOCK_SH);
    $size = filesize($file);
    $raw = ($size > 0) ? fread($fp, $size) : '[]';
    flock($fp, LOCK_UN);
    fclose($fp);

    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function safe_json_write($file, $data) {
    ensure_data_storage();

    $fp = @fopen($file, 'c+');
    if (!$fp) return false;

    flock($fp, LOCK_EX);
    ftruncate($fp, 0);
    rewind($fp);
    $ok = fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    return $ok !== false;
}

function json_append_row($file, $row) {
    $data = safe_json_read($file);
    $data[] = $row;

    $max = (int)MAX_STORE_ROWS;
    if ($max > 0 && count($data) > $max) {
        $data = array_slice($data, -$max);
    }

    return safe_json_write($file, $data);
}

function track_visit() {
    ensure_data_storage();

    $isBot = is_bot_request();
    $row = [
        'time'        => gmdate('c'),
        'ip'          => get_client_ip(),
        'userAgent'   => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'referer'     => $_SERVER['HTTP_REFERER'] ?? '',
        'url'         => get_current_url(),
        'method'      => $_SERVER['REQUEST_METHOD'] ?? 'GET',
        'visitorType' => $isBot ? 'bot' : 'human'
    ];

    json_append_row(VISITS_JSON, $row);
}

function track_click($target, $extra = []) {
    ensure_data_storage();

    $isBot = is_bot_request();
    $row = array_merge([
        'time'        => gmdate('c'),
        'ip'          => get_client_ip(),
        'userAgent'   => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'referer'     => $_SERVER['HTTP_REFERER'] ?? '',
        'url'         => get_current_url(),
        'target'      => (string)$target,
        'visitorType' => $isBot ? 'bot' : 'human'
    ], is_array($extra) ? $extra : []);

    json_append_row(CLICKS_JSON, $row);
}

function count_types($rows) {
    $human = 0; $bot = 0;
    foreach ($rows as $r) {
        $t = $r['visitorType'] ?? 'human';
        if ($t === 'bot') $bot++;
        else $human++;
    }
    return [$human, $bot, $human + $bot];
}

function latest_rows($rows, $limit) {
    $rows = is_array($rows) ? $rows : [];
    $limit = (int)$limit;
    if ($limit <= 0) $limit = 200;
    return array_reverse(array_slice($rows, -$limit));
}
