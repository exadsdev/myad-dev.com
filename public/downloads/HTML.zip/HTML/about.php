<?php
require_once 'config.php';

$pageTitle = 'เกี่ยวกับเรา - ' . SITE_NAME;
$pageDescription = 'รู้จัก PG Mobile ร้านขายมือถือมือสอง คุณภาพดี จดทะเบียนถูกต้อง ให้บริการมากว่า 5 ปี ด้วยความซื่อสัตย์และความใส่ใจในทุกรายละเอียด';
$pageKeywords = 'เกี่ยวกับ PG Mobile, ประวัติร้าน, ร้านมือถือสกลนคร';
$canonicalPath = '/about.php';

require_once 'includes/header.php';
?>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <h1>เกี่ยวกับเรา</h1>
        <p>รู้จักกับ PG Mobile ร้านขายมือถือมือสองคุณภาพดี</p>
    </div>
</section>

<!-- About Content -->
<section class="section">
    <div class="container">
        <div class="about-content">
            <h2>เรื่องราวของ PG Mobile</h2>

            <p>
                <strong>PG Mobile</strong> ก่อตั้งขึ้นด้วยความมุ่งมั่นที่จะมอบมือถือมือสองคุณภาพดี
                ในราคาที่ทุกคนเข้าถึงได้ เราเชื่อว่าทุกคนควรได้ใช้สมาร์ทโฟนที่มีคุณภาพ
                โดยไม่ต้องจ่ายแพงเกินไป
            </p>

            <p>
                เราเริ่มต้นจากร้านเล็กๆ ในจังหวัดสกลนคร ด้วยความรักและความหลงใหลในเทคโนโลยี
                ปัจจุบันเราให้บริการลูกค้ามาแล้วกว่า 5,000 ราย จากทั่วประเทศไทย
                และยังคงเติบโตอย่างต่อเนื่องด้วยความไว้วางใจของลูกค้า
            </p>

            <div class="about-image">
                <img src="images/Commercial-registration.jpg" alt="ใบทะเบียนการค้า PG Mobile" width="800" height="600"
                    loading="lazy">
            </div>

            <h2>ทำไมต้องเลือกเรา</h2>

            <p>
                ทุกเครื่องที่เราขายต้องผ่านการตรวจสอบอย่างละเอียดจากช่างผู้ชำนาญ
                เราตรวจเช็คทั้งสภาพภายนอก การทำงานของระบบ แบตเตอรี่ และลำโพง
                เพื่อให้มั่นใจว่าลูกค้าจะได้รับสินค้าที่พร้อมใช้งานทันที
            </p>

            <p>
                นอกจากนี้ เรายังจดทะเบียนการค้าถูกต้องตามกฎหมาย ภายใต้ชื่อ
                <strong>
                    <?= COMPANY_NAME ?>
                </strong> เลขทะเบียน
                <?= COMPANY_REGISTRATION ?>
                ลูกค้าสามารถมั่นใจได้ว่าซื้อสินค้าจากร้านที่เชื่อถือได้
            </p>

            <h2>พันธกิจของเรา</h2>

            <ul style="list-style:disc;padding-left:1.5rem;">
                <li>มอบมือถือมือสองคุณภาพดี ในราคาที่เป็นธรรม</li>
                <li>ตรวจสอบสินค้าทุกชิ้นก่อนจัดส่งอย่างละเอียด</li>
                <li>ให้บริการด้วยความซื่อสัตย์และโปร่งใส</li>
                <li>รับประกันสินค้าเพื่อความมั่นใจของลูกค้า</li>
                <li>พัฒนาบริการอย่างต่อเนื่องเพื่อความพึงพอใจสูงสุด</li>
            </ul>
        </div>
    </div>
</section>

<!-- Stats -->
<section class="section section-alt">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-item">
                <div class="stat-number">5+</div>
                <div class="stat-label">ปีประสบการณ์</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">5,000+</div>
                <div class="stat-label">ลูกค้าที่ไว้วางใจ</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">98%</div>
                <div class="stat-label">อัตราความพึงพอใจ</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">100%</div>
                <div class="stat-label">ตรวจสอบก่อนส่ง</div>
            </div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="cta-section">
    <div class="container">
        <h2>พร้อมสั่งซื้อมือถือคุณภาพดีแล้วหรือยัง?</h2>
        <p>ติดต่อเราวันนี้ รับคำแนะนำฟรี!</p>
        <div class="cta-buttons">
            <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>" class="btn btn-primary">โทรหาเรา
                <?= COMPANY_PHONE ?>
            </a>
            <a href="contact.php" class="btn btn-outline">ติดต่อเรา</a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>