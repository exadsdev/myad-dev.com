<?php
// click.php
require_once __DIR__ . '/tracker.php';

$target = $_GET['target'] ?? 'unknown';
$redirect = $_GET['redirect'] ?? '';

track_click($target);

// ถ้ามี redirect ให้เด้งไปปลายทาง
if ($redirect) {
    $redirect = str_replace(["\r","\n"], '', $redirect);
    header('Location: ' . $redirect, true, 302);
    exit;
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode(['ok' => true, 'target' => $target], JSON_UNESCAPED_UNICODE);
