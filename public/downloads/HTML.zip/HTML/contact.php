<?php
require_once 'config.php';

$pageTitle = 'ติดต่อเรา - ' . SITE_NAME;
$pageDescription = 'ติดต่อ PG Mobile ร้านขายมือถือมือสอง โทร 093-564-9111 อีเมล admin@pgmobilev9.com ที่อยู่ 183 หมู่ 1 ต.คำตากล้า อ.คำตากล้า จ.สกลนคร';
$pageKeywords = 'ติดต่อ PG Mobile, เบอร์โทร, แผนที่ร้าน, สกลนคร';
$canonicalPath = '/contact.php';

require_once 'includes/header.php';
?>

<!-- Page Header -->
<section class="page-header">
    <div class="container">
        <h1>ติดต่อเรา</h1>
        <p>พร้อมให้บริการตอบคำถามทุกวัน 09:00 - 21:00 น.</p>
    </div>
</section>

<!-- Contact Content -->
<section class="section">
    <div class="container">
        <div class="contact-grid">
            <!-- Contact Info -->
            <div class="contact-info">
                <div class="contact-item">
                    <div class="contact-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path
                                d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                        </svg>
                    </div>
                    <div class="contact-text">
                        <h4>ที่อยู่</h4>
                        <p>
                            <?= COMPANY_ADDRESS ?>
                        </p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path
                                d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" />
                        </svg>
                    </div>
                    <div class="contact-text">
                        <h4>โทรศัพท์</h4>
                        <p><a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>">
                                <?= COMPANY_PHONE ?>
                            </a></p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path
                                d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" />
                        </svg>
                    </div>
                    <div class="contact-text">
                        <h4>อีเมล</h4>
                        <p><a href="mailto:<?= COMPANY_EMAIL ?>">
                                <?= COMPANY_EMAIL ?>
                            </a></p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2.04C6.5 2.04 2 6.53 2 12.06c0 5.52 4.5 10.02 10 10.02s10-4.5 10-10.02C22 6.53 17.5 2.04 12 2.04zM16.5 12.06h-3.01v6h-3v-6H8.5v-3h2v-2.13c0-1.57.8-2.37 2.49-2.37h2.01v3h-1.5c-.31 0-.49.16-.49.51v1.99h2l-.25 3z"/>
                        </svg>
                    </div>
                    <div class="contact-text">
                        <h4>Facebook</h4>
                        <p><a href="https://www.facebook.com/pgmobiles" target="_blank" rel="noopener">PG Mobiles</a></p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                           <path d="M21.9 8.08c-.07-.3-.26-.57-.52-.75-.27-.2-.6-.28-.93-.24H3.55c-.33-.04-.66.04-.93.24s-.45.45-.52.75c-.1.4-.04.82.16 1.18.2.36.5.63.86.78.23.1.48.15.72.15h.6v5.36c0 .41.16.8.45 1.08.28.28.67.44 1.07.44h9.12c.4 0 .79-.16 1.07-.44.28-.28.45-.67.45-1.08V10.2h.6c.24 0 .49-.05.72-.15.36-.15.66-.42.86-.78.2-.36.26-.78.16-1.18zM9.66 14.3H8.22V9.9h1.44v4.4zm3.96 0h-1.44V9.9h1.44v4.4zm3.96 0h-1.44V9.9h1.44v4.4zM6.9 6.8c.4 0 .72-.32.72-.72s-.32-.72-.72-.72c-.4 0-.72.32-.72.72s.32.72.72.72zm10.2 0c.4 0 .72-.32.72-.72s-.32-.72-.72-.72c-.4 0-.72.32-.72.72s.32.72.72.72z"/>
                        </svg>
                    </div>
                    <div class="contact-text">
                        <h4>Line</h4>
                        <p><a href="https://lin.ee/EAtjlIe" target="_blank" rel="noopener">@pgmobiles</a></p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path
                                d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z" />
                        </svg>
                    </div>
                    <div class="contact-text">
                        <h4>เวลาทำการ</h4>
                        <p>ทุกวัน 09:00 - 21:00 น.</p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path
                                d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14h-2v-4H4V7h4v6h2V7h2v6h2V7h2v10h-2v-4z" />
                        </svg>
                    </div>
                    <div class="contact-text">
                        <h4>ข้อมูลบริษัท</h4>
                        <p>
                            <?= COMPANY_NAME ?>
                        </p>
                        <p>เลขทะเบียน:
                            <?= COMPANY_REGISTRATION ?>
                        </p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                            <path 
                                d="M8.5 13.5l2.5 3 2.5-3H6v- идеальный вариант исполнения Вами задуманногоM17 17H5V5h12v12zM17 3H5c-1.11 0-2 .9-2 2v12c0 1.1.89 2 2 2h12c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"/>
                        </svg>
                    </div>
                    <div class="contact-text">
                        <h4>ใบทะเบียนพาณิชย์</h4>
                        <p>
                            <a href="images/Commercial-registration.jpg" target="_blank">
                                <img src="images/Commercial-registration.jpg" alt="ใบทะเบียนพาณิชย์" style="max-width: 150px; border-radius: 8px; margin-top: 5px;">
                            </a>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Map -->
            <div class="map-container">
                <?= GOOGLE_MAPS_EMBED ?>
            </div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="cta-section">
    <div class="container">
        <h2>ต้องการสอบถามเพิ่มเติม?</h2>
        <p>โทรหาเราได้ทันที เรายินดีให้บริการ!</p>
        <div class="cta-buttons">
            <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>" class="btn btn-primary">โทรเลย
                <?= COMPANY_PHONE ?>
            </a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>