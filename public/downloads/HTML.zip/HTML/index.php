<?php
// =====================================================
// ✅ FILE: /index.php  (หรือไฟล์หน้า Landing หลักของคุณ)
// เพิ่ม no-cache + ทำ versioning ให้รูป/asset เพื่อไม่ให้รูปติดแคช (สำคัญมาก)
// =====================================================

// ✅ 1) ป้องกัน Cache สำหรับหน้า HTML
require_once __DIR__ . '/includes/no-cache.php';

require_once 'config.php';
require_once __DIR__ . '/tracker.php';
track_visit();

// ✅ 2) อ่านโหมดรูป + เวลาอัปเดต เพื่อทำ cache-busting ให้รูป (ไม่ต้องปิด cache รูปแบบรุนแรง)
$mode = 'phone';
$updatedAt = '';
$statePath = __DIR__ . '/config/image_switch_state.json';
if (is_file($statePath)) {
    $raw = @file_get_contents($statePath);
    if ($raw !== false) {
        $json = json_decode($raw, true);
        if (is_array($json)) {
            if (!empty($json['mode'])) $mode = (string)$json['mode'];
            if (!empty($json['updatedAt'])) $updatedAt = (string)$json['updatedAt'];
        }
    }
}

// ✅ 3) สร้างเวอร์ชัน token แบบ "ฉลาด" (เปลี่ยนเมื่อสลับโหมด/แก้ไฟล์) — กันรูปค้าง
// - ใช้ mode + updatedAt + filemtime ของหน้านี้ เป็นตัวกระตุ้น
$assetVersion = substr(sha1($mode . '|' . $updatedAt . '|' . (string)@filemtime(__FILE__)), 0, 12);

// ✅ 4) ฟังก์ชันเติม v=... ให้ URL รูป/asset (กันติดแคช)
function with_v($url, $v)
{
    $url = (string)$url;
    if ($url === '') return $url;
    return $url . (strpos($url, '?') !== false ? '&' : '?') . 'v=' . rawurlencode($v);
}

// =====================================================
// ของเดิมคุณ
// =====================================================
$pageTitle = 'PG Mobile - แหล่งรวมมือถือมือสอง สภาพนางฟ้า ราคาถูก รับประกันทุกเครื่อง';
$pageDescription = 'ร้านมือถือมือสอง PG Mobile ขายโทรศัพท์มือสองคัดเกรด สภาพสวย 100% ราคาถูกกว่าช็อป รับประกันการใช้งาน ส่งฟรีทั่วไทย มีเก็บเงินปลายทาง ผ่อนสบาย';
$pageKeywords = 'มือถือมือสอง, โทรศัพท์มือสอง, มือถือหลุดจำนำ, iPhone มือสอง, มือถือราคาถูก, ผ่อนมือถือ, ร้านมือถือสกลนคร, PG Mobile, ส่งฟรี';
$canonicalPath = '/';

$heroImage = getHeroImage();
$galleryImages = getGalleryImages();
$reviewImages = getReviewImages();
$newArrivalImages = getNewArrivalImages();

// ✅ 5) เติมเวอร์ชันให้รูปทั้งหมด (กันภาพค้างใน browser แบบถาวร)
$heroImage = with_v($heroImage, $assetVersion);

if (is_array($galleryImages)) {
    $galleryImages = array_map(function ($u) use ($assetVersion) {
        return with_v($u, $assetVersion);
    }, $galleryImages);
}

if (is_array($reviewImages)) {
    $reviewImages = array_map(function ($u) use ($assetVersion) {
        return with_v($u, $assetVersion);
    }, $reviewImages);
}

if (is_array($newArrivalImages)) {
    $newArrivalImages = array_map(function ($u) use ($assetVersion) {
        return with_v($u, $assetVersion);
    }, $newArrivalImages);
}

$facebookPage = 'https://www.facebook.com/pgmobiles';
$lineLink = 'https://lin.ee/EAtjlIe';

require_once 'includes/header.php';
require_once 'bot.php';

?>


<!-- JSON-LD Structured Data -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "<?= SITE_NAME ?>",
  "url": "<?= BASE_URL ?>",
  "logo": "<?= BASE_URL ?>/<?= LOGO ?>",
  "contactPoint": [{
    "@type": "ContactPoint",
    "telephone": "+66-93-564-9111",
    "contactType": "sales",
    "areaServed": "TH",
    "availableLanguage": ["Thai"]
  }],
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "183 หมู่ที่ 1",
    "addressLocality": "คำตากล้า",
    "addressRegion": "สกลนคร",
    "postalCode": "47250",
    "addressCountry": "TH"
  },
  "sameAs": [
    "<?= htmlspecialchars(FACEBOOK_URL) ?>",
    "<?= htmlspecialchars($facebookPage) ?>",
    "<?= htmlspecialchars($lineLink) ?>"
  ]
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "<?= SITE_NAME ?>",
  "image": "<?= BASE_URL ?>/<?= OG_IMAGE ?>",
  "url": "<?= BASE_URL ?>",
  "telephone": "+66-93-564-9111",
  "email": "<?= COMPANY_EMAIL ?>",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "183 หมู่ที่ 1 ตำบลคำตากล้า",
    "addressLocality": "อำเภอคำตากล้า",
    "addressRegion": "สกลนคร",
    "postalCode": "47250",
    "addressCountry": "TH"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 17.851683889262585,
    "longitude": 103.761095975818
  },
  "priceRange": "฿฿",
  "openingHours": "Mo-Su 09:00-21:00"
}
</script>

<!-- Hero Section -->
<section class="hero">
  <div class="container">
    <div class="hero-content">
      <div class="hero-text">
        <span class="badge">🔥 พร้อมส่งทั่วไทย</span>
        <h1>ร้านขายมือถือ PG Mobile <br><span style="color:#fbbf24">คุณภาพดี ราคาถูก</span></h1>
        <p class="hero-subtitle">
          รับประกันทุกเครื่อง ตรวจสอบก่อนส่ง ของแท้ 100%<br>
          PG ครบทุกรุ่น
        </p>

        <div class="cta-buttons">
          <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>" class="btn btn-primary">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path
                d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z" />
            </svg>
            โทรเลย <?= COMPANY_PHONE ?>
          </a>
          <a href="#products" class="btn btn-outline">ดูสินค้า</a>
        </div>

        <div class="cta-buttons" style="margin-top:12px; gap:10px;">
          <a href="<?= htmlspecialchars($lineLink) ?>" class="btn btn-outline" target="_blank" rel="noopener">
            แอดไลน์เพื่อสั่งซื้อ
          </a>
          <a href="<?= htmlspecialchars($facebookPage) ?>" class="btn btn-outline" target="_blank" rel="noopener">
            ดูงาน/รีวิวบน Facebook
          </a>
        </div>

        <div style="margin-top:14px; opacity:.9; font-size:14px; line-height:1.6;">
          <div>✅ ส่งฟรีทั่วประเทศ (1-3 วัน)</div>
          <div>✅ เก็บเงินปลายทาง / โอน / ผ่อนชำระ (แล้วแต่รุ่น)</div>
          <div>✅ มีบริการเช็คเครื่อง / เช็คแบต / เช็คอุปกรณ์ก่อนส่ง</div>
        </div>
      </div>

      <div class="hero-image-wrapper">
        <img src="<?= htmlspecialchars($heroImage) ?>" alt="มือถือมือสอง PG Mobile" class="hero-image" width="400"
          height="400" loading="eager">
      </div>
    </div>
  </div>
</section>

<!-- Store Intro / About (เพิ่มข้อมูลให้เหมือนหน้าในภาพ) -->
<section class="section section-alt">
  <div class="container">
    <h2 class="section-title">ทำไมต้องเลือก <span>PG Mobile</span></h2>

    <div class="features-grid">
      <div class="feature-card">
        <div class="feature-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor">
            <path
              d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z" />
          </svg>
        </div>
        <h3>รับประกันทุกเครื่อง</h3>
        <p>PGmobile ลิขสิทธิ์แท้100%</p>
        <p>รับประกันสินค้า 30 วัน มั่นใจได้ในคุณภาพ</p>
      </div>

      <div class="feature-card">
        <div class="feature-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor">
            <path
              d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
          </svg>
        </div>
        <h3>ส่งฟรีทั่วประเทศ</h3>
        <p>PGเว็บตรงช่วงโปรโมชั่น</p>
        <p>จัดส่งฟรี! ทุกออเดอร์ ถึงมือภายใน 1-3 วัน</p>
      </div>

      <div class="feature-card">
        <div class="feature-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor">
            <path
              d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z" />
          </svg>
        </div>
        <h3>ราคายุติธรรม</h3>
        <p>PG mobile จากสิงคโปร์100%</p>
        <p>ราคาถูกกว่าท้องตลาด คุ้มค่าทุกการซื้อ</p>
      </div>

      <div class="feature-card">
        <div class="feature-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor">
            <path
              d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
          </svg>
        </div>
        <h3>ตรวจสอบก่อนส่ง</h3>
        <p>PG mobile เว็บตรง100%</p>
        <p>ตรวจเช็คสภาพ 100% ก่อนจัดส่งทุกเครื่อง</p>
      </div>
    </div>

    <div style="margin-top:22px; display:flex; flex-wrap:wrap; gap:18px;">
      <div class="feature-card" style="height:100%; flex: 1 1 350px;">
        <h3 style="margin-top:0;">PG Mobile ร้านขายมือถือมือส PG Mobile</h3>
        <p style="margin:10px 0 0; line-height:1.8;">
          เราคัดสรรเครื่องมือสองคุณภาพดี ตรวจสอบสภาพการใช้งานทุกจุดก่อนส่ง
          พร้อมให้คำแนะนำรุ่นที่เหมาะกับงบและการใช้งานจริงของลูกค้า
          เน้นซื้อสบายใจ มีประกัน และมีช่องทางติดต่อชัดเจน
        </p>
        <div style="margin-top:12px; display:flex; flex-wrap:wrap; gap:10px;">
          <span class="badge">✔ เช็คเครื่องก่อนส่ง</span>
          <span class="badge">✔ มีรีวิวลูกค้า</span>
          <span class="badge">✔ บริการหลังการขาย</span>
          <span class="badge">✔ ส่งทั่วไทย</span>
        </div>
      </div>

      <div class="feature-card" style="height:100%; flex: 1 1 300px;">
        <h3 style="margin-top:0;">ช่องทางติดต่อด่วน</h3>
        <div style="margin-top:10px; line-height:1.9;">
          <div><strong>โทร:</strong> <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>"><?= COMPANY_PHONE ?></a>
          </div>
          <div><strong>อีเมล:</strong> <a
              href="mailto:<?= htmlspecialchars(COMPANY_EMAIL) ?>"><?= htmlspecialchars(COMPANY_EMAIL) ?></a></div>
          <div><strong>Facebook:</strong> <a href="<?= htmlspecialchars($facebookPage) ?>" target="_blank"
              rel="noopener"><?= htmlspecialchars($facebookPage) ?></a></div>
          <div><strong>LINE:</strong> <a href="<?= htmlspecialchars($lineLink) ?>" target="_blank"
              rel="noopener"><?= htmlspecialchars($lineLink) ?></a></div>
          <div style="margin-top:10px; opacity:.9;">
            <strong>ที่อยู่ร้าน:</strong><br>
            183 หมู่ที่ 1 ต.คำตากล้า อ.คำตากล้า จ.สกลนคร 47250
          </div>
          <div style="margin-top:10px; opacity:.9;">
            <strong>เวลาเปิดทำการ:</strong> ทุกวัน 09:00 - 21:00
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Stats Section -->
<section class="section">
  <div class="container">
    <div class="stats-grid">
      <div class="stat-item">
        <div class="stat-number">5,000+</div>
        <div class="stat-label">เครื่องที่ขายไปแล้ว</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">98%</div>
        <div class="stat-label">ลูกค้าพึงพอใจ</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">5+</div>
        <div class="stat-label">ปีประสบการณ์</div>
      </div>
      <div class="stat-item">
        <div class="stat-number">24/7</div>
        <div class="stat-label">บริการตอบแชท</div>
      </div>
    </div>
  </div>
</section>

<!-- Promo / Coupon Section -->
<section class="section section-alt">
  <div class="container">
    <div class="feature-card"
      style="display:flex; align-items:center; justify-content:space-between; gap:18px; flex-wrap:wrap;">
      <div style="flex:1; min-width:260px;">
        <h2 style="margin:0 0 8px;">รับคูปองส่วนลด <span style="color:#fbbf24;">10%</span> สำหรับการสั่งซื้อครั้งแรก
        </h2>
        <p style="margin:0; opacity:.9; line-height:1.8;">
          ทักแชทเพื่อรับโค้ดส่วนลด แจ้งรุ่นที่ต้องการ + งบประมาณ ทีมงานช่วยแนะนำให้เหมาะกับการใช้งานได้เลย
        </p>
        <div class="cta-buttons" style="margin-top:12px;">
          <a href="<?= htmlspecialchars($lineLink) ?>" class="btn btn-primary" target="_blank"
            rel="noopener">รับคูปองทาง LINE</a>
          <a href="<?= htmlspecialchars($facebookPage) ?>" class="btn btn-outline" target="_blank" rel="noopener">ทัก
            Facebook</a>
        </div>
      </div>
      <div style="min-width:220px; text-align:center;">
        <div class="badge" style="display:inline-block; padding:10px 14px; font-size:14px; margin-bottom:10px;">
          โค้ดส่วนลดสำหรับลูกค้าใหม่</div>
        <div style="font-size:44px; font-weight:800; letter-spacing:1px; opacity:.9;">10% OFF</div>
        <div style="opacity:.75; margin-top:6px;">* เงื่อนไขตามที่ร้านกำหนด</div>
      </div>
    </div>
  </div>
</section>

<!-- Products Gallery (สินค้าแนะนำ) -->
<section id="products" class="section">
  <div class="container">
    <h2 class="section-title">สินค้า<span>แนะนำ</span></h2>
    <div class="gallery-grid">
      <?php foreach ($galleryImages as $index => $image): ?>
        <div class="gallery-item">
          <img src="<?= htmlspecialchars($image) ?>" alt="มือถือมือสอง รุ่น <?= $index + 1 ?>" width="300" height="300"
            loading="lazy">
        </div>
      <?php endforeach; ?>
    </div>

    <div style="margin-top:18px; opacity:.9; line-height:1.8;">
      <strong>หมายเหตุ:</strong> ภาพสินค้าเป็นตัวอย่าง/อัปเดตตามสต็อคจริง
      สนใจรุ่นไหนทักแชทเพื่อเช็คราคาและสภาพเครื่องได้ทันที
    </div>
  </div>
</section>

<!-- Reviews Section - Customer Testimonials with Images -->
<section class="section" id="reviews">
  <div class="container">
    <h2 class="section-title">รีวิวจาก<span>ลูกค้าจริง</span></h2>
    <p class="text-center mb-4" style="opacity:0.85;">ความคิดเห็นจากลูกค้าที่ซื้อ PG V9 กับเรา</p>

    <?php
    // รีวิว 6 รายการ พร้อมรูปภาพ
    $reviewsWithImages = [
      [
        'image' => 'images/review/01.jpg',
        'province' => 'นครพนม',
        'date' => '15 พ.ค. 2025',
        'product' => 'PG V9',
        'text' => 'สั่ง PG V9 มาครับ เครื่องสวยมาก จอใหญ่ชัด แบตอึดใช้ได้ทั้งวัน แอดมินส่งวิดีโอเช็คเครื่องให้ดูก่อนส่ง ประทับใจมากครับ',
        'rating' => 5
      ],
      [
        'image' => 'images/review/02.jpg',
        'province' => 'อุดรธานี',
        'date' => '22 มิ.ย. 2025',
        'product' => 'PG V9 Pro',
        'text' => 'ซื้อให้แม่ใช้ค่ะ เครื่องสภาพดีมาก ราคาเป็นมิตร แอดมินตอบไวมาก แนะนำรุ่นที่เหมาะกับการใช้งานให้ด้วย ขอบคุณค่ะ',
        'rating' => 5
      ],
      [
        'image' => 'images/review/03.jpg',
        'province' => 'ขอนแก่น',
        'date' => '8 ส.ค. 2025',
        'product' => 'PG V9 Plus',
        'text' => 'เครื่องตรงปกครับ สั่งวันจันทร์ได้วันพุธ ส่งเร็วมาก แพ็คกล่องแน่นหนาดี มีใบรับประกันให้ครบ บริการหลังการขายดีครับ',
        'rating' => 5
      ],
      [
        'image' => 'images/review/04.png',
        'province' => 'มุกดาหาร',
        'date' => '3 ก.ย. 2025',
        'product' => 'PG V9 Pro',
        'text' => 'สั่ง PG V9 Pro มาใช้ค่ะ จอสวยมาก เครื่องลื่นไม่มีสะดุดเลย ก่อนส่งแอดมินโทรมาแจ้งสภาพเครื่องให้ฟัง บริการดีมากค่ะ',
        'rating' => 5
      ],
      [
        'image' => 'images/review/05.png',
        'province' => 'ร้อยเอ็ด',
        'date' => '18 ต.ค. 2025',
        'product' => 'PG V9 2025',
        'text' => 'ซื้อ PG V9 2025 มาใช้ครับ สเปคดีมาก กล้องถ่ายชัด แอดมินแนะนำฟีเจอร์ต่างๆ ให้ ร้านน่าเชื่อถือครับ',
        'rating' => 5
      ],
      [
        'image' => 'images/review/06.jpg',
        'province' => 'หนองคาย',
        'date' => '29 ธ.ค. 2025',
        'product' => 'PG V9',
        'text' => 'สั่งแบบเก็บปลายทางค่ะ ไม่ต้องโอนก่อน รอเช็คของแล้วค่อยจ่าย มั่นใจมากค่ะ เครื่องสภาพดีตรงปก แนะนำเลยค่ะ',
        'rating' => 5
      ]
    ];
    ?>

    <!-- Reviews Grid: Image + Text Below -->
    <div class="row g-4">
      <?php foreach ($reviewsWithImages as $review): ?>
        <div class="col-12 col-md-6 col-lg-4">
          <div class="card h-100 border-0 shadow-sm review-card-new">
            <!-- Review Image -->
            <div class="review-img-wrapper">
              <img src="<?= htmlspecialchars($review['image']) ?>" alt="รีวิวจากลูกค้า" class="card-img-top"
                loading="lazy">
            </div>
            <!-- Review Content -->
            <div class="card-body">
              <div class="mb-2" style="color:#fbbf24;">
                <?php for ($i = 0; $i < $review['rating']; $i++): ?>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                  </svg>
                <?php endfor; ?>
              </div>
              <span class="badge bg-primary mb-2"><?= htmlspecialchars($review['product']) ?></span>
              <p class="card-text small mb-3" style="line-height:1.7;">"<?= htmlspecialchars($review['text']) ?>"</p>
              <div class="pt-2 border-top">
                <div class="text-muted small">📍 <?= htmlspecialchars($review['province']) ?> |
                  <?= htmlspecialchars($review['date']) ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Disclaimer -->
    <div class="text-center mt-4 pt-3" style="border-top: 1px dashed rgba(0,0,0,0.1);">
      <p class="text-muted mb-2" style="font-size:0.8rem;">⚠️ ผลลัพธ์ขึ้นอยู่กับรุ่นสินค้าและเงื่อนไขการรับประกันของร้าน
      </p>
      <p class="mb-0" style="opacity:.85;">อยากดูรีวิวเพิ่ม? <a href="<?= htmlspecialchars($facebookPage) ?>"
          target="_blank" rel="noopener" class="fw-semibold">ไปที่ Facebook Page</a></p>
    </div>
  </div>
</section>

<style>
  .review-card-new {
    border-radius: 16px !important;
    overflow: hidden;
    transition: transform .3s, box-shadow .3s
  }

  .review-card-new:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(0, 0, 0, .15) !important
  }

  .review-img-wrapper {
    height: 220px;
    overflow: hidden
  }

  .review-img-wrapper img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform .3s
  }

  .review-card-new:hover .review-img-wrapper img {
    transform: scale(1.05)
  }
</style>

<!-- Services / Policies Section -->
<section class="section section-alt">
  <div class="container">
    <h2 class="section-title">บริการ<span>ของเรา</span></h2>

    <div class="features-grid">
      <div class="feature-card">
        <h3 style="margin-top:0;">การรับประกันสินค้า</h3>
        <p style="line-height:1.8; margin:10px 0 0;">
          รับประกัน 30 วัน (ตามเงื่อนไขร้าน) หากมีปัญหาการใช้งานจากการใช้งานปกติ
          สามารถติดต่อทีมงานเพื่อช่วยตรวจสอบและแนะนำแนวทางได้ทันที
        </p>
      </div>

      <div class="feature-card">
        <h3 style="margin-top:0;">การจัดส่งและความปลอดภัย</h3>
        <p style="line-height:1.8; margin:10px 0 0;">
          แพ็คกันกระแทกอย่างดี พร้อมตรวจสภาพก่อนส่งทุกเครื่อง
          จัดส่งทั่วประเทศ ใช้เวลาประมาณ 1-3 วัน (ขึ้นอยู่กับพื้นที่)
        </p>
      </div>

      <div class="feature-card">
        <h3 style="margin-top:0;">การชำระเงิน</h3>
        <p style="line-height:1.8; margin:10px 0 0;">
          รองรับการชำระเงินหลากหลาย: โอนเงิน / เก็บเงินปลายทาง (แล้วแต่เงื่อนไข)
          ต้องการผ่อนชำระสามารถทักสอบถามรุ่นที่ร่วมรายการได้
        </p>
      </div>

      <div class="feature-card">
        <h3 style="margin-top:0;">บริการหลังการขาย</h3>
        <p style="line-height:1.8; margin:10px 0 0;">
          ทีมงานช่วยแนะนำการใช้งาน ตั้งค่าเครื่อง โอนย้ายข้อมูลเบื้องต้น
          และแนะนำอุปกรณ์เสริมให้เหมาะกับรุ่นของลูกค้า
        </p>
      </div>
    </div>

    <div style="margin-top:18px; display:block; grid-template-columns: 1fr 1fr; gap:18px;">
      <div class="feature-card">
        <!-- FAQ Section (Bootstrap Accordion) -->
        <div class="feature-card">
          <h3 class="mb-3">คำถามที่พบบ่อย (FAQ)</h3>

          <div class="accordion" id="faqAccordion">

            <div class="accordion-item">
              <h2 class="accordion-header" id="faq1">
                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1Content">
                  มือถือมือสองมีตำหนิไหม?
                </button>
              </h2>
              <div id="faq1Content" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                  มือถือทุกเครื่องมีการแจ้งสภาพตามจริงก่อนส่ง หากมีรอยหรือตำหนิ
                  ทีมงานจะแจ้งล่วงหน้า พร้อมส่งรูปหรือวิดีโอให้ตรวจสอบก่อนตัดสินใจ
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header" id="faq2">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#faq2Content">
                  มีรับประกันไหม? กี่วัน?
                </button>
              </h2>
              <div id="faq2Content" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                  รับประกันสินค้า 30 วัน (ตามเงื่อนไขร้าน)
                  ครอบคลุมอาการเสียจากการใช้งานปกติ
                  หากพบปัญหาสามารถติดต่อทีมงานได้ทันที
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header" id="faq3">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#faq3Content">
                  จัดส่งกี่วัน? ส่งฟรีไหม?
                </button>
              </h2>
              <div id="faq3Content" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                  จัดส่งทั่วประเทศ ใช้เวลาประมาณ 1–3 วันทำการ
                  มีโปรส่งฟรีตามเงื่อนไขร้าน
                  แพ็คกันกระแทกและตรวจเครื่องก่อนส่งทุกครั้ง
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header" id="faq4">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#faq4Content">
                  มีเก็บเงินปลายทาง (COD) ไหม?
                </button>
              </h2>
              <div id="faq4Content" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                  รองรับเก็บเงินปลายทางในบางรุ่น/บางเงื่อนไข
                  แนะนำให้ทักแชทแจ้งรุ่นที่สนใจ
                  ทีมงานตรวจสอบให้ก่อนสั่งซื้อ
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header" id="faq5">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                  data-bs-target="#faq5Content">
                  ผ่อนได้ไหม?
                </button>
              </h2>
              <div id="faq5Content" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                <div class="accordion-body">
                  รองรับผ่อนชำระบางรุ่นตามเงื่อนไขร้าน
                  แจ้งงบประมาณและรุ่นที่สนใจ
                  ทีมงานช่วยแนะนำตัวเลือกที่เหมาะสมให้
                </div>
              </div>
            </div>

          </div>

          <div class="mt-3 small text-muted">
            หากยังไม่เจอคำตอบที่ต้องการ สามารถติดต่อเราได้ทาง
            <a href="<?= htmlspecialchars($lineLink) ?>" target="_blank">LINE</a> หรือ
            <a href="<?= htmlspecialchars($facebookPage) ?>" target="_blank">Facebook</a>
          </div>
        </div>

      </div>

      <div class="feature-card">
        <h3 style="margin-top:0;">รับซื้อ / เทิร์นเครื่อง (สอบถามได้)</h3>
        <p style="line-height:1.8; margin:10px 0 0;">
          ต้องการขายเครื่องเก่า หรืออยากเทิร์นเป็นรุ่นใหม่
          ส่งรายละเอียดรุ่น/ความจุ/สภาพเครื่อง + รูปถ่ายมาที่ LINE หรือ Facebook
          ทีมงานประเมินราคาให้เบื้องต้นได้
        </p>

        <div class="cta-buttons" style="margin-top:12px;">
          <a href="<?= htmlspecialchars($lineLink) ?>" class="btn btn-primary" target="_blank"
            rel="noopener">ส่งรูปประเมินทาง LINE</a>
          <a href="<?= htmlspecialchars($facebookPage) ?>" class="btn btn-outline" target="_blank"
            rel="noopener">ส่งรูปทาง Facebook</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Contact Section (เพิ่มช่องทางติดต่อให้ครบ) -->
<section id="contact" class="section">
  <div class="container">
    <h2 class="section-title">ติดต่อ<span>เรา</span></h2>

    <div style="display:flex; flex-wrap:wrap; gap:18px;">
      <div class="feature-card" style="flex: 1 1 350px;">
        <h3 style="margin-top:0;">ส่งข้อความหาเรา</h3>

        <form action="contact.php" method="get" style="margin-top:12px;">
          <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
            <div>
              <label style="display:block; margin-bottom:6px; opacity:.85;">ชื่อ</label>
              <input type="text" name="name" required
                style="width:100%; padding:12px 12px; border-radius:12px; border:1px solid rgba(255,255,255,.15); background:rgba(0,0,0,.25); color:#fff;">
            </div>
            <div>
              <label style="display:block; margin-bottom:6px; opacity:.85;">เบอร์โทร</label>
              <input type="text" name="phone" required
                style="width:100%; padding:12px 12px; border-radius:12px; border:1px solid rgba(255,255,255,.15); background:rgba(0,0,0,.25); color:#fff;">
            </div>
          </div>

          <div style="margin-top:10px;">
            <label style="display:block; margin-bottom:6px; opacity:.85;">ข้อความ</label>
            <textarea name="message" rows="4" required
              style="width:100%; padding:12px 12px; border-radius:12px; border:1px solid rgba(255,255,255,.15); background:rgba(0,0,0,.25); color:#fff;"></textarea>
          </div>

          <div class="cta-buttons" style="margin-top:12px;">
            <button type="submit" class="btn btn-primary" style="border:none;">ส่งข้อความ</button>
            <a href="<?= htmlspecialchars($lineLink) ?>" class="btn btn-outline" target="_blank" rel="noopener">ทัก LINE
              เร็วที่สุด</a>
          </div>

          <div style="margin-top:10px; opacity:.75; line-height:1.7;">
            * ฟอร์มนี้จะพาไปหน้าติดต่อเรา (contact.php) เพื่อส่งข้อมูล/รายละเอียดเพิ่มเติม
          </div>
        </form>
      </div>

      <div class="feature-card" style="flex: 1 1 350px;">
        <h3 style="margin-top:0;">ข้อมูลติดต่อ</h3>
        <div style="margin-top:10px; line-height:2;">
          <div><strong>ชื่อร้าน:</strong> <?= SITE_NAME ?></div>
          <div><strong>โทร:</strong> <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>"><?= COMPANY_PHONE ?></a>
          </div>
          <div><strong>อีเมล:</strong> <a
              href="mailto:<?= htmlspecialchars(COMPANY_EMAIL) ?>"><?= htmlspecialchars(COMPANY_EMAIL) ?></a></div>
          <div><strong>Facebook:</strong> <a href="<?= htmlspecialchars($facebookPage) ?>" target="_blank"
              rel="noopener"><?= htmlspecialchars($facebookPage) ?></a></div>
          <div><strong>LINE:</strong> <a href="<?= htmlspecialchars($lineLink) ?>" target="_blank"
              rel="noopener"><?= htmlspecialchars($lineLink) ?></a></div>

          <div style="margin-top:10px; opacity:.9;">
            <strong>ที่อยู่ร้าน:</strong><br>
            183 หมู่ที่ 1 ต.คำตากล้า อ.คำตากล้า จ.สกลนคร 47250
          </div>

          <div style="margin-top:10px; opacity:.9;">
            <strong>เวลาเปิดทำการ:</strong> ทุกวัน 09:00 - 21:00
          </div>
        </div>

        <div style="margin-top:14px; border-radius:14px; overflow:hidden; border:1px solid rgba(255,255,255,.12);">
          <iframe title="แผนที่ร้าน PG Mobile" width="100%" height="260" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
            src="https://www.google.com/maps?q=17.851683889262585,103.761095975818&z=16&output=embed" style="border:0;"
            allowfullscreen>
          </iframe>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
  <div class="container">
    <h2>พร้อมสั่งซื้อมือถือคุณภาพดีแล้วหรือยัง?</h2>
    <p>ติดต่อเราวันนี้ รับส่วนลดพิเศษสำหรับลูกค้าใหม่!</p>
    <div class="cta-buttons">
      <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>" class="btn btn-primary">
        โทรสั่งซื้อ <?= COMPANY_PHONE ?>
      </a>
      <a href="<?= htmlspecialchars($lineLink) ?>" class="btn btn-outline" target="_blank" rel="noopener">ทัก LINE</a>
      <a href="<?= htmlspecialchars($facebookPage) ?>" class="btn btn-outline" target="_blank" rel="noopener">ทัก
        Facebook</a>
      <a href="contact.php" class="btn btn-outline">หน้าติดต่อเรา</a>
    </div>
  </div>
</section>

<?php require_once 'includes/footer.php'; ?>