<?php
require_once 'config.php';

$pageTitle = '404 - ไม่พบหน้าที่ต้องการ | ' . SITE_NAME;
$pageDescription = 'ขออภัย ไม่พบหน้าที่คุณต้องการ กรุณาตรวจสอบ URL อีกครั้ง หรือกลับไปหน้าแรก';
$pageKeywords = '404, page not found, ไม่พบหน้า';
$canonicalPath = '/404.php';

// Set 404 header
http_response_code(404);

require_once 'includes/header.php';
?>

<section class="section" style="min-height: 60vh; display: flex; align-items: center;">
    <div class="container text-center">
        <h1 style="font-size: 8rem; color: var(--primary); margin-bottom: 0;">404</h1>
        <h2 style="margin-bottom: var(--space-4);">ไม่พบหน้าที่ต้องการ</h2>
        <p style="color: var(--gray-600); margin-bottom: var(--space-8);">
            ขออภัย หน้าที่คุณกำลังมองหาไม่มีอยู่ หรืออาจถูกย้ายไปที่อื่นแล้ว
        </p>
        <div class="cta-buttons" style="justify-content: center;">
            <a href="index.php" class="btn btn-secondary">กลับหน้าแรก</a>
            <a href="contact.php" class="btn btn-accent">ติดต่อเรา</a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>