<?php
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../tracker.php';

// Ensure admin is logged in
if (empty($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

// Paths to data files (settings)
$settingsFile = __DIR__ . '/../data/settings.json';

// Ensure json storage for tracking
ensure_data_storage();

// Load settings
$settings = ['google_tag_id' => '', 'shop_url' => ''];
if (file_exists($settingsFile)) {
    $settings = json_decode(file_get_contents($settingsFile), true) ?? $settings;
}

// Handle actions (settings save / clear json)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Save settings
    if (isset($_POST['google_tag_id'], $_POST['shop_url'])) {
        $settings['google_tag_id'] = trim($_POST['google_tag_id']);
        $settings['shop_url'] = trim($_POST['shop_url']);

        if (!is_dir(dirname($settingsFile))) {
            @mkdir(dirname($settingsFile), 0755, true);
        }

        file_put_contents($settingsFile, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        header('Location: index.php');
        exit;
    }

    // Clear data buttons
    $action = $_POST['action'] ?? '';
    if ($action === 'clear_visits') {
        safe_json_write(VISITS_JSON, []);
        header('Location: index.php');
        exit;
    }
    if ($action === 'clear_clicks') {
        safe_json_write(CLICKS_JSON, []);
        header('Location: index.php');
        exit;
    }
    if ($action === 'clear_all') {
        safe_json_write(VISITS_JSON, []);
        safe_json_write(CLICKS_JSON, []);
        header('Location: index.php');
        exit;
    }
}

// Load report data
$visits = safe_json_read(VISITS_JSON);
$clicks = safe_json_read(CLICKS_JSON);

[$vh, $vb, $vt] = count_types($visits);
[$ch, $cb, $ct] = count_types($clicks);

$visitsLatest = latest_rows($visits, MAX_ROWS_SHOW);
$clicksLatest = latest_rows($clicks, MAX_ROWS_SHOW);
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <title>เมนูผู้ดูแล</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Sarabun', sans-serif;
            background: #f8fafc;
            min-height: 100vh;
        }

        .card {
            background: #fff;
            border-radius: 12px;
            border: none;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        .badge-soft {
            border: 1px solid rgba(0, 0, 0, .08);
            background: #f8fafc;
        }

        .table thead th {
            white-space: nowrap;
        }

        /* ============================================
           Single Line + Ellipsis + Hover Tooltip
           ============================================ */
        .td-truncate {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            cursor: pointer;
        }

        .td-truncate:hover {
            background-color: #e2e8f0;
        }

        /* Force all table cells to single line */
        .table-logs td {
            white-space: nowrap;
            vertical-align: middle;
        }

        .table-logs tr {
            height: 40px;
        }
    </style>
</head>

<body>
    <div class="container py-4">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-0">เมนูผู้ดูแล</h1>
                <div class="text-secondary small">รายงานผู้เข้าชม/คลิก แยกคน-บอท + ตั้งค่าระบบ</div>
            </div>
            <a href="logout.php" class="btn btn-outline-danger">ออกจากระบบ</a>
        </div>

        <!-- Summary Cards -->
        <div class="row g-3 mb-3">
            <div class="col-12 col-lg-4">
                <div class="card p-3">
                    <div class="text-secondary small">Visits (ผู้เข้าชม)</div>
                    <div class="display-6 fw-bold"><?php echo (int) $vt; ?></div>
                    <div class="mt-2 d-flex gap-2 flex-wrap">
                        <span class="badge badge-soft text-dark">คน: <?php echo (int) $vh; ?></span>
                        <span class="badge badge-soft text-dark">บอท: <?php echo (int) $vb; ?></span>
                    </div>
                    <form method="post" class="mt-3 d-flex gap-2 flex-wrap">
                        <input type="hidden" name="action" value="clear_visits">
                        <button class="btn btn-sm btn-outline-danger" onclick="return confirm('ลบ Visits ทั้งหมด?')">ลบ
                            Visits</button>
                    </form>
                </div>
            </div>

            <div class="col-12 col-lg-4">
                <div class="card p-3">
                    <div class="text-secondary small">Clicks (การคลิก)</div>
                    <div class="display-6 fw-bold"><?php echo (int) $ct; ?></div>
                    <div class="mt-2 d-flex gap-2 flex-wrap">
                        <span class="badge badge-soft text-dark">คนคลิก: <?php echo (int) $ch; ?></span>
                        <span class="badge badge-soft text-dark">บอทคลิก: <?php echo (int) $cb; ?></span>
                    </div>
                    <form method="post" class="mt-3 d-flex gap-2 flex-wrap">
                        <input type="hidden" name="action" value="clear_clicks">
                        <button class="btn btn-sm btn-outline-danger" onclick="return confirm('ลบ Clicks ทั้งหมด?')">ลบ
                            Clicks</button>
                    </form>
                </div>
            </div>

            <div class="col-12 col-lg-4">
                <div class="card p-3">
                    <div class="text-secondary small">จัดการทั้งหมด</div>
                    <div class="mt-2 small text-secondary">
                        visits.json / clicks.json จะถูกรีเซ็ตเป็น []
                    </div>
                    <form method="post" class="mt-3 d-flex gap-2 flex-wrap">
                        <input type="hidden" name="action" value="clear_all">
                        <button class="btn btn-sm btn-danger"
                            onclick="return confirm('ลบทั้งหมด (Visits + Clicks)?')">ลบทั้งหมด</button>
                    </form>
                    <div class="mt-3 small text-secondary">
                        ตัวอย่าง Track คลิก:
                        <code
                            class="d-block mt-1">&lt;a href="/click.php?target=buy-now&amp;redirect=https://example.com"&gt;ซื้อเลย&lt;/a&gt;</code>
                    </div>
                </div>
            </div>
        </div>

        <!-- Settings -->
        <div class="card p-4 mb-3">
            <h5 class="mb-3">ตั้งค่าระบบ</h5>
            <form method="post" action="">
                <div class="mb-3">
                    <label class="form-label">Google Ads Tag ID</label>
                    <input type="text" name="google_tag_id" class="form-control"
                        value="<?php echo htmlspecialchars($settings['google_tag_id'] ?? ''); ?>"
                        placeholder="AW-XXXXXXXXX">
                </div>
                <div class="mb-3">
                    <label class="form-label">Shop URL</label>
                    <input type="text" name="shop_url" class="form-control"
                        value="<?php echo htmlspecialchars($settings['shop_url'] ?? ''); ?>" placeholder="https://...">
                </div>
                <div class="text-end">
                    <button type="submit" class="btn btn-primary">บันทึกการตั้งค่า</button>
                </div>
            </form>
        </div>

        <!-- Visits Table -->
        <div class="card p-3 mb-3">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h5 class="mb-0">Visits ล่าสุด (<?php echo (int) MAX_ROWS_SHOW; ?> รายการ)</h5>
                <span class="text-secondary small">ไฟล์: <?php echo htmlspecialchars(VISITS_JSON); ?></span>
            </div>
            <div class="small text-muted mb-2">💡 เอาเมาส์ชี้ที่ข้อความเพื่อดูข้อความเต็ม</div>
            <div class="table-responsive">
                <table class="table table-sm align-middle table-logs">
                    <thead>
                        <tr>
                            <th>เวลา</th>
                            <th>ประเภท</th>
                            <th>IP</th>
                            <th>URL</th>
                            <th>Referer</th>
                            <th>User-Agent</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($visitsLatest) === 0): ?>
                            <tr>
                                <td colspan="6" class="text-secondary">ยังไม่มีข้อมูล visits</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($visitsLatest as $r): ?>
                                <?php $t = $r['visitorType'] ?? 'human'; ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($r['time'] ?? ''); ?></td>
                                    <td>
                                        <?php if ($t === 'bot'): ?>
                                            <span class="badge bg-dark">บอท</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">คน</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($r['ip'] ?? ''); ?></td>
                                    <td class="td-truncate" title="<?php echo htmlspecialchars($r['url'] ?? ''); ?>">
                                        <?php echo htmlspecialchars($r['url'] ?? ''); ?>
                                    </td>
                                    <td class="td-truncate" title="<?php echo htmlspecialchars($r['referer'] ?? ''); ?>">
                                        <?php echo htmlspecialchars($r['referer'] ?? '') ?: '-'; ?>
                                    </td>
                                    <td class="td-truncate" title="<?php echo htmlspecialchars($r['userAgent'] ?? ''); ?>">
                                        <?php echo htmlspecialchars($r['userAgent'] ?? ''); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Clicks Table -->
        <div class="card p-3">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h5 class="mb-0">Clicks ล่าสุด (<?php echo (int) MAX_ROWS_SHOW; ?> รายการ)</h5>
                <span class="text-secondary small">ไฟล์: <?php echo htmlspecialchars(CLICKS_JSON); ?></span>
            </div>
            <div class="small text-muted mb-2">💡 เอาเมาส์ชี้ที่ข้อความเพื่อดูข้อความเต็ม</div>
            <div class="table-responsive">
                <table class="table table-sm align-middle table-logs">
                    <thead>
                        <tr>
                            <th>เวลา</th>
                            <th>ประเภท</th>
                            <th>IP</th>
                            <th>Target</th>
                            <th>URL</th>
                            <th>Referer</th>
                            <th>User-Agent</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($clicksLatest) === 0): ?>
                            <tr>
                                <td colspan="7" class="text-secondary">ยังไม่มีข้อมูล clicks</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($clicksLatest as $r): ?>
                                <?php $t = $r['visitorType'] ?? 'human'; ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($r['time'] ?? ''); ?></td>
                                    <td>
                                        <?php if ($t === 'bot'): ?>
                                            <span class="badge bg-dark">บอท</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">คน</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($r['ip'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($r['target'] ?? ''); ?></td>
                                    <td class="td-truncate" title="<?php echo htmlspecialchars($r['url'] ?? ''); ?>">
                                        <?php echo htmlspecialchars($r['url'] ?? ''); ?>
                                    </td>
                                    <td class="td-truncate" title="<?php echo htmlspecialchars($r['referer'] ?? ''); ?>">
                                        <?php echo htmlspecialchars($r['referer'] ?? '') ?: '-'; ?>
                                    </td>
                                    <td class="td-truncate" title="<?php echo htmlspecialchars($r['userAgent'] ?? ''); ?>">
                                        <?php echo htmlspecialchars($r['userAgent'] ?? ''); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</body>

</html>