<?php
// admin/_auth.php
// Ensures session active and admin logged in

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../config.php';

// Generate CSRF token if not present
if (empty($_SESSION['csrf_token'])) {
    if (function_exists('random_bytes')) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
    }
}

// Redirect if not logged in
if (empty($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}


?>