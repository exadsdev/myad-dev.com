<?php
session_start();
require_once __DIR__ . '/../config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: index.php');
        exit;
    } else {
        $error = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        * {
            box-sizing: border-box;
            font-family: "Segoe UI", Tahoma, sans-serif;
        }

        body {
            margin: 0;
            height: 100vh;
            background: linear-gradient(135deg, #1d2671, #c33764);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-wrapper {
            width: 100%;
            max-width: 380px;
            padding: 20px;
        }

        .login-box {
            background: #ffffff;
            border-radius: 14px;
            padding: 30px 28px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, .25);
            animation: fadeIn .6s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(12px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-box h1 {
            margin: 0;
            text-align: center;
            font-size: 24px;
            color: #1d2671;
        }

        .login-box p.subtitle {
            text-align: center;
            color: #777;
            font-size: 14px;
            margin-top: 6px;
            margin-bottom: 22px;
        }

        .form-group {
            margin-bottom: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 14px;
            border-radius: 8px;
            border: 1px solid #ddd;
            font-size: 14px;
            transition: 0.2s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #1d2671;
            box-shadow: 0 0 0 2px rgba(29, 38, 113, .15);
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            border: none;
            background: linear-gradient(135deg, #1d2671, #c33764);
            color: #fff;
            font-size: 15px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.25s;
        }

        .login-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, .25);
        }

        .error-box {
            background: #ffe6e6;
            color: #b00000;
            border-radius: 8px;
            padding: 10px;
            font-size: 13px;
            text-align: center;
            margin-bottom: 14px;
        }

        .footer-text {
            margin-top: 16px;
            text-align: center;
            font-size: 12px;
            color: #aaa;
        }
    </style>
</head>

<body>

    <div class="login-wrapper">
        <div class="login-box">
            <h1>Admin Panel</h1>
            <p class="subtitle">เข้าสู่ระบบผู้ดูแลระบบ</p>

            <?php if ($error): ?>
                <div class="error-box">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="post">
                <div class="form-group">
                    <input type="text" name="username" placeholder="ชื่อผู้ใช้" required>
                </div>

                <div class="form-group">
                    <input type="password" name="password" placeholder="รหัสผ่าน" required>
                </div>

                <button class="login-btn" type="submit">
                    เข้าสู่ระบบ
                </button>
            </form>

            <div class="footer-text">
                © <?= date('Y') ?> Admin System
            </div>
        </div>
    </div>

</body>

</html>