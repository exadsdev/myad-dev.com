
<?php
/*
  =========================
  FAQ DATA (เพิ่มคำถาม/คำตอบ)
  =========================
*/
$faqItems = [
  [
    'q' => 'มือถือมือสองมีตำหนิไหม?',
    'a' => 'มือถือทุกเครื่องจะมีการแจ้งสภาพตามจริงก่อนส่ง หากมีรอย/ตำหนิ ทีมงานจะแจ้งให้ทราบล่วงหน้า พร้อมส่งรูปจริงหรือวิดีโอตรวจเครื่องให้ได้ก่อนตัดสินใจ'
  ],
  [
    'q' => 'มีรับประกันไหม? รับประกันกี่วัน?',
    'a' => 'มีรับประกัน 30 วัน (ตามเงื่อนไขร้าน) ครอบคลุมอาการเสียจากการใช้งานปกติ หากพบปัญหาสามารถติดต่อทีมงานเพื่อช่วยตรวจสอบและแนะนำแนวทางได้ทันที'
  ],
  [
    'q' => 'จัดส่งกี่วันถึง? ส่งฟรีไหม?',
    'a' => 'จัดส่งทั่วประเทศโดยทั่วไป 1-3 วันทำการ (ขึ้นอยู่กับพื้นที่) และมีโปรส่งฟรีตามเงื่อนไขร้าน แพ็คกันกระแทกอย่างดี พร้อมตรวจเครื่องก่อนส่งทุกครั้ง'
  ],
  [
    'q' => 'มีเก็บเงินปลายทาง (COD) ไหม?',
    'a' => 'รองรับเก็บเงินปลายทางในบางรุ่น/บางเงื่อนไข หากต้องการ COD ให้ทักแชทแจ้งรุ่นที่สนใจ ทีมงานตรวจสอบให้ก่อนสั่งซื้อ'
  ],
  [
    'q' => 'ผ่อนได้ไหม? ต้องใช้อะไรบ้าง?',
    'a' => 'รองรับผ่อนชำระบางรุ่นตามเงื่อนไขร้าน/โปรโมชัน แนะนำให้ทักแชทแจ้งงบและรุ่นที่สนใจ ทีมงานจะเช็คตัวเลือกและขั้นตอนที่เหมาะสมให้'
  ],
  [
    'q' => 'เครื่องติด iCloud / ติดล็อกไหม?',
    'a' => 'ไม่ขายเครื่องติดล็อก ทีมงานตรวจเช็ค iCloud/บัญชี/สภาพการใช้งานก่อนส่ง หากลูกค้าต้องการดูหลักฐานการรีเซ็ต/เปิดเครื่อง สามารถขอวิดีโอได้'
  ],
  [
    'q' => 'แบตเตอรี่ (iPhone) สุขภาพแบตประมาณเท่าไหร่?',
    'a' => 'ทีมงานสามารถแจ้งสุขภาพแบตให้ก่อนส่งตามรุ่น/ล็อตสินค้า หากต้องการขั้นต่ำสุขภาพแบตตามที่กำหนด แจ้งทีมงานได้เพื่อคัดเครื่องให้เหมาะสม'
  ],
  [
    'q' => 'มีอุปกรณ์อะไรให้บ้าง? ได้กล่อง/ที่ชาร์จไหม?',
    'a' => 'อุปกรณ์ขึ้นอยู่กับแต่ละเครื่อง/แต่ละล็อต บางเครื่องมีกล่องและอุปกรณ์เดิม บางเครื่องเป็นตัวเครื่องอย่างเดียว สามารถสอบถามรายการที่จะได้รับก่อนชำระเงินได้'
  ],
  [
    'q' => 'เช็คเครื่องก่อนส่งเช็คอะไรบ้าง?',
    'a' => 'เช็คหน้าจอ/ทัช/ปุ่ม/กล้อง/สัญญาณ/ลำโพง/ไมค์/ชาร์จ/แบต/Wi-Fi/บลูทูธ และทดสอบการใช้งานพื้นฐาน พร้อมทำความสะอาดก่อนแพ็คส่ง'
  ],
  [
    'q' => 'ถ้าได้รับเครื่องแล้วมีปัญหา ต้องทำยังไง?',
    'a' => 'ให้ทักมาทันทีทาง LINE หรือ Facebook พร้อมแจ้งอาการและส่งรูป/วิดีโอประกอบ ทีมงานช่วยตรวจสอบและแนะนำขั้นตอนเคลมตามเงื่อนไขรับประกัน'
  ],
  [
    'q' => 'สามารถขอดูรูป/วิดีโอเครื่องจริงก่อนซื้อได้ไหม?',
    'a' => 'ได้เลยครับ แจ้งรุ่น/งบ/ความจุที่ต้องการ ทีมงานจะส่งรูปจริง/วิดีโอให้ตรวจสอบก่อนตัดสินใจ'
  ],
  [
    'q' => 'รับซื้อ/เทิร์นเครื่องไหม?',
    'a' => 'รับพิจารณารับซื้อหรือเทิร์นในบางกรณี ให้ส่งรุ่น/ความจุ/สภาพ/รูปถ่ายมาทาง LINE หรือ Facebook ทีมงานประเมินราคาให้เบื้องต้น'
  ],
  [
    'q' => 'มีหน้าร้านไหม? อยู่ที่ไหน?',
    'a' => 'มีข้อมูลที่อยู่ร้านและแผนที่ในหน้า “ติดต่อเรา” หากต้องการนัดรับ/สอบถามเส้นทาง ทักแชทได้เลย'
  ],
  [
    'q' => 'ต้องการให้แนะนำรุ่นที่เหมาะกับงบ ทำได้ไหม?',
    'a' => 'ทำได้ครับ แจ้งงบประมาณ + ลักษณะการใช้งาน (เล่นเกม/ถ่ายรูป/ทำงาน/ใช้ทั่วไป) ทีมงานช่วยแนะนำรุ่นที่คุ้มที่สุดให้'
  ],
];
?>

<!-- =========================
     FAQ SECTION (ใหม่ สวยขึ้น)
     ========================= -->
<div class="feature-card">
  <h3 style="margin-top:0;">คำถามที่พบบ่อย (FAQ)</h3>

  <style>
    /* FAQ UI */
    .faq-wrap{ margin-top:12px; }
    .faq-toolbar{
      display:flex; gap:10px; flex-wrap:wrap;
      margin-bottom:12px;
    }
    .faq-search{
      flex:1 1 260px;
      padding:12px 14px;
      border-radius:12px;
      border:1px solid rgba(255,255,255,.15);
      background:rgba(0,0,0,.25);
      color:#fff;
      outline:none;
    }
    .faq-search::placeholder{ color: rgba(255,255,255,.55); }
    .faq-hint{
      flex:0 0 auto;
      font-size:13px;
      opacity:.75;
      display:flex;
      align-items:center;
      padding:10px 12px;
      border-radius:12px;
      border:1px solid rgba(255,255,255,.12);
      background:rgba(255,255,255,.04);
    }
    .faq-acc{
      border-radius:16px;
      overflow:hidden;
      border:1px solid rgba(255,255,255,.12);
      background:rgba(255,255,255,.03);
    }
    .faq-item{
      border-bottom:1px solid rgba(255,255,255,.08);
    }
    .faq-item:last-child{ border-bottom:none; }
    .faq-q{
      width:100%;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:14px 14px;
      cursor:pointer;
      background:transparent;
      border:none;
      color:#fff;
      text-align:left;
      font-weight:700;
      font-size:15px;
    }
    .faq-q:hover{
      background:rgba(255,255,255,.04);
    }
    .faq-q .icon{
      flex:0 0 auto;
      width:26px; height:26px;
      border-radius:10px;
      display:grid;
      place-items:center;
      background:rgba(251,191,36,.16);
      border:1px solid rgba(251,191,36,.25);
      color:#fbbf24;
      font-weight:900;
      transition:transform .2s ease;
    }
    .faq-q[aria-expanded="true"] .icon{
      transform: rotate(45deg);
    }
    .faq-a{
      display:none;
      padding:0 14px 14px 14px;
      color:rgba(255,255,255,.88);
      line-height:1.9;
      font-size:14px;
    }
    .faq-a.show{ display:block; }
    .faq-a .a-label{
      display:inline-block;
      margin-right:6px;
      font-weight:800;
      color:#fbbf24;
    }
    .faq-bottom{
      margin-top:12px;
      display:flex; flex-wrap:wrap; gap:10px;
      align-items:center;
      justify-content:space-between;
      opacity:.9;
      font-size:13px;
    }
    .faq-contact{
      display:flex; gap:10px; flex-wrap:wrap;
    }
    .faq-contact a{
      text-decoration:none;
      border-radius:12px;
      padding:10px 12px;
      border:1px solid rgba(255,255,255,.12);
      background:rgba(255,255,255,.04);
      color:#fff;
    }
    .faq-contact a:hover{
      background:rgba(255,255,255,.07);
    }

    /* mobile */
    @media (max-width: 576px){
      .faq-q{ font-size:14px; padding:13px 12px; }
      .faq-a{ padding:0 12px 12px 12px; }
      .faq-hint{ width:100%; }
    }
  </style>

  <div class="faq-wrap">
    <div class="faq-toolbar">
      <input id="faqSearch" class="faq-search" type="text" placeholder="ค้นหาคำถาม เช่น ประกัน / ส่งของ / COD / ผ่อน..." autocomplete="off">
      <div class="faq-hint">แตะคำถามเพื่อเปิดคำตอบ • รองรับมือถือ</div>
    </div>

    <div class="faq-acc" id="faqAcc">
      <?php foreach ($faqItems as $i => $it): ?>
        <div class="faq-item" data-q="<?= htmlspecialchars(mb_strtolower($it['q'])) ?>" data-a="<?= htmlspecialchars(mb_strtolower($it['a'])) ?>">
          <button class="faq-q" type="button" aria-expanded="false" aria-controls="faq-a-<?= $i ?>" data-target="faq-a-<?= $i ?>">
            <span><?= htmlspecialchars($it['q']) ?></span>
            <span class="icon">+</span>
          </button>
          <div class="faq-a" id="faq-a-<?= $i ?>">
            <span class="a-label">A:</span><?= htmlspecialchars($it['a']) ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="faq-bottom">
      <div>ยังไม่เจอคำตอบ? ทักเราได้เลย ทีมงานตอบไว</div>
      <div class="faq-contact">
        <a href="<?= htmlspecialchars($lineLink) ?>" target="_blank" rel="noopener">LINE: แชทด่วน</a>
        <a href="<?= htmlspecialchars($facebookPage) ?>" target="_blank" rel="noopener">Facebook: ดูรีวิว/ทักแชท</a>
      </div>
    </div>
  </div>

  <script>
    (function(){
      // Toggle FAQ
      const acc = document.getElementById('faqAcc');
      if(!acc) return;

      acc.addEventListener('click', function(e){
        const btn = e.target.closest('.faq-q');
        if(!btn) return;

        const id = btn.getAttribute('data-target');
        const panel = document.getElementById(id);
        if(!panel) return;

        const expanded = btn.getAttribute('aria-expanded') === 'true';
        // เปิดแบบ "ทีละอัน" เพื่อให้สวยและอ่านง่าย
        acc.querySelectorAll('.faq-q[aria-expanded="true"]').forEach(b=>{
          if(b !== btn){
            b.setAttribute('aria-expanded','false');
            const pid = b.getAttribute('data-target');
            const p = document.getElementById(pid);
            if(p) p.classList.remove('show');
          }
        });

        btn.setAttribute('aria-expanded', expanded ? 'false' : 'true');
        panel.classList.toggle('show', !expanded);
      });

      // Search FAQ
      const search = document.getElementById('faqSearch');
      if(search){
        search.addEventListener('input', function(){
          const v = (search.value || '').trim().toLowerCase();
          const items = acc.querySelectorAll('.faq-item');

          items.forEach(item=>{
            if(!v){
              item.style.display = '';
              return;
            }
            const q = item.getAttribute('data-q') || '';
            const a = item.getAttribute('data-a') || '';
            const ok = q.includes(v) || a.includes(v);
            item.style.display = ok ? '' : 'none';
          });
        });
      }
    })();
  </script>

  <!-- FAQ JSON-LD (ช่วย SEO ให้ดูเป็นเว็บน่าเชื่อถือขึ้น) -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      <?php foreach ($faqItems as $idx => $it): ?>
      {
        "@type": "Question",
        "name": "<?= htmlspecialchars($it['q'], ENT_QUOTES) ?>",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "<?= htmlspecialchars($it['a'], ENT_QUOTES) ?>"
        }
      }<?= ($idx < count($faqItems)-1) ? ',' : '' ?>
      <?php endforeach; ?>
    ]
  }
  </script>
</div>
