<?php
/**
 * Dynamic robots.txt Generator
 * อ่านค่า BASE_URL จาก config.php เพื่อให้แก้ไขโดเมนได้ที่เดียว
 * URL: /robots.txt (via .htaccess rewrite)
 * 
 * ถ้าต้องการเปลี่ยนโดเมน ให้แก้ที่ config.php -> BASE_URL เท่านั้น
 */
require_once 'config.php';

header('Content-Type: text/plain; charset=utf-8');
?>
# robots.txt for <?= SITE_NAME ?> Website
# Generated dynamically from config.php
# Domain: <?= BASE_URL ?>


User-agent: *
Allow: /
Allow: /videos.php
Allow: /video.php
Allow: /blog.php
Allow: /about.php
Allow: /contact.php
Allow: /warranty.php
Allow: /faq.php

# Sitemap
Sitemap: <?= BASE_URL ?>/sitemap.xml

# Disallow admin/private areas
Disallow: /admin/
Disallow: /includes/
Disallow: /data/
Disallow: /config.php
Disallow: /tracker.php
Disallow: /bot.php
Disallow: /click.php

# Crawl delay (optional, for polite crawling)
Crawl-delay: 1