<?php
/**
 * Header Include - Contains <head> section and navigation
 * @param string $pageTitle - Page title
 * @param string $pageDescription - Meta description
 * @param string $pageKeywords - Meta keywords
 * @param string $canonicalPath - Canonical URL path (e.g., '/about.php')
 */

if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../config.php';
}

$pageTitle = $pageTitle ?? SITE_NAME . ' - ' . SITE_TAGLINE;
$pageDescription = $pageDescription ?? SITE_DESCRIPTION;
$pageKeywords = $pageKeywords ?? 'มือถือมือสอง, โทรศัพท์มือสอง, ราคาถูก, รับประกัน, PG Mobile, สกลนคร';
$canonicalPath = $canonicalPath ?? '';
$canonicalURL = BASE_URL . $canonicalPath;
$ogImage = BASE_URL . '/' . OG_IMAGE;


// Load settings for Google Tag
$settingsFile = __DIR__ . '/../data/settings.json';
$googleTagId = '';

if (file_exists($settingsFile)) {
    $settings = json_decode(file_get_contents($settingsFile), true);
    if (!empty($settings['google_tag_id'])) {
        $googleTagId = $settings['google_tag_id'];
    }
}
?>
<!DOCTYPE html>
<html lang="th">

<head>
    <?php if ($googleTagId): ?>
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?= htmlspecialchars($googleTagId) ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag() { dataLayer.push(arguments); }
            gtag('js', new Date());

            gtag('config', '<?= htmlspecialchars($googleTagId) ?>');
        </script>
    <?php endif; ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Preconnect -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preconnect" href="https://www.google.com">

    <!-- SEO Meta -->
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <meta name="description" content="<?= htmlspecialchars($pageDescription) ?>">
    <meta name="keywords" content="<?= htmlspecialchars($pageKeywords) ?>">
    <meta name="author" content="<?= COMPANY_NAME ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?= htmlspecialchars($canonicalURL) ?>">

    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= htmlspecialchars($canonicalURL) ?>">
    <meta property="og:title" content="<?= htmlspecialchars($pageTitle) ?>">
    <meta property="og:description" content="<?= htmlspecialchars($pageDescription) ?>">
    <meta property="og:image" content="<?= htmlspecialchars($ogImage) ?>">
    <meta property="og:locale" content="th_TH">
    <meta property="og:site_name" content="<?= SITE_NAME ?>">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="<?= htmlspecialchars($canonicalURL) ?>">
    <meta name="twitter:title" content="<?= htmlspecialchars($pageTitle) ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($pageDescription) ?>">
    <meta name="twitter:image" content="<?= htmlspecialchars($ogImage) ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?= FAVICON ?>">
    <link rel="apple-touch-icon" href="<?= LOGO ?>">

    <!-- Google Fonts - Single request -->
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&display=swap" rel="stylesheet">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <!-- Minimal CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- Skip to main content for accessibility -->
    <a href="#main-content" class="skip-link">ข้ามไปยังเนื้อหาหลัก</a>

    <!-- Header -->
    <header class="header">
        <nav class="nav container">
            <a href="index.php" class="logo" aria-label="<?= SITE_NAME ?> หน้าแรก">
                <img src="<?= LOGO ?>" alt="<?= SITE_NAME ?> Logo" width="120" height="40" loading="eager">
            </a>

            <button class="nav-toggle" aria-label="เปิดเมนู" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </button>

            <ul class="nav-menu" role="menubar">
                <li role="none"><a href="index.php" class="nav-link <?= isActivePage('index') ?>"
                        role="menuitem">หน้าแรก</a></li>
                <li role="none"><a href="videos.php" class="nav-link <?= isActivePage('videos') ?>"
                        role="menuitem">วิดีโอ</a></li>
                <li role="none"><a href="blog.php" class="nav-link <?= isActivePage('blog') ?>" role="menuitem">Blog</a>
                </li>
                <li role="none"><a href="about.php" class="nav-link <?= isActivePage('about') ?>"
                        role="menuitem">เกี่ยวกับเรา</a></li>
                <li role="none"><a href="warranty.php" class="nav-link <?= isActivePage('warranty') ?>"
                        role="menuitem">การรับประกัน</a></li>
                <li role="none"><a href="contact.php" class="nav-link <?= isActivePage('contact') ?>"
                        role="menuitem">ติดต่อเรา</a></li>
            </ul>
        </nav>
    </header>

    <main id="main-content">