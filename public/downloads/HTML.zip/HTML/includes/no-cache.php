<?php
// =====================================================
// ✅ FILE: /includes/no-cache.php
// ป้องกัน Cache สำหรับ "หน้าเว็บ (HTML)" เพื่อไม่ให้ติดแคชตอนใช้งานจริง
// (แนะนำ: ใช้กับหน้า index.php / หน้า dynamic ที่ข้อมูลเปลี่ยนบ่อย)
// =====================================================

// กัน PHP session cache (ถ้ามี session)
if (function_exists('session_cache_limiter')) {
    @session_cache_limiter('nocache');
}

// Header กัน cache (HTML)
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
header('Expires: 0');

// กันบาง proxy / CDN แคชผิด
header('Surrogate-Control: no-store');

// กัน ETag บางกรณีทำให้ browser คิดว่าไม่ต้องโหลดใหม่
header_remove('ETag');
