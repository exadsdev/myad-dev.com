<?php
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../config.php';
}
?>
</main>

<!-- Trust Badges - Simple Row -->
<section class="py-3" style="background:#1e3a5f;">
    <div class="container">
        <div class="row text-center text-white small">
            <div class="col-6 col-md-3 py-2">
                <span class="fw-semibold">✓ รับประกัน 30 วัน</span>
            </div>
            <div class="col-6 col-md-3 py-2">
                <span class="fw-semibold">✓ เก็บเงินปลายทาง</span>
            </div>
            <div class="col-6 col-md-3 py-2">
                <span class="fw-semibold">✓ จัดส่งทั่วไทย</span>
            </div>
            <div class="col-6 col-md-3 py-2">
                <span class="fw-semibold">✓ ตรวจสอบก่อนส่ง</span>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer style="background:#0f172a; color:#94a3b8;">
    <div class="container py-4">
        <div class="row g-4">

            <!-- Column 1: Brand -->
            <div class="col-12 col-lg-3">
                <h5 class="text-white mb-2"><?= SITE_NAME ?></h5>
                <p class="small mb-3">ร้านขายมือถือ PG V9 คุณภาพดี ราคาถูก รับประกันทุกเครื่อง</p>
                <div class="d-flex gap-2">
                    <a href="https://www.facebook.com/pgmobiles" target="_blank" rel="noopener"
                        class="text-white opacity-75">
                        <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                            <path
                                d="M18.77,7.46H14.5v-1.9c0-.9.6-1.1,1-1.1h3V.5h-4.33C10.24.5,9.5,3.44,9.5,5.32v2.15h-3v4h3v12h5v-12h3.85l.42-4Z" />
                        </svg>
                    </a>
                    <a href="https://lin.ee/EAtjlIe" target="_blank" rel="noopener" class="text-white opacity-75">
                        <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                            <path
                                d="M12,.5C5.66.5.5,4.95.5,10.42c0,4.9,4.34,9,10.23,9.78.4.09.94.27,1.08.61.12.31.08.79.04,1.1l-.17,1c-.05.29-.22,1.16,1.01.63,1.23-.53,6.65-3.92,9.08-6.71h0C23.23,14.8,24,12.69,24,10.42,24,4.95,18.34.5,12,.5Z" />
                        </svg>
                    </a>
                </div>
            </div>

            <!-- Column 2: Address -->
            <div class="col-6 col-lg-3">
                <h6 class="text-white mb-3">ที่อยู่ร้าน</h6>
                <p class="small mb-2"><?= COMPANY_ADDRESS ?></p>
                <p class="small mb-0"><strong>เวลา:</strong> 09:00-21:00 น.</p>
            </div>

            <!-- Column 3: Contact -->
            <div class="col-6 col-lg-3">
                <h6 class="text-white mb-3">ติดต่อเรา</h6>
                <ul class="list-unstyled small mb-0">
                    <li class="mb-1"><a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>"
                            class="text-reset text-decoration-none"><?= COMPANY_PHONE ?></a></li>
                    <li class="mb-1"><a href="mailto:<?= COMPANY_EMAIL ?>"
                            class="text-reset text-decoration-none"><?= COMPANY_EMAIL ?></a></li>
                    <li class="mb-1"><a href="https://lin.ee/EAtjlIe" target="_blank"
                            class="text-reset text-decoration-none">LINE: @pgmobile</a></li>
                </ul>
            </div>

            <!-- Column 4: Links -->
            <div class="col-12 col-lg-3">
                <h6 class="text-white mb-3">นโยบาย</h6>
                <ul class="list-unstyled small mb-0 d-flex flex-wrap gap-2">
                    <li><a href="privacy.php" class="text-reset text-decoration-none">ความเป็นส่วนตัว</a></li>
                    <li>|</li>
                    <li><a href="terms.php" class="text-reset text-decoration-none">ข้อกำหนด</a></li>
                    <li>|</li>
                    <li><a href="refund-policy.php" class="text-reset text-decoration-none">คืนสินค้า</a></li>
                    <li>|</li>
                    <li><a href="warranty.php" class="text-reset text-decoration-none">รับประกัน</a></li>
                </ul>
            </div>

        </div>

        <!-- Bottom -->
        <div class="border-top border-secondary pt-3 mt-4">
            <div class="row small">
                <div class="col-12 col-md-6 text-center text-md-start mb-2 mb-md-0">
                    © <?= date('Y') ?> <?= COMPANY_NAME ?>
                </div>
                <div class="col-12 col-md-6 text-center text-md-end opacity-75">
                    เลขทะเบียน: <img src="images/pgmobile.jpg" alt="ใบทะเบียนพาณิชย์" width="80"
                        style="vertical-align:middle; margin-left:5px;"> <?= COMPANY_REGISTRATION ?>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Floating LINE Button -->
<a href="https://lin.ee/EAtjlIe" target="_blank" rel="noopener" class="floating-btn" aria-label="LINE"
    style="background:#06C755; width:40px; height:40px;">
    <svg width="22" height="22" fill="#fff" viewBox="0 0 24 24">
        <path
            d="M12,.5C5.66.5.5,4.95.5,10.42c0,4.9,4.34,9,10.23,9.78.4.09.94.27,1.08.61.12.31.08.79.04,1.1l-.17,1c-.05.29-.22,1.16,1.01.63,1.23-.53,6.65-3.92,9.08-6.71h0C23.23,14.8,24,12.69,24,10.42,24,4.95,18.34.5,12,.5Z" />
    </svg>
</a>

<style>
    footer a:hover {
        color: #fff !important;
    }

    .floating-btn {
        animation: pulse-line 2s infinite;
    }

    @keyframes pulse-line {

        0%,
        100% {
            box-shadow: 0 0 0 0 rgba(6, 199, 85, .5);
        }

        50% {
            box-shadow: 0 0 0 12px transparent;
        }
    }
</style>

<script defer src="assets/js/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
    crossorigin="anonymous"></script>
</body>

</html>