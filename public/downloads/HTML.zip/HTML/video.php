<?php
/**
 * หน้ารายละเอียดวิดีโอ - SEO Heavy Version
 * URL: /video.php?slug=pg
 * 
 * SEO Features:
 * - H1 + บทนำ 200-400 คำ
 * - Transcript with timecodes (600-1200+ words)
 * - Key Takeaways (6-10 bullet points)
 * - FAQ (8-12 questions) with FAQPage schema
 * - VideoObject, BreadcrumbList, FAQPage JSON-LD
 * - Full meta tags (title, description, canonical, OG, Twitter)
 * 
 * Performance Critical:
 * - LCP: ไม่โหลด YouTube iframe ทันที ใช้ click-to-load
 * - CLS: ล็อก aspect-ratio 16:9 ไว้ล่วงหน้า
 * - INP: JS เบามากใช้เฉพาะ click handler
 */
require_once 'config.php';
require_once 'data/videos.php';

// Get video from slug
$slug = isset($_GET['slug']) ? trim($_GET['slug']) : '';
$video = getVideoBySlug($slug);

// 404 if video not found
if (!$video) {
    http_response_code(404);
    include '404.php';
    exit;
}

// Get video URLs
$videoUrls = getVideoUrls($video, BASE_URL);

// Page metadata
$pageTitle = $video['title'] . ' | ' . SITE_NAME;
$pageDescription = mb_substr($video['description'], 0, 160) . '...';
$pageKeywords = $video['keywords'] ?? implode(', ', $video['tags'] ?? []);
$canonicalPath = '/video.php?slug=' . urlencode($video['slug']);
$ogImage = $videoUrls['thumbnailUrl'];

include 'includes/header.php';
?>

<!-- Override OG tags for video page -->
<script>
    (function () {
        var ogImage = document.querySelector('meta[property="og:image"]');
        var twitterImage = document.querySelector('meta[name="twitter:image"]');
        if (ogImage) ogImage.setAttribute('content', '<?= htmlspecialchars($videoUrls['thumbnailUrl']) ?>');
        if (twitterImage) twitterImage.setAttribute('content', '<?= htmlspecialchars($videoUrls['thumbnailUrl']) ?>');
    })();
</script>

<!-- JSON-LD: VideoObject -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "VideoObject",
    "name": "<?= htmlspecialchars($video['title']) ?>",
    "description": "<?= htmlspecialchars($video['description']) ?>",
    "thumbnailUrl": [
        "<?= htmlspecialchars($videoUrls['thumbnailUrl']) ?>",
        "<?= htmlspecialchars($videoUrls['thumbnailMaxRes']) ?>"
    ],
    "uploadDate": "<?= $video['uploadDate'] ?>",
    "duration": "<?= $video['duration'] ?>",
    "contentUrl": "<?= htmlspecialchars($videoUrls['contentUrl']) ?>",
    "embedUrl": "<?= htmlspecialchars($videoUrls['embedUrl']) ?>",
    "publisher": {
        "@type": "Organization",
        "name": "<?= SITE_NAME ?>",
        "logo": {
            "@type": "ImageObject",
            "url": "<?= BASE_URL ?>/<?= LOGO ?>"
        }
    },
    "potentialAction": {
        "@type": "WatchAction",
        "target": "<?= htmlspecialchars($videoUrls['contentUrl']) ?>"
    },
    "interactionStatistic": {
        "@type": "InteractionCounter",
        "interactionType": "https://schema.org/WatchAction",
        "userInteractionCount": 1000
    }
}
</script>

<!-- JSON-LD: BreadcrumbList -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
        {
            "@type": "ListItem",
            "position": 1,
            "name": "หน้าแรก",
            "item": "<?= BASE_URL ?>/"
        },
        {
            "@type": "ListItem",
            "position": 2,
            "name": "วิดีโอ",
            "item": "<?= BASE_URL ?>/videos.php"
        },
        {
            "@type": "ListItem",
            "position": 3,
            "name": "<?= htmlspecialchars($video['shortTitle'] ?? $video['title']) ?>",
            "item": "<?= BASE_URL ?>/video.php?slug=<?= urlencode($video['slug']) ?>"
        }
    ]
}
</script>

<!-- JSON-LD: FAQPage -->
<?php if (!empty($video['faq'])): ?>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            <?php foreach ($video['faq'] as $index => $faqItem): ?>
                {
                    "@type": "Question",
                    "name": "<?= htmlspecialchars($faqItem['question']) ?>",
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": "<?= htmlspecialchars($faqItem['answer']) ?>"
                    }
                }<?= $index < count($video['faq']) - 1 ? ',' : '' ?>
            <?php endforeach; ?>
        ]
    }
    </script>
<?php endif; ?>

<style>
    /* Critical CSS for Video Detail - Prevents CLS */

    /* CLS Prevention: Fixed aspect ratio container */
    .video-container {
        position: relative;
        width: 100%;
        aspect-ratio: 16 / 9;
        background: #000;
        border-radius: 12px;
        overflow: hidden;
        cursor: pointer;
    }

    /* Thumbnail placeholder (before iframe load) */
    .video-placeholder {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .video-placeholder img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    /* Play button */
    .video-play-btn {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 80px;
        height: 80px;
        background: rgba(255, 0, 0, 0.9);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.2s ease, background 0.2s ease;
        z-index: 2;
        border: none;
        cursor: pointer;
    }

    .video-container:hover .video-play-btn {
        transform: translate(-50%, -50%) scale(1.1);
        background: rgba(255, 0, 0, 1);
    }

    .video-play-btn svg {
        width: 32px;
        height: 32px;
        fill: #fff;
        margin-left: 6px;
    }

    /* YouTube iframe (loaded on click) */
    .video-iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: 0;
    }

    /* Video info section */
    .video-detail-header {
        padding: 1.5rem 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 2rem;
    }

    .video-detail-title {
        font-size: 1.75rem;
        font-weight: 700;
        color: #1a1a2e;
        margin: 0 0 1rem;
        line-height: 1.3;
    }

    .video-detail-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 1.5rem;
        font-size: 0.9rem;
        color: #666;
    }

    .video-detail-meta span {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* Content sections */
    .content-section {
        margin-bottom: 3rem;
    }

    .content-section h2 {
        font-size: 1.5rem;
        font-weight: 700;
        color: #1a1a2e;
        margin-bottom: 1.25rem;
        padding-bottom: 0.75rem;
        border-bottom: 2px solid #e2e8f0;
    }

    .content-section h3 {
        font-size: 1.25rem;
        font-weight: 600;
        color: #2d3748;
        margin: 1.5rem 0 1rem;
    }

    .content-section p {
        font-size: 1rem;
        color: #4a5568;
        line-height: 1.8;
        margin-bottom: 1rem;
    }

    /* Introduction */
    .video-intro {
        font-size: 1.1rem;
        line-height: 1.9;
        color: #374151;
    }

    .video-intro p {
        margin-bottom: 1.25rem;
    }

    /* Key Takeaways */
    .key-takeaways {
        background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
        border-radius: 12px;
        padding: 1.5rem;
        margin: 1.5rem 0;
    }

    .key-takeaways h2 {
        color: #166534;
        border-bottom-color: #86efac;
    }

    .key-takeaways ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .key-takeaways li {
        padding: 0.75rem 0;
        padding-left: 2rem;
        position: relative;
        color: #166534;
        font-weight: 500;
        border-bottom: 1px solid rgba(22, 101, 52, 0.1);
    }

    .key-takeaways li:last-child {
        border-bottom: none;
    }

    .key-takeaways li::before {
        content: "✓";
        position: absolute;
        left: 0;
        color: #22c55e;
        font-weight: 700;
    }

    /* Transcript */
    .transcript-section {
        background: #f8fafc;
        border-radius: 12px;
        padding: 1.5rem;
    }

    .transcript-item {
        display: flex;
        gap: 1rem;
        padding: 1rem 0;
        border-bottom: 1px solid #e2e8f0;
    }

    .transcript-item:last-child {
        border-bottom: none;
    }

    .transcript-time {
        flex-shrink: 0;
        background: #1a1a2e;
        color: #fff;
        padding: 0.25rem 0.75rem;
        border-radius: 4px;
        font-size: 0.85rem;
        font-family: monospace;
        height: fit-content;
    }

    .transcript-text {
        color: #4a5568;
        line-height: 1.7;
    }

    /* FAQ Section */
    .faq-section {
        background: #fff;
    }

    .faq-item {
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        margin-bottom: 1rem;
        overflow: hidden;
    }

    .faq-question {
        background: #f8fafc;
        padding: 1rem 1.25rem;
        font-weight: 600;
        color: #1a1a2e;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .faq-question::after {
        content: "+";
        font-size: 1.5rem;
        color: #64748b;
        transition: transform 0.2s;
    }

    .faq-item.open .faq-question::after {
        transform: rotate(45deg);
    }

    .faq-answer {
        padding: 0 1.25rem;
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease, padding 0.3s ease;
    }

    .faq-item.open .faq-answer {
        padding: 1.25rem;
        max-height: 500px;
    }

    .faq-answer p {
        margin: 0;
        color: #4a5568;
        line-height: 1.7;
    }

    /* Related Videos/Links */
    .related-section {
        background: #f8fafc;
        border-radius: 12px;
        padding: 1.5rem;
    }

    .related-links {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 1rem;
    }

    .related-link {
        display: block;
        background: #fff;
        padding: 1rem;
        border-radius: 8px;
        text-decoration: none;
        color: #1a1a2e;
        font-weight: 500;
        transition: box-shadow 0.2s, transform 0.2s;
        border: 1px solid #e2e8f0;
    }

    .related-link:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        transform: translateY(-2px);
    }

    /* CTA Section */
    .video-cta {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border-radius: 12px;
        padding: 2.5rem;
        text-align: center;
        color: #fff;
        margin: 2rem 0;
    }

    .video-cta h3 {
        font-size: 1.5rem;
        margin: 0 0 0.5rem;
        color: #fff;
    }

    .video-cta p {
        opacity: 0.9;
        margin-bottom: 1.5rem;
        color: #fff;
    }

    .video-cta .btn-primary {
        background: #06C755;
        color: #fff;
        border: none;
        padding: 1rem 2.5rem;
        font-size: 1.1rem;
        font-weight: 600;
        border-radius: 50px;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .video-cta .btn-primary:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 20px rgba(6, 199, 85, 0.4);
    }

    .video-cta .btn-secondary {
        background: transparent;
        color: #fff;
        border: 2px solid #fff;
        padding: 0.75rem 1.5rem;
        font-weight: 600;
        border-radius: 50px;
        text-decoration: none;
        display: inline-block;
        margin-top: 1rem;
        transition: background 0.2s ease;
    }

    .video-cta .btn-secondary:hover {
        background: rgba(255, 255, 255, 0.1);
    }

    /* Back link */
    .back-link {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        color: #2563eb;
        text-decoration: none;
        font-weight: 500;
        margin-top: 1rem;
    }

    .back-link:hover {
        text-decoration: underline;
    }

    @media (max-width: 768px) {
        .video-detail-title {
            font-size: 1.35rem;
        }

        .video-play-btn {
            width: 60px;
            height: 60px;
        }

        .video-play-btn svg {
            width: 24px;
            height: 24px;
        }

        .content-section h2 {
            font-size: 1.25rem;
        }

        .transcript-item {
            flex-direction: column;
            gap: 0.5rem;
        }

        .video-cta {
            padding: 1.5rem;
        }

        .related-links {
            grid-template-columns: 1fr;
        }
    }
</style>

<!-- Breadcrumb -->
<nav class="container py-3" aria-label="breadcrumb">
    <ol class="breadcrumb mb-0" style="font-size: 0.875rem;">
        <li class="breadcrumb-item"><a href="index.php">หน้าแรก</a></li>
        <li class="breadcrumb-item"><a href="videos.php">วิดีโอ</a></li>
        <li class="breadcrumb-item active" aria-current="page">
            <?= htmlspecialchars($video['shortTitle'] ?? $video['title']) ?></li>
    </ol>
</nav>

<!-- Video Content -->
<article class="container pb-5">

    <!-- Video Player with Click-to-Load -->
    <div class="video-container" id="videoPlayer" data-youtube-id="<?= htmlspecialchars($video['youtubeId']) ?>"
        role="button" aria-label="เล่นวิดีโอ <?= htmlspecialchars($video['title']) ?>">

        <!-- Placeholder: Thumbnail + Play Button -->
        <div class="video-placeholder" id="videoPlaceholder">
            <img src="<?= htmlspecialchars($videoUrls['thumbnailUrl']) ?>"
                alt="<?= htmlspecialchars($video['title']) ?>" width="1280" height="720" loading="eager"
                fetchpriority="high" onerror="this.src='<?= htmlspecialchars($videoUrls['thumbnailUrl']) ?>'">
            <button class="video-play-btn" type="button" aria-label="เล่นวิดีโอ">
                <svg viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                </svg>
            </button>
        </div>
    </div>

    <!-- Video Header -->
    <header class="video-detail-header">
        <h1 class="video-detail-title"><?= htmlspecialchars($video['title']) ?></h1>
        <div class="video-detail-meta">
            <span>⏱ ความยาว: <?= htmlspecialchars($video['durationDisplay']) ?></span>
            <span>📅 เผยแพร่: <?= htmlspecialchars($video['publishedDateDisplay']) ?></span>
            <span>🏷️ <?= htmlspecialchars(implode(', ', array_slice($video['tags'] ?? [], 0, 3))) ?></span>
        </div>
    </header>

    <!-- Introduction Section (200-400 words) -->
    <section class="content-section video-intro">
        <h2>เกี่ยวกับวิดีโอนี้</h2>
        <p>
            ยินดีต้อนรับสู่วิดีโอรีวิว <strong>PG Mobile V9</strong> มือถือมือสองคุณภาพดีจากร้าน PG Mobile
            ในวิดีโอนี้เราจะพาคุณไปดูรายละเอียดของสินค้า ตั้งแต่สภาพภายนอก คุณภาพหน้าจอ ประสิทธิภาพการใช้งาน
            กล้องถ่ายรูป แบตเตอรี่ และทุกฟีเจอร์ที่สำคัญ เพื่อให้คุณมั่นใจก่อนตัดสินใจซื้อ
        </p>
        <p>
            ร้าน PG Mobile เป็นร้านขายมือถือมือสองที่ได้รับความไว้วางใจจากลูกค้าทั่วประเทศไทย
            เราตั้งอยู่ที่จังหวัดสกลนคร และให้บริการจัดส่งสินค้าถึงบ้านทั่วประเทศ ทุกเครื่องที่เราขาย
            ผ่านกระบวนการตรวจสอบคุณภาพ (Quality Control) อย่างละเอียดทุกขั้นตอน
            ตั้งแต่การตรวจสอบหน้าจอ ทัชสกรีน ลำโพง ไมโครโฟน กล้องหน้า กล้องหลัง เซ็นเซอร์ต่างๆ
            ไปจนถึงการทดสอบระบบปฏิบัติการและแอปพลิเคชัน
        </p>
        <p>
            <strong>สิ่งที่คุณจะได้เรียนรู้จากวิดีโอนี้:</strong>
        </p>
        <ul style="color: #4a5568; line-height: 2;">
            <li>รายละเอียดสเปคและคุณสมบัติของ PG Mobile V9</li>
            <li>กระบวนการตรวจสอบคุณภาพก่อนจัดส่ง</li>
            <li>การรับประกันสินค้า 30 วันเต็ม</li>
            <li>วิธีการสั่งซื้อและช่องทางการชำระเงิน</li>
            <li>บริการจัดส่งและการรับเงินปลายทาง</li>
        </ul>
        <p>
            ไม่ว่าคุณจะกำลังมองหามือถือเครื่องใหม่ในราคาประหยัด หรือต้องการเครื่องสำรองไว้ใช้งาน
            วิดีโอนี้จะช่วยให้คุณเห็นภาพชัดเจนว่าสินค้าจากร้านเราเป็นอย่างไร คุณภาพดีแค่ไหน
            และทำไมลูกค้าหลายพันคนถึงเลือกซื้อมือถือมือสองจาก PG Mobile
        </p>
    </section>

    <!-- Key Takeaways -->
    <?php if (!empty($video['keyTakeaways'])): ?>
        <section class="content-section key-takeaways">
            <h2>ไฮไลต์สำคัญ</h2>
            <ul>
                <?php foreach ($video['keyTakeaways'] as $takeaway): ?>
                    <li><?= htmlspecialchars($takeaway) ?></li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endif; ?>

    <!-- Suitable For Section -->
    <section class="content-section">
        <h2>เหมาะกับใครบ้าง?</h2>
        <div class="row g-4">
            <div class="col-md-6">
                <h3>👨‍🎓 นักเรียน นักศึกษา</h3>
                <p>
                    สำหรับนักเรียนนักศึกษาที่มีงบประมาณจำกัด มือถือมือสองคุณภาพดีจาก PG Mobile
                    เป็นทางเลือกที่ดีมาก ได้เครื่องสเปคดี ใช้งานได้ครบทุกฟังก์ชัน ในราคาที่จับต้องได้
                </p>
            </div>
            <div class="col-md-6">
                <h3>👨‍💼 พนักงานออฟฟิศ</h3>
                <p>
                    ต้องการเครื่องไว้ใช้งานทั่วไป โทร แชท อีเมล์ ดูเอกสาร ประชุมออนไลน์
                    มือถือมือสองตอบโจทย์การใช้งานประจำวันได้อย่างสมบูรณ์แบบ
                </p>
            </div>
            <div class="col-md-6">
                <h3>📱 ต้องการเครื่องสำรอง</h3>
                <p>
                    มีเครื่องหลักอยู่แล้ว แต่ต้องการเครื่องสำรองไว้ใช้กรณีเครื่องหลักเสียหรือแบตหมด
                    มือถือมือสองเป็นตัวเลือกที่คุ้มค่าที่สุด
                </p>
            </div>
            <div class="col-md-6">
                <h3>👴 ผู้สูงอายุ</h3>
                <p>
                    สำหรับผู้สูงอายุที่ต้องการมือถือใช้งานง่าย โทรหาลูกหลาน วิดีโอคอล
                    ไม่จำเป็นต้องซื้อเครื่องใหม่ราคาแพง มือถือมือสองก็ตอบโจทย์ได้ดี
                </p>
            </div>
        </div>
    </section>

    <!-- Transcript Section -->
    <?php if (!empty($video['transcript'])): ?>
        <section class="content-section transcript-section">
            <h2>บทถอดความวิดีโอ (Transcript)</h2>
            <p style="margin-bottom: 1rem; color: #64748b; font-size: 0.9rem;">
                อ่านเนื้อหาทั้งหมดในวิดีโอ พร้อม Timecode สำหรับการอ้างอิง
            </p>
            <?php foreach ($video['transcript'] as $item): ?>
                <div class="transcript-item">
                    <span class="transcript-time"><?= htmlspecialchars($item['time']) ?></span>
                    <p class="transcript-text"><?= htmlspecialchars($item['text']) ?></p>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <!-- How to Order Section -->
    <section class="content-section">
        <h2>ขั้นตอนการสั่งซื้อ</h2>
        <div class="row g-4">
            <div class="col-md-3 text-center">
                <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">1️⃣</div>
                <h3 style="font-size: 1rem;">ติดต่อสอบถาม</h3>
                <p style="font-size: 0.9rem;">ทัก LINE หรือโทรสอบถามรุ่นและสีที่ต้องการ</p>
            </div>
            <div class="col-md-3 text-center">
                <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">2️⃣</div>
                <h3 style="font-size: 1rem;">รับภาพสินค้าจริง</h3>
                <p style="font-size: 0.9rem;">เราส่งภาพเครื่องจริงให้ดูก่อนตัดสินใจ</p>
            </div>
            <div class="col-md-3 text-center">
                <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">3️⃣</div>
                <h3 style="font-size: 1rem;">ยืนยันสั่งซื้อ</h3>
                <p style="font-size: 0.9rem;">แจ้งที่อยู่จัดส่ง เลือก COD หรือโอนเงิน</p>
            </div>
            <div class="col-md-3 text-center">
                <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">4️⃣</div>
                <h3 style="font-size: 1rem;">รับสินค้า</h3>
                <p style="font-size: 0.9rem;">รอรับสินค้าที่บ้าน 1-3 วันทำการ</p>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <?php if (!empty($video['faq'])): ?>
        <section class="content-section faq-section">
            <h2>คำถามที่พบบ่อย (FAQ)</h2>
            <?php foreach ($video['faq'] as $index => $faqItem): ?>
                <div class="faq-item" id="faq-<?= $index ?>">
                    <div class="faq-question" onclick="toggleFaq(<?= $index ?>)">
                        <?= htmlspecialchars($faqItem['question']) ?>
                    </div>
                    <div class="faq-answer">
                        <p><?= htmlspecialchars($faqItem['answer']) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </section>
    <?php endif; ?>

    <!-- CTA Section -->
    <section class="video-cta">
        <h3>สนใจมือถือคุณภาพดี ราคาถูก?</h3>
        <p>รับประกัน 30 วันเต็ม จัดส่งฟรีทั่วประเทศ รับเงินปลายทาง</p>
        <a href="https://lin.ee/EAtjlIe" target="_blank" rel="noopener" class="btn-primary">
            <svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                <path
                    d="M12,.5C5.66.5.5,4.95.5,10.42c0,4.9,4.34,9,10.23,9.78.4.09.94.27,1.08.61.12.31.08.79.04,1.1l-.17,1c-.05.29-.22,1.16,1.01.63,1.23-.53,6.65-3.92,9.08-6.71h0C23.23,14.8,24,12.69,24,10.42,24,4.95,18.34.5,12,.5Z" />
            </svg>
            ติดต่อผ่าน LINE
        </a>
        <br>
        <a href="tel:<?= str_replace('-', '', COMPANY_PHONE) ?>" class="btn-secondary">
            📞 โทร <?= COMPANY_PHONE ?>
        </a>
    </section>

    <!-- Related Links -->
    <?php if (!empty($video['relatedLinks'])): ?>
        <section class="content-section related-section">
            <h2>หน้าที่เกี่ยวข้อง</h2>
            <div class="related-links">
                <?php foreach ($video['relatedLinks'] as $link): ?>
                    <a href="<?= htmlspecialchars($link['url']) ?>" class="related-link">
                        → <?= htmlspecialchars($link['title']) ?>
                    </a>
                <?php endforeach; ?>
                <a href="videos.php" class="related-link">
                    → ดูวิดีโอทั้งหมด
                </a>
            </div>
        </section>
    <?php endif; ?>

    <!-- Back to Videos -->
    <a href="videos.php" class="back-link">
        ← กลับไปหน้ารายการวิดีโอ
    </a>

</article>

<!-- Minimal JavaScript for FAQ and Video Lazy Load -->
<script>
    // Click-to-Load YouTube Embed
    (function () {
        var player = document.getElementById('videoPlayer');
        var placeholder = document.getElementById('videoPlaceholder');

        if (!player || !placeholder) return;

        function loadVideo() {
            var youtubeId = player.getAttribute('data-youtube-id');
            if (!youtubeId) return;

            // Create iframe
            var iframe = document.createElement('iframe');
            iframe.className = 'video-iframe';
            iframe.src = 'https://www.youtube.com/embed/' + youtubeId + '?autoplay=1&rel=0';
            iframe.title = 'YouTube video player';
            iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
            iframe.allowFullscreen = true;

            // Replace placeholder with iframe
            placeholder.style.display = 'none';
            player.appendChild(iframe);
            player.style.cursor = 'default';

            // Remove click listener
            player.removeEventListener('click', loadVideo);
        }

        player.addEventListener('click', loadVideo);
    })();

    // FAQ Toggle
    function toggleFaq(index) {
        var item = document.getElementById('faq-' + index);
        if (item) {
            item.classList.toggle('open');
        }
    }

    // Auto-open first FAQ
    document.addEventListener('DOMContentLoaded', function () {
        var firstFaq = document.getElementById('faq-0');
        if (firstFaq) {
            firstFaq.classList.add('open');
        }
    });
</script>

<?php include 'includes/footer.php'; ?>