// src/app/about/page.js
import Image from 'next/image';
import Link from 'next/link';
import siteConfig from '@/config/site';

export const metadata = {
    title: `รู้จัก PG Mobile ร้านมือถือมือสองคุณภาพดี สกลนคร - ${siteConfig.name}`,
    description: 'รู้จัก PG Mobile ร้านขายมือถือมือสอง สภาพนางฟ้า จดทะเบียนพาณิชย์ถูกต้อง ให้บริการลูกค้าทั่วไทยกว่า 5,000 ราย ประสบการณ์กว่า 5 ปี พร้อมรับประกัน 30 วัน',
    keywords: 'ทีมงาน PG Mobile, ร้านมือถือคำตากล้า, มือถือมือสองสกลนคร, ประวัติ PG Mobile, ร้านมือถือที่เชื่อถือได้',
    alternates: {
        canonical: `${siteConfig.baseUrl}/about`,
    },
};

export default function AboutPage() {
    const stats = [
        { number: '5+', label: 'ปีแห่งความเชี่ยวชาญ', desc: 'ในตลาดมือถือคัดเกรด' },
        { number: '5,000+', label: 'ครอบครัวลูกค้า', desc: 'ที่ไว้วางใจใช้บริการเรา' },
        { number: '4.9/5', label: 'คะแนนรีวิวจริง', desc: 'ความพึงพอใจสูงสุด' },
        { number: '100%', label: 'ตรวจเช็คละเอียด', desc: 'ทุกเครื่องก่อนถึงมือคุณ' },
    ];

    return (
        <main id="about-us-page">
            {/* Page Header - Semantic H1 */}
            <header className="page-header">
                <div className="container">
                    <h1 style={{ fontSize: '2.5rem', marginBottom: '10px' }}>เกี่ยวกับเรา PG Mobile</h1>
                    <p style={{ fontSize: '1.2rem', opacity: 0.9 }}>ร้านมือถือมือสองที่ยืนหนึ่งเรื่องคุณภาพและการบริการที่จริงใจ</p>
                </div>
            </header>

            {/* SGE / Direct Answer Section */}
            <section className="section" style={{ paddingBottom: 0 }}>
                <div className="container">
                    <div
                        className="feature-card"
                        style={{
                            borderLeft: '4px solid var(--accent)',
                            backgroundColor: 'rgba(251, 191, 36, 0.05)',
                            padding: '24px'
                        }}
                    >
                        <h2 style={{ fontSize: '1.4rem', margin: '0 0 12px' }}>สรุปข้อมูล PG Mobile ใน 1 นาที</h2>
                        <p style={{ lineHeight: 1.8, margin: 0 }}>
                            <strong>PG Mobile</strong> คือร้านจำหน่ายสมาร์ทโฟนมือสองคุณภาพสูง (คัดเกรด A+) ตั้งอยู่ในอำเภอคำตากล้า จังหวัดสกลนคร
                            เราจดทะเบียนพาณิชย์ถูกต้องภายใต้ชื่อ <strong>{siteConfig.company.nameTh}</strong> (เลขทะเบียน: {siteConfig.company.registration})
                            เปิดให้บริการมานานกว่า 5 ปี โดยเน้นการขายเครื่องสภาพสวย แบตอึด ใช้งานปกติ 100% พร้อมบริการจัดส่งด่วนทั่วไทยและรับประกันสินค้า 30 วันเต็ม
                        </p>
                    </div>
                </div>
            </section>

            {/* About Content - Semantic Articles */}
            <section className="section">
                <div className="container">
                    <div className="about-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '40px', alignItems: 'center' }}>
                        <article className="about-text">
                            <h2 style={{ fontSize: '1.8rem', color: 'var(--accent)', marginBottom: '15px' }}>จุดเริ่มต้นของเรา</h2>
                            <p style={{ lineHeight: 1.8, marginBottom: '20px' }}>
                                <strong>PG Mobile</strong> เกิดจากวิสัยทัศน์ที่ต้องการให้คนไทยได้เข้าถึงเทคโนโลยีสมาร์ทโฟนระดับโลกในราคาที่คุ้มค่า
                                เราคัดเลือกเฉพาะเครื่องที่สภาพดีที่สุดเหมือนใหม่ (สภาพนางฟ้า) เพื่อส่งต่อให้ลูกค้า
                                โดยไม่ต้องกังวลเรื่องปัญหาการซ่อนเร้นหรือตำหนิที่ไม่ได้แจ้ง
                            </p>
                            <p style={{ lineHeight: 1.8 }}>
                                จากร้านค้าท้องถิ่นในสกลนคร เราเติบโตสู่การเป็นร้านค้าออนไลน์ที่เป็นที่ยอมรับระดับประเทศ
                                ด้วยยอดขายรวมกว่า 5,000 เครื่อง และการบอกต่อแบบปากต่อปากจากลูกค้าที่ประทับใจในคุณภาพสินค้าและการดูแลหลังการขายที่เป็นกันเอง
                            </p>
                        </article>

                        <aside className="about-image-wrapper">
                            <figure>
                                <Image
                                    src="/images/Commercial-registration.jpg"
                                    alt="หลักฐานใบจดทะเบียนพาณิชย์ PG Mobile กรมพัฒนาธุรกิจการค้า เพื่อความเชื่อมั่นของลูกค้า"
                                    width={800}
                                    height={600}
                                    style={{ borderRadius: '12px', boxShadow: '0 10px 30px rgba(0,0,0,0.2)' }}
                                    loading="lazy"
                                />
                                <figcaption style={{ marginTop: '10px', textAlign: 'center', fontSize: '0.9rem', opacity: 0.7 }}>
                                    ใบจดทะเบียนพาณิชย์ถูกต้องตามกฎหมาย ตรวจสอบได้ 100%
                                </figcaption>
                            </figure>
                        </aside>
                    </div>

                    <hr style={{ margin: '60px 0', border: 0, borderTop: '1px solid var(--border)' }} />

                    <div className="about-values" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '30px' }}>
                        <article className="value-item">
                            <h3 style={{ fontSize: '1.4rem', marginBottom: '12px' }}>💎 คุณภาพระดับพรีเมียม</h3>
                            <p style={{ lineHeight: 1.7, opacity: 0.9 }}>
                                สินค้าทุกเครื่องต้องผ่านการ QC (Quality Control) อย่างเข้มงวด 20 จุดสำคัญ
                                ทั้งหน้าจอ กล้อง ลำโพง สัญญาณโทรศัพท์ และสุขภาพแบตเตอรี่ที่ต้องอยู่ในเกณฑ์ดีเยี่ยมเท่านั้น
                            </p>
                        </article>

                        <article className="value-item">
                            <h3 style={{ fontSize: '1.4rem', marginBottom: '12px' }}>🤝 ความซื่อสัตย์เป็นหัวใจ</h3>
                            <p style={{ lineHeight: 1.7, opacity: 0.9 }}>
                                เราแจ้งสภาพสินค้าตามจริงทุกประเด็น ไม่มีหมกเม็ดตำหนิ พร้อมส่งวิดีโอแกะกล่องและทดสอบเครื่องจริงให้ลูกค้าดูก่อนชำระเงิน
                                เพื่อความสบายใจสูงสุดของผู้ซื้อ
                            </p>
                        </article>

                        <article className="value-item">
                            <h3 style={{ fontSize: '1.4rem', marginBottom: '12px' }}>🛡️ การรับประกันที่เชื่อถือได้</h3>
                            <p style={{ lineHeight: 1.7, opacity: 0.9 }}>
                                รับประกันสินค้า 30 วัน หากเครื่องมีปัญหาจากการผลิตหรือการใช้งานปกติ
                                ทีมงานพร้อมเปลี่ยนเครื่องใหม่หรือดำเนินการแก้ไขให้ทันที โดยไม่มีขั้นตอนที่ยุ่งยากลำบากใจ
                            </p>
                        </article>
                    </div>
                </div>
            </section>

            {/* Stats Section */}
            <section className="section section-alt" aria-label="สถิติความสำเร็จ">
                <div className="container">
                    <div className="stats-grid">
                        {stats.map((stat, index) => (
                            <article key={index} className="stat-item">
                                <div className="stat-number" style={{ color: 'var(--accent)' }}>{stat.number}</div>
                                <h3 className="stat-label" style={{ fontSize: '1.2rem', margin: '5px 0' }}>{stat.label}</h3>
                                <p style={{ fontSize: '0.9rem', opacity: 0.8 }}>{stat.desc}</p>
                            </article>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="cta-section" style={{ padding: '80px 0' }}>
                <div className="container" style={{ textAlign: 'center' }}>
                    <h2 style={{ fontSize: '2.2rem', marginBottom: '20px' }}>สัมผัสประสบการณ์มือถือคุณภาพดีด้วยตัวคุณเอง</h2>
                    <p style={{ fontSize: '1.2rem', marginBottom: '35px', opacity: 0.9 }}>แอดมินพร้อมให้คำแนะนำรุ่นที่เหมาะสมกับงบประมาณและการใช้งานของคุณ</p>
                    <div className="cta-buttons" style={{ justifyContent: 'center', gap: '20px' }}>
                        <a
                            href={`tel:${siteConfig.company.phone.replace(/-/g, '')}`}
                            className="btn btn-primary"
                            style={{ padding: '15px 30px' }}
                        >
                            📞 โทรเลย: {siteConfig.company.phone}
                        </a>
                        <Link href="/contact" className="btn btn-outline" style={{ padding: '15px 30px' }}>
                            ✉️ ติดต่อเราผ่านข้อความ
                        </Link>
                    </div>
                    <div style={{ marginTop: '30px' }}>
                        <a href={siteConfig.social.line} target="_blank" rel="noopener noreferrer" style={{ color: '#00b900', fontWeight: 600 }}>
                            หรือทัก LINE: @mypgphone (ตอบกลับภายใน 5 นาที)
                        </a>
                    </div>
                </div>
            </section>

            {/* Embedded Organization Schema for About Page */}
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{
                    __html: JSON.stringify({
                        "@context": "https://schema.org",
                        "@type": "AboutPage",
                        "mainEntity": {
                            "@id": `${siteConfig.baseUrl}/#organization`
                        },
                        "description": "Information about PG Mobile, a trusted second-hand mobile phone store in Thailand.",
                        "breadcrumb": {
                            "@type": "BreadcrumbList",
                            "itemListElement": [
                                {
                                    "@type": "ListItem",
                                    "position": 1,
                                    "name": "หน้าแรก",
                                    "item": siteConfig.baseUrl
                                },
                                {
                                    "@type": "ListItem",
                                    "position": 2,
                                    "name": "เกี่ยวกับเรา",
                                    "item": `${siteConfig.baseUrl}/about`
                                }
                            ]
                        }
                    })
                }}
            />
        </main>
    );
}
