// src/app/terms/page.js
import Link from 'next/link';
import siteConfig from '@/config/site';

export const metadata = {
    title: `ข้อกำหนดและเงื่อนไขการใช้งาน - ${siteConfig.name}`,
    description: 'อ่านข้อกำหนดและเงื่อนไขการใช้บริการของ PG Mobile เพื่อความเข้าใจในการเลือกซื้อสมาร์ทโฟนมือสองและการรักษาความปลอดภัยในธุรกรรมของท่าน',
    keywords: 'ข้อตกลงการใช้งาน PG Mobile, เงื่อนไขการซื้อขาย, นโยบายร้านมือถือมือสอง, Terms of Service, สมัครสมาชิก',
    alternates: {
        canonical: `${siteConfig.baseUrl}/terms`,
    },
};

export default function TermsPage() {
    const lastUpdate = '14 กุมภาพันธ์ 2569';

    return (
        <main id="terms-of-service-page">
            {/* Page Header */}
            <header className="page-header">
                <div className="container">
                    <h1 style={{ fontSize: '2.5rem', marginBottom: '10px' }}>ข้อกำหนดและเงื่อนไขการใช้งาน</h1>
                    <p style={{ fontSize: '1.2rem', opacity: 0.9 }}>Terms & Conditions of Service</p>
                </div>
            </header>

            {/* Terms Content */}
            <section className="section">
                <div className="container">
                    <article className="legal-content">
                        <p style={{ fontStyle: 'italic', marginBottom: '30px', opacity: 0.8 }}>
                            ปรับปรุงข้อมูลล่าสุดเมื่อ: <time dateTime="2026-02-14">{lastUpdate}</time>
                        </p>

                        <div className="policy-section">
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>1. การยอมรับในข้อตกลง</h2>
                            <p style={{ lineHeight: 1.8 }}>
                                การที่ท่านเข้าใช้งานเว็บไซต์หรือทำการสั่งซื้อสินค้าจากพอร์ทัลของ <strong>{siteConfig.company.nameTh}</strong>
                                ถือว่าท่านได้รับทราบและยอมรับข้อกำหนดทั้งหมดที่ระบุไว้ ณ ที่นี้ หากท่านไม่เห็นด้วยกับข้อกำหนดใดๆ
                                กรุณางดเว้นการเข้าถึงหรือใช้บริการในระบบของเรา
                            </p>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>2. ความถูกต้องของข้อมูลสินค้ามือสอง</h2>
                            <p style={{ lineHeight: 1.8 }}>
                                สินค้าที่เราจำหน่ายเป็น <strong>สินค้ามือสอง (Used / Second-hand)</strong> ซึ่งอาจมีร่องรอยการใช้งานตามสภาพจริง
                                เรามุ่งมั่นที่จะอธิบายสภาพสินค้า (เกรดสินค้า) อย่างละเอียดและส่งวิดีโอทดสอบให้ดูรายเครื่อง
                                เพื่อให้ลูกค้าได้รับข้อมูลที่ถูกต้องที่สุดก่อนการชำระเงิน
                            </p>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>3. กระบวนการสั่งซื้อและการชำระเงิน</h2>
                            <ul style={{ lineHeight: 1.8 }}>
                                <li>• ราคาสินค้าอ้างอิงตามหน้าเพจหรือสต็อกจริง ณ เวลาที่ตกลงซื้อขาย</li>
                                <li>• เมื่อลูกค้ายืนยันการจองผ่าน LINE/Facebook ต้องดำเนินการชำระเงินภายในเวลาที่กำหนด</li>
                                <li>• รองรับการชำระเงินผ่านการโอนเข้าบัญชีบริษัทที่กำหนดเท่านั้น เพื่อความปลอดภัย</li>
                            </ul>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>4. นโยบายการจัดส่งสินค้า</h2>
                            <p style={{ lineHeight: 1.8 }}>
                                เราจะดำเนินการจัดส่งพัสดุผ่านบริษัทขนส่งชั้นนำ (Flash/Kerry/J&T) ภายใน 24-48 ชั่วโมงหลังจากยืนยันยอดเงิน
                                โดยใช้เวลาจัดส่งถึงปลายทางประมาณ 1-3 วันทำการ และจะแจ้งเลขพัสดุให้ลูกค้าทราบทันทีผ่านช่องทางที่ติดต่อไว้
                            </p>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>5. การใช้เนื้อหาบนเว็บไซต์</h2>
                            <p style={{ lineHeight: 1.8 }}>
                                รูปภาพสินค้า วิดีโอรีวิว และข้อความทั้งหมดบนเว็บไซต์เป็นลิขสิทธิ์ของ {siteConfig.name}
                                ห้ามมิให้ผู้ใดคัดลอก นำไปใช้เพื่อการค้า หรือดัดแปลงโดยไม่ได้รับอนุญาตเป็นลายลักษณ์อักษร
                            </p>
                        </div>

                        <footer style={{ marginTop: '50px', padding: '20px', borderTop: '1px solid var(--border)' }}>
                            <h3 style={{ fontSize: '1.3rem', marginBottom: '15px' }}>ช่องทางติดต่อสอบถามเกี่ยวกับข้อกำหนด</h3>
                            <p>
                                หากท่านมีประเด็นสงสัยใดๆ สามารถแชทคุยกับทีมงานแอดมินหรือฝ่ายกฎหมายของร้านได้ที่:<br />
                                💬 LINE: @mypgphone<br />
                                📍 ที่ตั้ง: {siteConfig.company.address}
                            </p>
                        </footer>
                    </article>
                </div>
            </section>

            {/* Breadcrumb Schema */}
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{
                    __html: JSON.stringify({
                        "@context": "https://schema.org",
                        "@type": "BreadcrumbList",
                        "itemListElement": [
                            {
                                "@type": "ListItem",
                                "position": 1,
                                "name": "หน้าแรก",
                                "item": siteConfig.baseUrl
                            },
                            {
                                "@type": "ListItem",
                                "position": 2,
                                "name": "ข้อกำหนดการใช้งาน",
                                "item": `${siteConfig.baseUrl}/terms`
                            }
                        ]
                    })
                }}
            />
        </main>
    );
}
