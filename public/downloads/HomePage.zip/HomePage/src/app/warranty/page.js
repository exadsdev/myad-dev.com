// src/app/warranty/page.js
import Link from 'next/link';
import siteConfig from '@/config/site';

export const metadata = {
    title: `การรับประกันสินค้า 30 วัน - ${siteConfig.name}`,
    description: 'เงื่อนไขและรายละเอียดการรับประกันสินค้ามือถือมือสอง PG Mobile มั่นใจ 100% ด้วยการดูแลหลังการขายที่เป็นระบบ พร้อมเปลี่ยนเครื่องใหม่ใน 30 วัน',
    keywords: 'เงื่อนไขรับประกัน PG Mobile, เคลมมือถือมือสอง, รับประกันมือถือ 30 วัน, ศูนย์บริการ PG Mobile, นโยบายการเคลมสินค้า',
    alternates: {
        canonical: `${siteConfig.baseUrl}/warranty`,
    },
};

export default function WarrantyPage() {
    const warrantyCards = [
        {
            title: '🛡️ ระยะเวลารับประกันสินค้า',
            content: 'รับประกันคุณภาพสินค้าทุกเครื่องเป็นเวลา 30 วัน นับตั้งแต่วันที่ลูกค้าได้รับพัสดุ (อ้างอิงสถานะการจัดส่งจากบริษัทขนส่ง)',
        },
        {
            title: '✅ เงื่อนไขการรับประกัน',
            content: 'ครอบคลุมความผิดปกติจากการผลิตหรือการใช้งานปกติ เช่น หน้าจอสัมผัสผิดปกติ, ลำโพงไม่ดัง, ชาร์จไม่เข้า, ปุ่มกดไม่ทำงาน และปัญหาด้านฮาร์ดแวร์อื่นๆ',
        },
        {
            title: '❌ ข้อยกเว้นการรับประกัน',
            content: 'ไม่ครอบคลุมกรณีเครื่องตกกระแทกพื้น, ตกน้ำ, ความชื้นสะสม, แกะเครื่องเองโดยไม่ได้รับอนุญาต, หรือความเสียหายที่เกิดจากอุบัติเหตุและการใช้งานผิดประเภท',
        },
        {
            title: '📋 ขั้นตอนการแจ้งเคลม',
            content: '1. ทักแชทแจ้งปัญหาพร้อมส่งรูป/วิดีโอ 2. ส่งสินค้ากลับมายังศูนย์บริการ 3. ช่างตรวจสอบ 1-3 วันทำการ 4. รับเครื่องซ่อมหรือเปลี่ยนเครื่องใหม่',
        },
        {
            title: '📦 บริการรับ-ส่งสินค้าเคลม',
            content: 'ทางร้านดูแลรับผิดชอบค่าใช้จ่ายในการจัดส่งทั้งไปและกลับ สำหรับกรณีที่เป็นความผิดปกติจากการผลิตจริง เพื่อความสบายใจของลูกค้า',
        },
        {
            title: '📞 ช่องทางติดต่อศูนย์บริการ',
            content: `โทรสอบถาม: ${siteConfig.company.phone} | LINE: @mypgphone | เวลาทำการ: ${siteConfig.businessHours}`,
        },
    ];

    const importantNotes = [
        'กรุณาเก็บหลักฐานการสั่งซื้อหรือใบเสร็จ (ถ้ามี) ไว้เพื่อใช้ในการยืนยันตัวตนการเคลม',
        'สินค้าต้องอยู่ในสภาพเดิมเหมือนวันที่ส่งมอบ ไม่ถูกดัดแปลงซอฟต์แวร์หรือฮาร์ดแวร์',
        'การพิจารณาผลการเคลมขึ้นอยู่กับช่างผู้เชี่ยวชาญของทางร้านเป็นผู้ประเมินตามหลักเกณฑ์',
        'วอยด์ประกัน (ถ้ามี) ต้องอยู่ในสภาพสมบูรณ์ ไม่มีการแกะหรือทำลาย',
    ];

    return (
        <main id="warranty-page">
            {/* Page Header */}
            <header className="page-header">
                <div className="container">
                    <h1 style={{ fontSize: '2.5rem', marginBottom: '10px' }}>นโยบายการรับประกันสินค้า</h1>
                    <p style={{ fontSize: '1.2rem', opacity: 0.9 }}>มาตรฐานการดูแลหลังการขายที่ PG Mobile ให้ความสำคัญเป็นอันดับหนึ่ง</p>
                </div>
            </header>

            {/* SGE Optimized Summary Box */}
            <section className="section" style={{ paddingBottom: 0 }}>
                <div className="container">
                    <div
                        className="feature-card"
                        style={{
                            borderLeft: '4px solid #10b981',
                            backgroundColor: 'rgba(16, 185, 129, 0.05)',
                            padding: '24px'
                        }}
                    >
                        <h2 style={{ fontSize: '1.4rem', margin: '0 0 12px' }}>สรุปเงื่อนไขการรับประกัน (FAQ)</h2>
                        <p style={{ lineHeight: 1.8, margin: 0 }}>
                            มือถือทุกเครื่องจาก <strong>PG Mobile รับประกัน 30 วันเต็ม</strong> นับจากวันรับของ
                            ครอบคลุมอาการเสียจากระบบเครื่องทุกอย่าง (ที่ไม่ใช่อุบัติเหตุ) เช่น จอ, แบต, ชาร์จ, สัญญาณ
                            หากพบปัญหาสามารถส่งเคลมได้ฟรี และทางร้านดูแลค่าส่งให้ทั้งหมด
                            เพื่อความมั่นใจว่าท่านจะได้รับสินค้าที่สมบูรณ์ที่สุด
                        </p>
                    </div>
                </div>
            </section>

            {/* Warranty Content Grid */}
            <section className="section">
                <div className="container">
                    <div className="warranty-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '30px' }}>
                        {warrantyCards.map((card, index) => (
                            <article key={index} className="warranty-card">
                                <h3 style={{ fontSize: '1.3rem', marginBottom: '12px', color: 'var(--accent)' }}>{card.title}</h3>
                                <p style={{ lineHeight: 1.7, opacity: 0.9 }}>{card.content}</p>
                            </article>
                        ))}
                    </div>
                </div>
            </section>

            {/* Important Notes */}
            <section className="section section-alt">
                <div className="container">
                    <article className="legal-content">
                        <h2 style={{ fontSize: '1.8rem', marginBottom: '20px' }}>ข้อควรทราบเพิ่มเติม</h2>
                        <ul style={{ listStyle: 'none', padding: 0 }}>
                            {importantNotes.map((note, index) => (
                                <li key={index} style={{ marginBottom: '15px', display: 'flex', alignItems: 'flex-start', gap: '10px', lineHeight: 1.7 }}>
                                    <span style={{ color: 'var(--accent)', fontWeight: 'bold' }}>•</span>
                                    <span>{note}</span>
                                </li>
                            ))}
                        </ul>
                    </article>
                </div>
            </section>

            {/* CTA Section */}
            <section className="cta-section">
                <div className="container" style={{ textAlign: 'center' }}>
                    <h2 style={{ fontSize: '2rem', marginBottom: '15px' }}>พบปัญหากับสินค้าที่ซื้อไป?</h2>
                    <p style={{ fontSize: '1.1rem', marginBottom: '30px', opacity: 0.9 }}>อย่าลังเลที่จะติดต่อเรา ทีมงานแอดมินพร้อมดูแลประสานงานการเคลมให้โดยเร็วที่สุด</p>
                    <div className="cta-buttons" style={{ justifyContent: 'center', gap: '20px' }}>
                        <a
                            href={`tel:${siteConfig.company.phone.replace(/-/g, '')}`}
                            className="btn btn-primary"
                        >
                            📞 แจ้งปัญหาทางโทรศัพท์
                        </a>
                        <Link href="/contact" className="btn btn-outline">
                            ✉️ แจ้งปัญหาผ่านข้อความ
                        </Link>
                    </div>
                    <div style={{ marginTop: '20px' }}>
                        <a href={siteConfig.social.line} target="_blank" rel="noopener noreferrer" style={{ fontWeight: 600, color: '#00b900' }}>
                            หรือทัก LINE: @mypgphone (เจ้าหน้าที่บริการหลังการขาย)
                        </a>
                    </div>
                </div>
            </section>

            {/* Breadcrumb Schema */}
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{
                    __html: JSON.stringify({
                        "@context": "https://schema.org",
                        "@type": "BreadcrumbList",
                        "itemListElement": [
                            {
                                "@type": "ListItem",
                                "position": 1,
                                "name": "หน้าแรก",
                                "item": siteConfig.baseUrl
                            },
                            {
                                "@type": "ListItem",
                                "position": 2,
                                "name": "การรับประกัน",
                                "item": `${siteConfig.baseUrl}/warranty`
                            }
                        ]
                    })
                }}
            />
        </main>
    );
}
