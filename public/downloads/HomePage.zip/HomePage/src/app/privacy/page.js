// src/app/privacy/page.js
import siteConfig from '@/config/site';

export const metadata = {
    title: `นโยบายความเป็นส่วนตัว - ${siteConfig.name}`,
    description: 'นโยบายความเป็นส่วนตัวของ PG Mobile รายละเอียดการเก็บรวบรวมข้อมูล การรักษาความปลอดภัย และสิทธิในข้อมูลส่วนบุคคลตามมาตรฐาน PDPA',
    keywords: 'นโยบายความเป็นส่วนตัว PG Mobile, ข้อตกลงการใช้งาน, PDPA, การคุ้มครองข้อมูลส่วนบุคคล, Security Policy',
    alternates: {
        canonical: `${siteConfig.baseUrl}/privacy`,
    },
};

export default function PrivacyPage() {
    const lastUpdate = '14 กุมภาพันธ์ 2569';

    return (
        <main id="privacy-policy-page">
            {/* Page Header */}
            <header className="page-header">
                <div className="container">
                    <h1 style={{ fontSize: '2.5rem', marginBottom: '10px' }}>นโยบายความเป็นส่วนตัว</h1>
                    <p style={{ fontSize: '1.2rem', opacity: 0.9 }}>Privacy Policy & Data Protection</p>
                </div>
            </header>

            {/* Privacy Content */}
            <section className="section">
                <div className="container">
                    <article className="legal-content">
                        <p style={{ fontStyle: 'italic', marginBottom: '30px', opacity: 0.8 }}>
                            ปรับปรุงข้อมูลล่าสุดเมื่อ: <time dateTime="2026-02-14">{lastUpdate}</time>
                        </p>

                        <div className="policy-section">
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>1. บทนำและความสำคัญ</h2>
                            <p style={{ lineHeight: 1.8 }}>
                                <strong>{siteConfig.company.nameTh}</strong> (&quot;เรา&quot;) ให้ความสำคัญอย่างยิ่งต่อการคุ้มครองข้อมูลส่วนบุคคลของท่าน
                                นโยบายนี้อธิบายถึงวิธีการที่เราจัดเก็บ ใช้ เปิดเผย และรักษาความปลอดภัยข้อมูลส่วนบุคคล
                                เพื่อให้สอดคล้องกับพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล (PDPA)
                            </p>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>2. ข้อมูลที่เราเก็บรวบรวม</h2>
                            <p>เพื่อความสะดวกในการให้บริการสั่งซื้อมือถือมือสอง เราจำเป็นต้องจัดเก็บข้อมูลดังนี้:</p>
                            <ul style={{ listStyle: 'none', padding: 0, marginTop: '10px' }}>
                                <li style={{ marginBottom: '10px' }}><strong>• ข้อมูลส่วนตัว:</strong> ชื่อ-นามสกุล และเบอร์โทรศัพท์สำหรับติดต่อประสานงาน</li>
                                <li style={{ marginBottom: '10px' }}><strong>• ข้อมูลการจัดส่ง:</strong> ที่อยู่จัดส่งสินค้าโดยละเอียด เพื่อความถูกต้องในการส่งพัสดุ</li>
                                <li style={{ marginBottom: '10px' }}><strong>• ข้อมูลการเงิน:</strong> หลักฐานการชำระเงิน (สลิปโอนเงิน) เพื่อตรวจสอบยอดคำสั่งซื้อ</li>
                            </ul>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>3. วัตถุประสงค์ในการใช้ข้อมูล</h2>
                            <p>เราใช้ข้อมูลส่วนบุคคลของท่านเพื่อวัตถุประสงค์เฉพาะดังนี้:</p>
                            <ul style={{ listStyle: 'none', padding: 0, marginTop: '10px' }}>
                                <li style={{ marginBottom: '10px' }}>• ดำเนินการจัดทำคำสั่งซื้อและจัดส่งมือถือถึงมือท่านอย่างรวดเร็ว</li>
                                <li style={{ marginBottom: '10px' }}>• แจ้งสถานะการจัดส่งและเลขพัสดุผ่านช่องทาง LINE หรือ Facebook</li>
                                <li style={{ marginBottom: '10px' }}>• ตรวจสอบประวัติการรับประกันสินค้า (30 วัน) ในกรณีที่เครื่องมีปัญหา</li>
                                <li style={{ marginBottom: '10px' }}>• ให้คำปรึกษาและบริการหลังการขายตามรุ่นที่ท่านสั่งซื้อ</li>
                            </ul>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>4. การรักษาความปลอดภัยของข้อมูล</h2>
                            <p style={{ lineHeight: 1.8 }}>
                                เราใช้มาตรการทางเทคนิคและการบริหารจัดการฐานข้อมูลที่รัดกุม
                                เพื่อป้องกันไม่ให้ข้อมูลของลูกค้าสูญหาย ถูกนำไปใช้ในทางที่ผิด หรือถูกเข้าถึงโดยไม่ได้รับอนุญาต
                                ข้อมูลทั้งหมดจะถูกเข้าถึงได้เฉพาะเจ้าหน้าที่ที่ดูแลคำสั่งซื้อโดยตรงเท่านั้น
                            </p>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>5. การเปิดเผยข้อมูลแก่บุคคลที่สาม</h2>
                            <p style={{ lineHeight: 1.8 }}>
                                เราจะส่งต่อข้อมูลที่จำเป็น (ชื่อ, ที่อยู่, เบอร์โทร) ให้แก่ <strong>บริษัทขนส่งเอกชน (เช่น Flash Express, Kerry, J&T)</strong>
                                เฉพาะเพื่อวัตถุประสงค์ในการจัดส่งสินค้าเท่านั้น และเราจะไม่มีการจัดจำหน่ายข้อมูลของท่านให้แก่ธุรกิจโฆษณาภายนอกโดยเด็ดขาด
                            </p>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>6. สิทธิของท่านในฐานะเจ้าของข้อมูล</h2>
                            <p>ท่านมีสิทธิในการขอตรวจสอบ แก้ไข หรือขอลบข้อมูลส่วนตัวของท่านออกจากระบบของเราได้ตลอดเวลา
                                โดยสามารถติดต่อเจ้าหน้าที่ผ่านช่องทาง LINE อย่างเป็นทางการของทางร้าน</p>
                        </div>

                        <div className="policy-section" style={{ marginTop: '30px', padding: '20px', backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: '10px' }}>
                            <h2 style={{ fontSize: '1.6rem', marginBottom: '15px' }}>7. ข้อมูลการติดต่อเจ้าหน้าที่คุ้มครองข้อมูล</h2>
                            <p>หากท่านมีข้อสงสัยเกี่ยวกับนโยบายความเป็นส่วนตัว กรุณาติดต่อ:</p>
                            <p style={{ marginTop: '10px' }}>
                                <strong>ร้าน PG Mobile (สกลนคร)</strong><br />
                                📞 โทร: {siteConfig.company.phone}<br />
                                💬 LINE: @mypgphone<br />
                                📍 ที่อยู่: {siteConfig.company.address}
                            </p>
                        </div>
                    </article>
                </div>
            </section>

            {/* Breadcrumb Schema */}
            <script
                type="application/ld+json"
                dangerouslySetInnerHTML={{
                    __html: JSON.stringify({
                        "@context": "https://schema.org",
                        "@type": "BreadcrumbList",
                        "itemListElement": [
                            {
                                "@type": "ListItem",
                                "position": 1,
                                "name": "หน้าแรก",
                                "item": siteConfig.baseUrl
                            },
                            {
                                "@type": "ListItem",
                                "position": 2,
                                "name": "นโยบายความเป็นส่วนตัว",
                                "item": `${siteConfig.baseUrl}/privacy`
                            }
                        ]
                    })
                }}
            />
        </main>
    );
}
