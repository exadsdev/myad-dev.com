// src/components/ProductsGallery.js
import Image from 'next/image';

const galleryImages = [
    { src: '/images/pg3.jpg', alt: 'iPhone มือสอง สภาพนางฟ้า รุ่นยอดนิยมที่ PG Mobile' },
    { src: '/images/pg4.jpg', alt: 'สมาร์ทโฟน Android สภาพสวย ราคาถูก สกลนคร' },
    { src: '/images/pg5.jpg', alt: 'มือถือหลุดจำนำ คัดเกรดคุณภาพสูง พร้อมใช้งาน' },
    { src: '/images/pg6.jpg', alt: 'โทรศัพท์มือสอง iPhone 13 14 15 สภาพเยี่ยม' },
    { src: '/images/pg7.jpg', alt: 'สต็อกมือถือมือสองรุ่นล่าสุดที่ร้าน PG Mobile' },
    { src: '/images/pg8.jpg', alt: 'เช็คสภาพเครื่องมือสองก่อนส่ง ประสบการณ์กว่า 5 ปี' },
    { src: '/images/pg9.jpg', alt: 'มือถือราคาประหยัด สำหรับนักเรียน นักศึกษา' },
    { src: '/images/pg10.jpg', alt: 'รีวิวสินค้าจริงจากคลังสินค้า PG Mobile คำตากล้า' },
];

export default function ProductsGallery() {
    return (
        <section id="products-gallery" className="section" aria-label="แกลเลอรีสินค้าแนะนำ">
            <div className="container">
                <header style={{ textAlign: 'center', marginBottom: '32px' }}>
                    <h2 className="section-title">สินค้า <span>คัดเกรดแนะนำ</span></h2>
                    <p style={{ maxWidth: '800px', margin: '0.5rem auto 0', opacity: 0.8, lineHeight: 1.6 }}>
                        ชมตัวอย่างสมาร์ทโฟนมือสองคุณภาพดีที่เราคัดสรรมาเพื่อคุณโดยเฉพาะ
                        ทุกเครื่องผ่านการตรวจเช็คอย่างละเอียดและพร้อมส่งให้ลูกค้าทั่วประเทศ
                    </p>
                </header>

                <div className="gallery-grid" role="list">
                    {galleryImages.map((image, index) => (
                        <article key={index} className="gallery-item" role="listitem">
                            <Image
                                src={image.src}
                                alt={image.alt}
                                width={300}
                                height={300}
                                loading="lazy"
                                style={{ objectFit: 'cover' }}
                                sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw"
                                title={image.alt}
                            />
                        </article>
                    ))}
                </div>

                <div
                    className="feature-card"
                    style={{
                        marginTop: '32px',
                        padding: '24px',
                        display: 'flex',
                        alignItems: 'flex-start',
                        gap: '16px',
                        backgroundColor: 'rgba(255,255,255,0.03)',
                        borderRadius: '12px'
                    }}
                >
                    <div style={{ fontSize: '24px' }} aria-hidden="true">💡</div>
                    <div>
                        <h3 style={{ margin: '0 0 8px', fontSize: '1.2rem' }}>ข้อมูลสำคัญสำหรับลูกค้า</h3>
                        <p style={{ margin: 0, opacity: 0.9, lineHeight: 1.7 }}>
                            <strong>หมายเหตุ:</strong> รูปภาพข้างต้นเป็นเพียงตัวอย่างสินค้าในคลังของเรา
                            เนื่องจากสินค้ามือถือมือสองมีการหมุนเวียนสต็อกอย่างรวดเร็ว (Fast Moving)
                            แนะนำให้ลูกค้า <strong>ทักแชทสอบถามรุ่นที่สนใจ</strong> เพื่อเช็คราคาปัจจุบัน สภาพเครื่องจริง
                            และวิดีโอทดสอบการใช้งานล่าสุดก่อนตัดสินใจซื้อครับ
                        </p>
                    </div>
                </div>
            </div>
        </section>
    );
}
